import { atom } from '../atom/index.js'

/* @__NO_SIDE_EFFECTS__ */
export const map = (initial = {}) => {
  let $map = atom(initial)
  $map.eqKey = Object.is

  $map.setKey = function (key, value) {
    let oldMap = $map.value
    if (typeof value === 'undefined' && key in $map.value) {
      $map.value = { ...$map.value }
      delete $map.value[key]
      $map.notify(oldMap, key)
    } else if (!$map.eqKey($map.value[key], value, key)) {
      $map.value = {
        ...$map.value,
        [key]: value
      }
      $map.notify(oldMap, key)
    }
  }

  return $map
}

import {readFile,readdir,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {hash,captureTree,treeHash} from '../../src/v9/workspace.mjs';
import {parseNativeEvents} from '../../src/bench/native-codex.mjs';
const base=resolve('.suffice/v10-native15-20261023'),root=join(base,'plan');
const read=async p=>JSON.parse(await readFile(p,'utf8'));
const p=await read(join(root,'plan.json')),started=await read(join(root,'execution-started.json')),issues=[];
for(const [path,sha] of p.runtimeFiles)if(hash(await readFile(path))!==sha)issues.push('Runtime changed: '+path);
if(hash(await readFile(join(root,'grading-freeze.json')))!==started.gradingFreezeSha256)issues.push('Grader freeze changed');
let execution;try{execution=await read(join(root,'execution-complete.json'));}catch{const files=(await readdir(root)).filter(n=>/^progress-\d+\.json$/.test(n));const rows=await Promise.all(files.map(n=>read(join(root,n))));rows.sort((a,b)=>b.completed-a.completed);execution=rows[0]??{attempts:[]};}
const rows=[];const equal=(a,b)=>Math.abs(a-b)<1e-9;
for(const a of execution.attempts){
 const result=await read(a.actorResultPath),directory=join(root,'attempts',a.id,'receipts','actor');
 if(treeHash(await captureTree(a.workspace,{includeIgnored:true}))!==a.sourceHash)issues.push('Workspace hash changed: '+a.id);
 if(treeHash(await captureTree(a.snapshot,{includeIgnored:true}))!==a.sourceHash)issues.push('Snapshot hash changed: '+a.id);
 let price=0,requests=0,localStops=0,tools={},toolFreeReviewerCalls=0;
 if(a.strategy==='v10'){
  for(let i=0;i<(result.stages??[]).length;i++){
   const s=result.stages[i],events=(await readFile(join(directory,`stage-${i+1}-${s.role}`,'events.jsonl'),'utf8')).split('\n').filter(Boolean).map(JSON.parse);let cost=0;
   const usage={inputTokens:0,cachedInputTokens:0,outputTokens:0};
   for(const e of events){
    if(e.type==='request_reservation')requests++;
    if(e.type==='local_stop')localStops++;
    if(e.type==='assistant'){if(e.model!==s.model||e.provider!=='openai')issues.push('Model mismatch: '+a.id);const u=e.usage;if(u){cost+=u.cost?.total??0;usage.inputTokens+=u.input+u.cacheRead+u.cacheWrite;usage.cachedInputTokens+=u.cacheRead;usage.outputTokens+=u.output;}}
    if(e.type==='tool_observation')tools[e.tool]=(tools[e.tool]??0)+1;
   }
   if(s.costKnown&&!equal(cost,s.costUsd))issues.push('Stage cost mismatch: '+a.id);
   for(const key of Object.keys(usage))if(usage[key]!==s.usage?.[key])issues.push('Stage token mismatch: '+a.id+' '+key);
   if(['test-writer','arbiter'].includes(s.role))toolFreeReviewerCalls+=s.toolCalls;
   price+=cost;
  }
  if(a.costKnown&&!equal(price,a.costUsd))issues.push('Attempt cost mismatch: '+a.id);
 }else{
  const raw=await readFile(join(directory,'events.jsonl'),'utf8');
  const parsed=parseNativeEvents(raw,{...result.process,model:p.models.native,pricing:p.pricing.models[p.models.native]});
  if(parsed.costKnown!==a.costKnown||(a.costKnown&&!equal(parsed.costUsd,a.costUsd)))issues.push('Native price mismatch: '+a.id);
  if(JSON.stringify(parsed.usage)!==JSON.stringify(a.usage))issues.push('Native token mismatch: '+a.id);
  price=parsed.costUsd;requests=parsed.userTurns.completed;
 }
 if(toolFreeReviewerCalls)issues.push('Reviewer returned tools: '+a.id);
 rows.push({id:a.id,taskId:a.taskId,strategy:a.strategy,status:a.status,actorStatus:a.actorStatus,costKnown:a.costKnown,costUsd:a.costUsd,knownCostFloorUsd:a.knownCostFloorUsd,requests,localStops,tools,reviewerToolCalls:toolFreeReviewerCalls,repairs:a.repairs,takeovers:a.takeovers,protectionViolations:a.protectionViolations,internalProtectionViolations:a.internalProtectionViolations,latencyMs:a.latencyMs,sourceHash:a.sourceHash});
}
const report={at:new Date().toISOString(),closed:execution.closed??false,completed:rows.length,issues,runtimeHash:p.runtimeHash,gradingFreezeSha256:started.gradingFreezeSha256,costKnown:rows.every(r=>r.costKnown),knownCostFloorUsd:rows.reduce((n,r)=>n+(r.costKnown?r.costUsd:r.knownCostFloorUsd),0),attempts:rows};
await writeFile(join(base,'audit.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({completed:report.completed,closed:report.closed,issues,costKnown:report.costKnown,knownCostFloorUsd:report.knownCostFloorUsd,recent:rows.slice(-4).map(({id,status,costUsd,repairs,takeovers})=>({id,status,costUsd,repairs,takeovers}))},null,2));if(issues.length)process.exitCode=1;

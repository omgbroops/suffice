import { defineScalarTag, NOT_RESOLVED } from '../../tag.ts'

const YAML_FLOAT_PATTERN = new RegExp(
  // 2.5e4, 2.5 and integers
  '^(?:[-+]?[0-9]+(?:\\.[0-9]*)?(?:[eE][-+]?[0-9]+)?' +
  // .2e4, .2
  '|[-+]?\\.[0-9]+(?:[eE][-+]?[0-9]+)?' +
  // .inf
  '|[-+]?\\.(?:inf|Inf|INF)' +
  // .nan
  '|\\.(?:nan|NaN|NAN))$')

const YAML_FLOAT_SPECIAL_PATTERN = new RegExp(
  '^(?:' +
  // .inf
  '[-+]?\\.(?:inf|Inf|INF)' +
  // .nan
  '|\\.(?:nan|NaN|NAN))$')

function resolveYamlFloat (source: string) {
  if (!YAML_FLOAT_PATTERN.test(source)) return NOT_RESOLVED

  let value = source.toLowerCase()
  const sign = value[0] === '-' ? -1 : 1

  if ('+-'.includes(value[0])) value = value.slice(1)

  if (value === '.inf') return sign === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY
  if (value === '.nan') return NaN

  const result = sign * parseFloat(value)

  if (Number.isFinite(result) || YAML_FLOAT_SPECIAL_PATTERN.test(source)) return result
  return NOT_RESOLVED
}

function representYamlFloat (object: number) {
  if (isNaN(object)) return '.nan'
  if (object === Number.POSITIVE_INFINITY) return '.inf'
  if (object === Number.NEGATIVE_INFINITY) return '-.inf'
  if (Object.is(object, -0)) return '-0.0'

  const result = object.toString(10)
  return /^[-+]?[0-9]+e/.test(result) ? result.replace('e', '.e') : result
}

const floatCoreTag = defineScalarTag('tag:yaml.org,2002:float', {
  implicit: true,
  // Superset of source.charAt(0) over all matched inputs: optional sign, '.', or digit
  // ('.inf'/'.nan' start with '.').
  implicitFirstChars: ['-', '+', '.', ...'0123456789'],
  resolve: resolveYamlFloat,
  identify: (object) => Object.prototype.toString.call(object) === '[object Number]' &&
    // Also claim integer-valued numbers that stringify in exponential notation
    // (>= 1e21), since their `!!int` text would be invalid; `represent` emits a
    // valid float form for them.
    (object % 1 !== 0 || Object.is(object, -0) || /e/i.test(object.toString(10))),
  represent: representYamlFloat
})

export { floatCoreTag }

import {readFile,writeFile,mkdir,cp,readdir,stat} from 'node:fs/promises';
import {join,resolve,dirname,basename} from 'node:path';
import {hash,captureTree} from '../../src/v9/workspace.mjs';
import {runProcess} from '../../src/v9/process.mjs';
const base=resolve('.suffice/v10-native15-20261023'),root=join(base,'plan'),out=resolve('reports/v10-native15-20261023'),stage=join(base,'result-evidence');
const read=async p=>JSON.parse(await readFile(p,'utf8')),save=(p,v)=>writeFile(p,JSON.stringify(v,null,2)+'\n');
const p=await read(join(root,'plan.json')),e=await read(join(root,'execution-complete.json')),g=await read(join(root,'grades.final.json'));
if(!e.closed||e.attempts.length!==30||g.grades.length!==30||g.grades.some(row=>row.accepted===null))throw Error('All actors and grading must close before archiving');
await mkdir(stage,{recursive:false});
const filter=path=>basename(path)!=='.git';
for(const file of ['plan.json','execution-started.json','execution-complete.json','grading-freeze.json','grades.json','reference-validation.json','summary.json','grades.final.json','reference-validation.final.json','summary.final.json']){await cp(join(root,file),join(out,file));await cp(join(root,file),join(stage,file));}
for(const a of e.attempts){
 const source=join(root,'attempts',a.id),target=join(stage,'attempts',a.id);await mkdir(join(target,'receipts'),{recursive:true});await cp(join(source,'attempt.json'),join(target,'attempt.json'));
 for(const item of ['actor-result.json','raw-source','final-source']){try{await cp(join(source,'receipts',item),join(target,'receipts',item),{recursive:true,filter});}catch(error){if(error.code!=='ENOENT')throw error;}}
 const actor=join(source,'receipts','actor');await cp(actor,join(target,'receipts','actor'),{recursive:true,filter:path=>filter(path)&&path!==join(actor,'final-source')});
}
const evaluation=join(stage,'evaluation');await mkdir(evaluation,{recursive:true});
for(const item of ['frozen','results','reference-receipts','downloads','grading-start.json','grading-complete.json']){try{await cp(join(root,'evaluation',item),join(evaluation,item),{recursive:true,filter});}catch(error){if(error.code!=='ENOENT')throw error;}}
await cp(join(root,'evaluation','supplemental'),join(evaluation,'supplemental'),{recursive:true,filter:path=>filter(path)&&path!==join(root,'evaluation','supplemental','grading')});
await cp(resolve('scripts/v10-native-revalidate.mjs'),join(stage,'v10-native-revalidate.mjs'));
await cp(resolve('tests/v10-native-revalidate.test.mjs'),join(stage,'v10-native-revalidate.test.mjs'));
await cp(join(base,'cookie-review.json'),join(stage,'cookie-review.json'));
const references=[];
for(const t of p.tasks){
 try{
  const original=await captureTree(t.inputDir,{includeIgnored:true}),reference=await captureTree(join(root,'evaluation','references',t.id),{includeIgnored:true}),files=[];
  for(const [name,value] of reference){const prior=original.get(name);if(prior?.bytes.equals(value.bytes)&&prior.mode===value.mode)continue;const target=join(evaluation,'reference-files',t.id,name);await mkdir(dirname(target),{recursive:true});await writeFile(target,value.bytes);files.push({path:name,mode:value.mode,sha256:hash(value.bytes)});}
  references.push({id:t.id,files});
 }catch(error){references.push({id:t.id,error:error.message});}
}
await save(join(evaluation,'reference-files.json'),references);
await cp(join(base,'audit.json'),join(out,'audit.json'));await cp(join(base,'audit.json'),join(stage,'audit.json'));
for(const file of ['audit-progress.mjs','archive-results.mjs'])await cp(join(base,file),join(stage,file));
const entries=[];
async function walk(path,rel=''){
 for(const item of (await readdir(path,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){const full=join(path,item.name),name=rel?rel+'/'+item.name:item.name;if(item.isDirectory())await walk(full,name);else{const bytes=await readFile(full);entries.push({path:name,bytes:bytes.length,mode:(await stat(full)).mode&0o777,sha256:hash(bytes)});}}
}
await walk(stage);const inventory='{"files":[\n'+entries.map(entry=>JSON.stringify(entry)).join(',\n')+'\n]}\n';await writeFile(join(out,'evidence-files.json'),inventory);
const zip=join(out,'results-evidence.zip'),packed=await runProcess('tar',['-a','-c','-f',zip,'-C',stage,'.'],{timeoutMs:60000});if(packed.exitCode!==0)throw Error(packed.stderr);
const verify=join(base,'results-evidence-verify');await mkdir(verify,{recursive:false});const extracted=await runProcess('tar',['-x','-f',zip,'-C',verify],{timeoutMs:60000});if(extracted.exitCode!==0)throw Error(extracted.stderr);
for(const file of entries)if(hash(await readFile(join(verify,file.path)))!==file.sha256)throw Error('Archive byte mismatch: '+file.path);
await save(join(out,'archive.json'),{at:new Date().toISOString(),file:'results-evidence.zip',sha256:hash(await readFile(zip)),bytes:(await stat(zip)).size,inventorySha256:hash(inventory),verifiedFiles:entries.length,unpackedBytes:entries.reduce((n,f)=>n+f.bytes,0),otherRequiredArchives:['runtime.zip','public-inputs.zip','preflight-and-preparation.zip']});
await cp(join(root,'evaluation','grading-start.json'),join(out,'grading-start.json'));await cp(join(root,'evaluation','grading-complete.json'),join(out,'grading-complete.json'));
for(const file of ['decision.json','completed.json','blind-review.md'])await cp(join(root,'evaluation','supplemental',file),join(out,'supplemental-'+file));
console.log(JSON.stringify({files:entries.length,zipBytes:(await stat(zip)).size,unpackedBytes:entries.reduce((n,f)=>n+f.bytes,0)}));

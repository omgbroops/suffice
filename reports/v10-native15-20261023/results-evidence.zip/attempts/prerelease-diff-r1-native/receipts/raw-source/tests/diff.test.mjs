import test from 'node:test';
import assert from 'node:assert/strict';
import diff from '../src/functions/diff.js';

const checkBothOrders = cases => {
  for (const [low, high, expected] of cases) {
    assert.equal(diff(low, high), expected, `${low} -> ${high}`);
    assert.equal(diff(high, low), expected, `${high} -> ${low}`);
  }
};

test('prerelease to stable compares core versions', () => {
  checkBothOrders([
    ['1.7.2-1', '1.8.1', 'minor'],
    ['1.1.1-pre', '2.1.1', 'major'],
    ['1.2.0-pre', '1.3.1', 'minor'],
    ['1.2.3-pre', '1.3.0', 'minor'],
    ['1.2.3-pre', '2.0.1', 'major'],
    ['1.2.3-pre', '2.1.0', 'major'],
    ['1.2.3-pre', '2.0.0', 'major'],
    ['1.2.3-pre', '1.2.4', 'patch'],
  ]);
});

test('prerelease stabilization keeps existing release semantics', () => {
  checkBothOrders([
    ['1.2.0-pre', '1.2.0', 'minor'],
    ['1.2.3-pre', '1.2.3', 'patch'],
    ['1.0.0-pre', '1.0.0', 'major'],
    ['0.0.0-pre', '0.0.0', 'major'],
    ['1.0.0-pre', '1.1.1', 'major'],
    ['1.0.0-pre', '2.1.1', 'major'],
  ]);
});

test('prerelease to prerelease keeps prerelease classifications', () => {
  checkBothOrders([
    ['1.1.1-pre', '2.1.1-pre', 'premajor'],
    ['1.7.2-1', '1.8.1-1', 'preminor'],
    ['1.2.3-pre', '1.2.4-pre', 'prepatch'],
    ['1.2.3-pre.1', '1.2.3-pre.2', 'prerelease'],
    ['1.2.3-pre', '1.2.3-pre', null],
  ]);
});

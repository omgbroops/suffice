import {readFile, writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {parse} from 'acorn';
const root = resolve(import.meta.dirname, '..'), repo = resolve(root, '../..');
const source = await readFile(resolve(repo, 'scripts/v10-native-grade.mjs'), 'utf8');
const ast = parse(source, {ecmaVersion: 'latest', sourceType: 'module'});
const edits = [];
function visit(node, taskId) {
  if (!node || typeof node !== 'object') return;
  if (node.type === 'IfStatement') {
    const test = node.test;
    const id = test?.type === 'BinaryExpression' && test.left?.type === 'MemberExpression' && test.left.object?.name === 'task' && test.left.property?.name === 'id' ? test.right?.value : undefined;
    visit(node.consequent, id ?? taskId); visit(node.alternate, taskId); return;
  }
  if (node.type === 'CallExpression' && node.callee?.name === 'editReference') edits.push({taskId, path: node.arguments[1].value, before: node.arguments[2].value, after: node.arguments[3].value, expected: node.arguments[4].value});
  for (const [key, value] of Object.entries(node)) if (!['start', 'end'].includes(key)) {
    if (Array.isArray(value)) value.forEach(child => visit(child, taskId)); else if (value && typeof value === 'object') visit(value, taskId);
  }
}
visit(ast);
const receipts = [];
for (const edit of edits) {
  const original = await readFile(resolve(root, 'fixtures', edit.taskId, edit.path), 'utf8');
  const occurrences = original.split(edit.before).length - 1;
  if (occurrences !== edit.expected) throw Error(`Reference anchor count failed for ${edit.taskId}`);
  receipts.push({taskId: edit.taskId, path: edit.path, occurrences, expected: edit.expected});
}
const old = parse(await readFile(resolve(repo, 'scripts/prepare-picomatch.mjs'), 'utf8'), {ecmaVersion: 'latest', sourceType: 'module'});
const literals = [];
function collect(node) {if (!node || typeof node !== 'object') return; if (node.type === 'Literal' && typeof node.value === 'string') literals.push(node.value); if (node.type === 'TemplateLiteral' && node.expressions.length === 0) literals.push(node.quasis[0].value.cooked); for (const value of Object.values(node)) {if (Array.isArray(value)) value.forEach(collect); else if (value && typeof value === 'object') collect(value);}}
collect(old);
for (const edit of edits.filter(edit => edit.taskId.startsWith('picomatch-'))) if (!literals.includes(edit.before) || !literals.includes(edit.after)) throw Error(`Picomatch procedure differs from existing preparation: ${edit.taskId}`);
const result = {at: new Date().toISOString(), scriptSha256: createHash('sha256').update(source).digest('hex'), allMinimalEditAnchorsMatch: true, picomatchEditsEqualExistingProcedure: true, receipts, gradersExecuted: 0, referencesFetched: 0};
await writeFile(resolve(root, 'preparation/grader-static-probe.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({anchors: edits.length, allMatch: true, gradersExecuted: 0, referencesFetched: 0}));

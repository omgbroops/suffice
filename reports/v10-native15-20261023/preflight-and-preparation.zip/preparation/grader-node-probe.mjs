import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {gunzipSync} from 'node:zlib';
import {runProcess} from '../../../src/v9/process.mjs';
const root = resolve(import.meta.dirname, '..');
const directory = resolve(root, 'preparation/grader-node-probe');
await mkdir(directory, {recursive: true});
const path = resolve(directory, 'probe.test.mjs');
await writeFile(path, "import test from 'node:test';import assert from 'node:assert/strict';test('local probe',()=>assert.equal(2+2,4));\n");
const out = await runProcess(process.execPath, ['--permission', `--allow-fs-read=${directory}`, '--test-reporter=tap', path],
  {cwd: directory, env: {...process.env, SUFFICE_WORKSPACE: directory, NODE_NO_WARNINGS: '1'}});
if (out.exitCode !== 0 || !/^# tests 1\r?$/m.test(out.stdout)) throw Error(`Node permission TAP probe failed: ${out.stdout} ${out.stderr}`);
const tar = gunzipSync(await readFile(resolve(root, 'preparation/downloads/bytes-3.1.0.tgz')));
const entries = [];
for (let offset = 0; offset + 512 <= tar.length;) {
  const header = tar.subarray(offset, offset + 512);
  if (header.every(byte => byte === 0)) break;
  const name = header.subarray(0, 100).toString().split('\0')[0];
  const type = String.fromCharCode(header[156] || 48);
  const size = Number.parseInt(header.subarray(124, 136).toString().split('\0')[0].trim() || '0', 8);
  entries.push({name, type}); offset += 512 + Math.ceil(size / 512) * 512;
}
await writeFile(resolve(directory, 'probe-results.json'), JSON.stringify({nodeTAP: true, tests: 1, permissionFlagsWork: true, baselineNpmArchiveEntries: entries}, null, 2) + '\n');
console.log(JSON.stringify({nodeTAP: true, tests: 1, baselineTarTypes: [...new Set(entries.map(entry => entry.type))]}));

import test from 'node:test';import assert from 'node:assert/strict';test('local probe',()=>assert.equal(2+2,4));

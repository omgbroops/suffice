# picomatch repair task

Fix picomatch so a globstar (**) matches paths that contain newline or carriage-return characters, e.g. isMatch("hello\nworld", "**") should be true. The original upstream repository/package and its layout are under src/. No dependency installation is needed. Run the public regression checks with node --test tests/public.test.mjs. Preserve original upstream tests, fixtures, documentation, and package metadata.

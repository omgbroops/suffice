# picomatch repair task

Fix picomatch so that ** immediately followed by a literal in the same path segment, such as **.thing.js, behaves like a single * and cannot match across path separators: somepath/test.thing.js must not match **.thing.js, while test.thing.js still does. Do not change how **/ forms or bare ** segments behave. The original upstream repository/package and its layout are under src/. No dependency installation is needed. Run the public regression checks with node --test tests/public.test.mjs. Preserve original upstream tests, fixtures, documentation, and package metadata.

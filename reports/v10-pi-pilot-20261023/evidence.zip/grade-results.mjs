import {readFile,writeFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {gradeBenchmark} from '../../scripts/v10-bench.mjs';
import {hash} from '../../src/v9/workspace.mjs';
const root=resolve('.suffice/v10-pi-pilot-20261023'),evaluation=join(root,'evaluation');
const campaigns=['plan-final','sol-uncapped-restart'];
const closed=[];
for(const name of campaigns){const e=JSON.parse(await readFile(join(root,name,'execution-complete.json'),'utf8'));if(!e.closed)throw Error('Actor campaign remains open');closed.push({campaign:name,at:e.at});}
const expected={
 'development/grade-development.mjs':'2870a60e2460e30db5c439e78494092ea38d0533a43f73d8eef8f452a8b9997c',
 'development/manifest.json':'8a2e0d75326095e43372ffffc05bbbf80d8859109ad2cf809713777c134d9e1e',
 'semver/grade-semver.mjs':'e730c13d23e70b3de22e9377f5f8ffa349ac058cb309f79a0f6ab13beb5f470f',
 'semver/manifest.json':'d17249e6b1e744bcbf9fabe7886790059a69a7f490ef595ae17e44ff04e8de16',
};
for(const [file,sha256] of Object.entries(expected))if(hash(await readFile(join(evaluation,file)))!==sha256)throw Error('Frozen evaluator changed: '+file);
const checks={};for(const id of ['retry','json-lines','build-metadata','prerelease-subset'])checks[id]=[process.execPath,join(evaluation,['retry','json-lines'].includes(id)?'development/grade-development.mjs':'semver/grade-semver.mjs'),id,'{workspace}'];
const config=join(evaluation,'evaluators.json');await writeFile(config,JSON.stringify({checks,timeoutMs:120000},null,2)+'\n',{flag:'wx'});
const startedAt=new Date().toISOString();
await writeFile(join(evaluation,'frozen.json'),JSON.stringify({startedAt,actorsClosed:closed,sha256:expected,evaluatorConfigurationSha256:hash(await readFile(config)),rule:'No actor calls or revisions after independent scoring; original capped and user-requested uncapped restart are separate campaigns.'},null,2)+'\n',{flag:'wx'});
const results=[];
for(const name of campaigns){const grades=await gradeBenchmark(join(root,name),config);results.push({campaign:name,grades:grades.map(({id,status,accepted})=>({id,status,accepted}))});}
for(const [file,sha256] of Object.entries(expected))if(hash(await readFile(join(evaluation,file)))!==sha256)throw Error('Evaluator mutated during grading: '+file);
await writeFile(join(evaluation,'completed.json'),JSON.stringify({startedAt,completedAt:new Date().toISOString(),evaluatorHashesVerified:true,results},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(results,null,2));

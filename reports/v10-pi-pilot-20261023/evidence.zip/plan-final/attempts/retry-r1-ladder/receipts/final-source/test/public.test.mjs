import {test} from 'node:test';import assert from 'node:assert/strict';import {retry} from '../src/retry.mjs';
test('success',async()=>assert.equal(await retry(n=>n),1));
test('retry once',async()=>{let calls=0;assert.equal(await retry(()=>{if(++calls===1)throw Error('again');return 7;}),7);assert.equal(calls,2);});

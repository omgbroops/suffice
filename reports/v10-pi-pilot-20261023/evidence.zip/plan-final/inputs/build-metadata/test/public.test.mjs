import {test} from 'node:test';import assert from 'node:assert/strict';import {createRequire} from 'node:module';const require=createRequire(import.meta.url),semver=require('../src/index.js');
test('ordinary ranges',()=>{assert.equal(semver.satisfies('1.2.3','^1.0.0'),true);assert.equal(semver.satisfies('2.0.0','^1.0.0'),false);});
test('normal prerelease exclusion',()=>assert.equal(semver.satisfies('1.2.3-beta.1','^1.0.0'),false));
test('public issue reproduction',()=>{assert.equal(semver.validRange('4.17.0+'+'a'.repeat(250)+'3',{loose:true}),'4.17.0');});

export async function* parseJsonLines(chunks) { for await (const chunk of chunks) { for (const line of String(chunk).split('\n')) if (line.trim()) yield JSON.parse(line); } }

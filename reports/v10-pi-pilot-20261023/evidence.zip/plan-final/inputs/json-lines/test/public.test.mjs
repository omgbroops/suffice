import {test} from 'node:test';import assert from 'node:assert/strict';import {parseJsonLines} from '../src/json-lines.mjs';const collect=async chunks=>{const out=[];for await(const v of parseJsonLines(chunks))out.push(v);return out;};
test('basic',async()=>assert.deepEqual(await collect(['1\n2\n']),[1,2]));
test('split line',async()=>assert.deepEqual(await collect(['{"a":','1}\n']),[{a:1}]));

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const semver = require('../src')

test('long build metadata never becomes a version component', () => {
  const range = '4.17.0+' + 'a'.repeat(250) + '3'
  for (const loose of [false, true]) {
    assert.equal(semver.validRange(range, { loose }), '4.17.0')
    assert.equal(semver.satisfies('4.17.0', range, { loose }), true)
    assert.equal(semver.satisfies('4.17.3', range, { loose }), false)
    assert.equal(semver.satisfies('4.17.1', range, { loose }), false)
  }
})

test('build metadata does not change any range bounds', () => {
  const templates = [
    '4.17.0BUILD',
    '= 4.17.0BUILD',
    '> 4.17.0BUILD',
    '>=\t4.17.0BUILD < 5.0.0BUILD',
    '<= 4.17.0BUILD',
    '4BUILD',
    '4.17BUILD',
    '4.17.xBUILD',
    '4.x.xBUILD',
    '~ 4.17.0BUILD',
    '~> 4.17BUILD',
    '^ 4.17.0BUILD',
    '^0.0.3BUILD',
    '4.17.0BUILD - 5.0.0BUILD',
    '4.17.xBUILD - 5.0.xBUILD',
    '4.17.0-beta.1BUILD - 5.0.0-rc.2BUILD',
    '^4.17.0-beta.1BUILD',
    '~4.17.0-beta.1BUILD',
    '4.17.0-beta.1BUILD',
    '< 4.17.0-beta.1BUILD || >= 6.0.0BUILD',
    '^4.17.0BUILD || ~6.0.0BUILD',
  ]
  const builds = [
    'short',
    'a'.repeat(250) + '3',
    '3'.repeat(1000),
    'a'.repeat(1000) + '.123.' + 'b'.repeat(1000) + '-3',
  ]
  for (const loose of [false, true]) {
    for (const includePrerelease of [false, true]) {
      const options = { loose, includePrerelease }
      for (const template of templates) {
        const plain = template.replaceAll('BUILD', '')
        const expected = semver.validRange(plain, options)
        assert.notEqual(expected, null, plain)
        for (const build of builds) {
          const range = template.replaceAll('BUILD', '+' + build)
          assert.equal(semver.validRange(range, options), expected,
            `${template}, ${JSON.stringify(options)}, build length ${build.length}`)
        }
      }
    }
  }
})

test('prerelease and strict/loose rules survive long metadata', () => {
  const build = '+' + 'a'.repeat(1000) + '3'
  assert.equal(semver.validRange('04.17.00' + build), null)
  assert.equal(semver.validRange('04.17.00' + build, { loose: true }), '4.17.0')
  assert.equal(semver.validRange('4.17.0beta.1' + build), null)
  assert.equal(semver.validRange('4.17.0beta.1' + build, { loose: true }),
    '4.17.0-beta.1')
  assert.equal(semver.satisfies('4.17.1-beta.1', '^4.17.0' + build), false)
  assert.equal(semver.satisfies('4.17.0-beta.2', '^4.17.0-beta.1' + build), true)
  assert.equal(semver.satisfies('4.17.0-beta.1',
    '4.17.0' + build + ' - 5.0.0', { includePrerelease: true }), true)
  // Range normalization must not relax the length limit on actual versions.
  assert.equal(semver.valid('4.17.0' + build), null)
})

import {readFile,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {hash,captureTree,treeHash} from '../../src/v9/workspace.mjs';
const root=resolve('.suffice/v10-pi-pilot-20261023');
const problems=[],campaigns=[],near=(a,b)=>Math.abs(a-b)<1e-9;
const saved=JSON.parse(await readFile('reports/v10-pi-pilot-20261023/runtime-files.json','utf8'));
for(const [path,expected] of saved.files)if(hash(await readFile(path))!==expected)problems.push('Runtime changed: '+path);
for(const name of ['plan-final','sol-uncapped-restart']){
 const dir=join(root,name),plan=JSON.parse(await readFile(join(dir,'plan.json'),'utf8')),execution=JSON.parse(await readFile(join(dir,'execution-complete.json'),'utf8'));
 const {fingerprint,...body}=plan;if(hash(JSON.stringify(body))!==fingerprint)problems.push('Invalid plan: '+name);
 const tools={},rows=[];let modelRequests=0,totalCost=0,reviewerToolCalls=0;
 for(const a of execution.attempts){
  if(treeHash(await captureTree(a.workspace,{includeIgnored:true}))!==a.sourceHash)problems.push('Mutable source differs: '+a.id);
  if(treeHash(await captureTree(a.snapshot,{includeIgnored:true}))!==a.sourceHash)problems.push('Sealed source differs: '+a.id);
  let cost=0;const usage={inputTokens:0,cachedInputTokens:0,outputTokens:0},navigation={};
  for(let i=0;i<a.stages.length;i++){
   const stage=a.stages[i],stageDir=join(dir,'attempts',a.id,'receipts',`stage-${i+1}-${stage.role}`);
   const events=(await readFile(join(stageDir,'events.jsonl'),'utf8')).split('\n').filter(Boolean).map(JSON.parse);
   let stageCost=0;const stageUsage={inputTokens:0,cachedInputTokens:0,outputTokens:0};
   for(const e of events){
    if(e.type==='request_reservation'){modelRequests++;}
    if(e.type==='assistant'){
     if(e.model!==stage.model||e.provider!=='openai')problems.push('Model identity mismatch: '+a.id);
     if(['error','aborted'].includes(e.stopReason))problems.push('Incomplete assistant receipt: '+a.id);
     stageCost+=e.usage.cost.total;stageUsage.inputTokens+=e.usage.input+e.usage.cacheRead+e.usage.cacheWrite;stageUsage.cachedInputTokens+=e.usage.cacheRead;stageUsage.outputTokens+=e.usage.output;
    }
    if(e.type==='tool_observation'){
     tools[e.tool]=(tools[e.tool]??0)+1;
     if(['symbols','symbol_read','symbol_references'].includes(e.tool))navigation[e.tool]=(navigation[e.tool]??0)+1;
     if(e.compacted)problems.push('Unexpected compaction: '+a.id);
    }
    if(e.type==='observation_recovery')tools.observation_read=(tools.observation_read??0)+1;
   }
   if(!near(stageCost,stage.costUsd))problems.push('Stage cost does not reconcile: '+a.id);
   for(const key of Object.keys(stageUsage))if(stageUsage[key]!==stage.usage[key])problems.push('Stage usage does not reconcile: '+a.id+' '+key);
   if(['test-writer','arbiter'].includes(stage.role))reviewerToolCalls+=stage.toolCalls;
   cost+=stageCost;for(const key of Object.keys(usage))usage[key]+=stageUsage[key];
  }
  if(!near(cost,a.costUsd))problems.push('Attempt cost does not reconcile: '+a.id);
  for(const key of Object.keys(usage))if(usage[key]!==a.usage[key])problems.push('Attempt usage does not reconcile: '+a.id+' '+key);
  totalCost+=cost;rows.push({id:a.id,status:a.status,costUsd:cost,costKnown:a.costKnown,sourceHash:a.sourceHash,navigation});
 }
 if(!near(totalCost,execution.knownCostFloorUsd))problems.push('Campaign cost does not reconcile: '+name);
 campaigns.push({name,closed:execution.closed,closedAt:execution.at,totalCostUsd:totalCost,modelRequests,reviewerToolCalls,tools,attempts:rows});
}
const report={at:new Date().toISOString(),runtimeHash:saved.runtimeHash,runtimeFilesVerified:saved.files.length,problems,campaigns,totalV10ApiEquivalentCostUsd:campaigns.reduce((n,c)=>n+c.totalCostUsd,0)};
await writeFile(join(root,'audit.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));if(problems.length)process.exitCode=1;

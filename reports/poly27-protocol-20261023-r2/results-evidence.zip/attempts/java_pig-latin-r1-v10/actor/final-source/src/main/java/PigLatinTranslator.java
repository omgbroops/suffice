class PigLatinTranslator {
    public String translate(String text) {
        StringBuilder result = new StringBuilder();
        int index = 0;

        while (index < text.length()) {
            if (Character.isWhitespace(text.charAt(index))) {
                result.append(text.charAt(index++));
                continue;
            }

            int end = index;
            while (end < text.length() && !Character.isWhitespace(text.charAt(end))) {
                end++;
            }
            result.append(translateToken(text.substring(index, end)));
            index = end;
        }

        return result.toString();
    }

    private String translateToken(String token) {
        int start = 0;
        while (start < token.length() && !isLetter(token.charAt(start))) {
            start++;
        }
        int end = token.length();
        while (end > start && !isLetter(token.charAt(end - 1))) {
            end--;
        }

        if (start == end) {
            return token;
        }

        String prefix = token.substring(0, start);
        String word = token.substring(start, end);
        String suffix = token.substring(end);
        return prefix + translateWord(word) + suffix;
    }

    private String translateWord(String word) {
        String lower = word.toLowerCase(java.util.Locale.ROOT);
        int clusterEnd;

        if (lower.startsWith("xr") || lower.startsWith("yt") || isVowel(lower.charAt(0))) {
            clusterEnd = 0;
        } else {
            clusterEnd = 0;
            while (clusterEnd < lower.length()) {
                if (clusterEnd > 0 && lower.charAt(clusterEnd) == 'u'
                        && lower.charAt(clusterEnd - 1) == 'q') {
                    clusterEnd++;
                    break;
                }
                if (clusterEnd > 0 && lower.charAt(clusterEnd) == 'y') {
                    break;
                }
                if (isVowel(lower.charAt(clusterEnd))) {
                    break;
                }
                clusterEnd++;
            }
        }

        return word.substring(clusterEnd) + word.substring(0, clusterEnd) + "ay";
    }

    private boolean isVowel(char character) {
        return character == 'a' || character == 'e' || character == 'i'
                || character == 'o' || character == 'u';
    }

    private boolean isLetter(char character) {
        return character >= 'a' && character <= 'z'
                || character >= 'A' && character <= 'Z';
    }
}

package say

var ones = [...]string{
	"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
	"ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen",
}

var tens = [...]string{
	"", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety",
}

// Say returns the English name of n. The boolean is false when n is outside
// the exercise's supported range.
func Say(n int64) (string, bool) {
	if n < 0 || n > 999_999_999_999 {
		return "", false
	}
	if n == 0 {
		return "zero", true
	}

	scales := [...]struct {
		value int64
		name  string
	}{
		{1_000_000_000, "billion"},
		{1_000_000, "million"},
		{1_000, "thousand"},
	}

	parts := make([]string, 0, 7)
	for _, scale := range scales {
		chunk := n / scale.value
		if chunk != 0 {
			parts = append(parts, spellUnderThousand(chunk)+" "+scale.name)
			n %= scale.value
		}
	}
	if n != 0 {
		parts = append(parts, spellUnderThousand(n))
	}
	result := parts[0]
	for _, part := range parts[1:] {
		result += " " + part
	}
	return result, true
}

func spellUnderThousand(n int64) string {
	var result string
	if n >= 100 {
		result = ones[n/100] + " hundred"
		n %= 100
		if n != 0 {
			result += " "
		}
	}
	if n >= 20 {
		result += tens[n/10]
		if n%10 != 0 {
			result += "-" + ones[n%10]
		}
	} else if n > 0 {
		result += ones[n]
	}
	return result
}

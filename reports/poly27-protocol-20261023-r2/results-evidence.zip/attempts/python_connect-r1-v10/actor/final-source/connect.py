"""Determine the winner of a Hex (Connect) board."""


class ConnectGame:
    def __init__(self, board):
        # A board may be supplied as a sequence of rows or as the multiline
        # diagram used in the exercise description. Spaces are formatting only.
        rows = board.splitlines() if isinstance(board, str) else board
        self.board = [
            [cell for cell in str(row) if cell in ".OX"]
            for row in rows
        ]

    def _connected(self, player):
        """Return whether player has a path between its assigned edges."""
        if not self.board:
            return False

        height = len(self.board)
        starts = []
        target = set()

        if player == "O":
            starts = [(0, col) for col, cell in enumerate(self.board[0]) if cell == player]
            target = {(height - 1, col) for col, cell in enumerate(self.board[-1]) if cell == player}
        else:
            starts = [(row, 0) for row, cells in enumerate(self.board) if cells and cells[0] == player]
            target = {(row, len(cells) - 1) for row, cells in enumerate(self.board)
                      if cells and cells[-1] == player}

        visited = set(starts)
        stack = list(starts)
        while stack:
            row, col = stack.pop()
            if (row, col) in target:
                return True
            for neighbor in (
                (row, col - 1), (row, col + 1),
                (row - 1, col), (row - 1, col + 1),
                (row + 1, col), (row + 1, col - 1),
            ):
                r, c = neighbor
                if (0 <= r < height and 0 <= c < len(self.board[r])
                        and self.board[r][c] == player and neighbor not in visited):
                    visited.add(neighbor)
                    stack.append(neighbor)
        return False

    def get_winner(self):
        if self._connected("O"):
            return "O"
        if self._connected("X"):
            return "X"
        return ""

//
// This is only a SKELETON file for the 'Alphametics' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export const solve = (puzzle) => {
  const equation = puzzle.match(
    /^\s*([A-Z]+(?:\s*\+\s*[A-Z]+)*)\s*={1,2}\s*([A-Z]+)\s*$/,
  );
  if (!equation) return null;

  const addends = equation[1].split(/\s*\+\s*/);
  const result = equation[2];
  const words = [...addends, result];
  const letters = new Set(words.join(''));
  if (letters.size > 10 || addends.some((word) => word.length > result.length)) {
    return null;
  }

  const leading = new Set(
    words.filter((word) => word.length > 1).map((word) => word[0]),
  );
  const assignment = {};
  const used = new Set();

  // Count repeated letters so each column assigns a letter only once.
  const columns = Array.from({ length: result.length }, (_, column) => {
    const counts = new Map();
    for (const word of addends) {
      const letter = word[word.length - 1 - column];
      if (letter !== undefined) {
        counts.set(letter, (counts.get(letter) || 0) + 1);
      }
    }
    return [...counts];
  });

  const search = (column, index, sum) => {
    if (column === result.length) return sum === 0;

    const terms = columns[column];
    if (index < terms.length) {
      const [letter, count] = terms[index];
      if (assignment[letter] !== undefined) {
        return search(column, index + 1, sum + count * assignment[letter]);
      }

      for (let digit = 0; digit <= 9; digit += 1) {
        if (used.has(digit) || (digit === 0 && leading.has(letter))) continue;
        assignment[letter] = digit;
        used.add(digit);
        if (search(column, index + 1, sum + count * digit)) return true;
        used.delete(digit);
        delete assignment[letter];
      }
      return false;
    }

    const letter = result[result.length - 1 - column];
    const digit = sum % 10;
    const carry = Math.floor(sum / 10);
    if (assignment[letter] !== undefined) {
      return assignment[letter] === digit && search(column + 1, 0, carry);
    }
    if (used.has(digit) || (digit === 0 && leading.has(letter))) return false;

    assignment[letter] = digit;
    used.add(digit);
    if (search(column + 1, 0, carry)) return true;
    used.delete(digit);
    delete assignment[letter];
    return false;
  };

  return search(0, 0, 0) ? assignment : null;
};

import { solve } from '../alphametics.js';

const expectSolution = (puzzle) => {
  const solution = solve(puzzle);
  expect(solution).not.toBeNull();
  const words = puzzle.match(/[A-Z]+/g);
  const letters = [...new Set(words.join(''))];
  expect(Object.keys(solution).sort()).toEqual(letters.sort());
  expect(new Set(Object.values(solution)).size).toBe(letters.length);
  for (const digit of Object.values(solution)) {
    expect(Number.isInteger(digit)).toBe(true);
    expect(digit).toBeGreaterThanOrEqual(0);
    expect(digit).toBeLessThanOrEqual(9);
  }
  for (const word of words) {
    if (word.length > 1) expect(solution[word[0]]).not.toBe(0);
  }
  const numbers = words.map((word) =>
    BigInt([...word].map((letter) => solution[letter]).join('')),
  );
  const result = numbers.pop();
  expect(numbers.reduce((sum, value) => sum + value, 0n)).toBe(result);
  return solution;
};

test('solves SEND + MORE = MONEY with the known unique assignment', () => {
  expect(expectSolution('SEND + MORE = MONEY')).toEqual({
    S: 9, E: 5, N: 6, D: 7, M: 1, O: 0, R: 8, Y: 2,
  });
});

test.each([
  'I + BB == ILL',
  'TWO + TWO = FOUR',
  'THIS + IS + TOO = FUNNY',
  'HE + SEES + THE = LIGHT',
  'COUPLE + COUPLE = QUARTET',
  'ELEVEN + NINE + FIVE + FIVE = THIRTY',
  'AND + A + STRONG + OFFENSE + AS + A + GOOD = DEFENSE',
  'A + B = C',
  'A + B = A',
  '  A+B==C  ',
])('returns a valid assignment for %s', (puzzle) => {
  expectSolution(puzzle);
});

test('allows zero for a single-letter word', () => {
  expect(solve('A + A = A')).toEqual({ A: 0 });
});

test('handles carries greater than nine', () => {
  expectSolution(`${Array(20).fill('A').join(' + ')} = BC`);
});

test('handles words beyond the safe integer range', () => {
  expectSolution(`${'A'.repeat(30)} + B = ${'A'.repeat(29)}C`);
});

test.each([
  'A = B',
  'A + B = BA',
  'AA + B = A',
  'AAA + AAA = AAAA',
  'A + B = AA',
  'ABCDEFGHIJ + K = ABCDEFGHIJ',
])('returns null when no assignment exists for %s', (puzzle) => {
  expect(solve(puzzle)).toBeNull();
});

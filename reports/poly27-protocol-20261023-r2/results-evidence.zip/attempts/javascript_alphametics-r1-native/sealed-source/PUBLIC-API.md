# Public interface

solve(puzzle: string): Record<string, number> | null. Return the letter-to-digit assignment, or null when no solution exists.

from itertools import product

import pytest

from connect import ConnectGame


@pytest.mark.parametrize(
    "board, expected",
    [
        ("", ""),
        (".", ""),
        ("X", "X"),
        ("O", "O"),
        (". . .\n . . .\n  . . .", ""),
        ("X X X", "X"),
        ("O O O", "O"),
        ("X . X", ""),
        ("O\n O\n  O", "O"),
        ("X\n X\n  X", "X"),
        ("O\n .\n  O", ""),
        ("O O\n . .", ""),
        ("X .\n X .", ""),
        (". X\n X .", "X"),
        (". O\n O .", "O"),
        ("X .\n . X", ""),
        ("O .\n . O", ""),
        (". . . .\n X X X X", "X"),
        ("O .\n O .\n O .\n O .", "O"),
        ("\n  .\tX\n   X .\n", "X"),
        (". O . X .\n . X X O .\n  O O O X .\n   . X O X O\n    X O O O X", ""),
    ],
)
def test_public_examples_and_edges(board, expected):
    game = ConnectGame(board)
    assert game.get_winner() == expected
    assert game.get_winner() == expected


def component_winner(cells, height, width):
    """Independent reference: merge touching stones, then compare edge roots."""
    parents = list(range(len(cells)))

    def root(index):
        while parents[index] != index:
            index = parents[index]
        return index

    for row in range(height):
        for column in range(width):
            index = row * width + column
            # Each undirected edge appears once, using only forward neighbors.
            for next_row, next_column in (
                (row, column + 1),
                (row + 1, column),
                (row + 1, column - 1),
            ):
                if next_row < height and 0 <= next_column < width:
                    other = next_row * width + next_column
                    if cells[index] == cells[other]:
                        parents[root(index)] = root(other)

    for player, start, finish in (
        ("X", range(0, len(cells), width), range(width - 1, len(cells), width)),
        ("O", range(width), range((height - 1) * width, len(cells))),
    ):
        start_roots = {root(index) for index in start if cells[index] == player}
        finish_roots = {root(index) for index in finish if cells[index] == player}
        if start_roots & finish_roots:
            return player
    return ""


@pytest.mark.parametrize("height, width", [(1, 4), (4, 1), (2, 3), (3, 2)])
def test_all_small_rectangular_boards(height, width):
    for cells in product(".XO", repeat=height * width):
        board = "\n".join(
            " " * row + " ".join(cells[row * width : (row + 1) * width])
            for row in range(height)
        )
        assert ConnectGame(board).get_winner() == component_winner(cells, height, width), board


def test_large_connections_do_not_require_recursion():
    assert ConnectGame(" ".join("X" * 2000)).get_winner() == "X"
    assert ConnectGame("\n".join("O" * 2000)).get_winner() == "O"

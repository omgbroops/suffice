class ConnectGame:
    def __init__(self, board):
        self.board = [
            "".join(row.split()) for row in board.splitlines() if row.strip()
        ]

    def get_winner(self):
        if not self.board or not self.board[0]:
            return ""

        height, width = len(self.board), len(self.board[0])
        neighbors = ((-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0))

        for player in ("X", "O"):
            edge = (
                ((row, 0) for row in range(height))
                if player == "X"
                else ((0, column) for column in range(width))
            )
            pending = [
                (row, column)
                for row, column in edge
                if self.board[row][column] == player
            ]
            visited = set(pending)

            while pending:
                row, column = pending.pop()
                if (player == "X" and column == width - 1) or (
                    player == "O" and row == height - 1
                ):
                    return player

                for row_delta, column_delta in neighbors:
                    next_row, next_column = row + row_delta, column + column_delta
                    position = (next_row, next_column)
                    if (
                        0 <= next_row < height
                        and 0 <= next_column < width
                        and position not in visited
                        and self.board[next_row][next_column] == player
                    ):
                        visited.add(position)
                        pending.append(position)

        return ""

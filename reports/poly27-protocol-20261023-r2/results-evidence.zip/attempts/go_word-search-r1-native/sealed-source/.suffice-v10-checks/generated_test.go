package wordsearch

import "testing"

func TestAllEightDirections(t *testing.T) {
	for _, direction := range []struct {
		name   string
		dx, dy int
	}{
		{"east", 1, 0}, {"west", -1, 0},
		{"south", 0, 1}, {"north", 0, -1},
		{"southeast", 1, 1}, {"southwest", -1, 1},
		{"northeast", 1, -1}, {"northwest", -1, -1},
	} {
		t.Run(direction.name, func(t *testing.T) {
			grid := make([][]rune, 5)
			for row := range grid {
				grid[row] = []rune("xxxxx")
			}
			for i, letter := range "cat" {
				grid[2+i*direction.dy][2+i*direction.dx] = letter
			}
			puzzle := make([]string, len(grid))
			for row := range grid {
				puzzle[row] = string(grid[row])
			}
			got, err := Solve([]string{"cat"}, puzzle)
			want := [2][2]int{{2, 2}, {2 + 2*direction.dx, 2 + 2*direction.dy}}
			if err != nil || len(got) != 1 || got["cat"] != want {
				t.Fatalf("Solve = %v, %v; want cat at %v", got, err, want)
			}
		})
	}
}

func TestExampleAndMultipleWords(t *testing.T) {
	puzzle := []string{
		"jefblpepre", "camdcimgtc", "oivokprjsm", "pbwasqroua", "rixilelhrs",
		"wolcqlirpc", "screeaumgr", "alxhpburyi", "jalaycalmp", "clojurermt",
	}
	want := map[string][2][2]int{
		"clojure": {{0, 9}, {6, 9}},
		"java":    {{0, 0}, {3, 3}},
		"elixir":  {{5, 4}, {0, 4}},
	}
	got, err := Solve([]string{"clojure", "java", "elixir"}, puzzle)
	if err != nil || len(got) != len(want) {
		t.Fatalf("Solve = %v, %v; want %v", got, err, want)
	}
	for word, location := range want {
		if got[word] != location {
			t.Errorf("%s at %v; want %v", word, got[word], location)
		}
	}
}

func TestSingleLetterAndRectangularPuzzle(t *testing.T) {
	got, err := Solve([]string{"f", "def"}, []string{"abc", "def"})
	if err != nil || len(got) != 2 || got["f"] != [2][2]int{{2, 1}, {2, 1}} || got["def"] != [2][2]int{{0, 1}, {2, 1}} {
		t.Fatalf("unexpected result: %v, %v", got, err)
	}
}

func TestMissingWords(t *testing.T) {
	for _, tc := range []struct {
		name   string
		word   string
		puzzle []string
	}{
		{"absent", "z", []string{"abc", "def", "ghi"}},
		{"too long", "abcd", []string{"abc", "def", "ghi"}},
		{"no wrapping", "cde", []string{"abc", "def", "ghi"}},
		{"no turning", "abe", []string{"abc", "def", "ghi"}},
		{"no reuse", "aaa", []string{"ab", "cd"}},
		{"empty puzzle", "a", nil},
	} {
		t.Run(tc.name, func(t *testing.T) {
			if got, err := Solve([]string{tc.word}, tc.puzzle); err == nil {
				t.Fatalf("Solve = %v, nil; want an error", got)
			}
		})
	}
}

func TestNoRequestedWords(t *testing.T) {
	got, err := Solve(nil, []string{"abc", "def", "ghi"})
	if err != nil || len(got) != 0 {
		t.Fatalf("Solve = %v, %v; want no locations and no error", got, err)
	}
}

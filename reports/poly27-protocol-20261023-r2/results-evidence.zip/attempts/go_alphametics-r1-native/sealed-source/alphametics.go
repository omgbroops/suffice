package alphametics

import (
	"errors"
	"strings"
	"unicode"
)

func Solve(puzzle string) (map[string]int, error) {
	sides := strings.Split(puzzle, "==")
	if len(sides) != 2 {
		return nil, errors.New("puzzle must contain exactly one == operator")
	}

	letters := make(map[rune]int)
	var leading []bool
	parseWord := func(text string) ([]int, error) {
		word := []rune(strings.TrimSpace(text))
		if len(word) == 0 {
			return nil, errors.New("puzzle contains an empty word")
		}
		ids := make([]int, len(word))
		for i, letter := range word {
			if !unicode.IsLetter(letter) {
				return nil, errors.New("words must contain only letters")
			}
			id, found := letters[letter]
			if !found {
				id = len(letters)
				if id == 10 {
					return nil, errors.New("more than ten distinct letters")
				}
				letters[letter] = id
				leading = append(leading, false)
			}
			ids[i] = id
		}
		if len(ids) > 1 {
			leading[ids[0]] = true
		}
		return ids, nil
	}

	var addends [][]int
	width := 0
	for _, text := range strings.Split(sides[0], "+") {
		word, err := parseWord(text)
		if err != nil {
			return nil, err
		}
		addends = append(addends, word)
		if len(word) > width {
			width = len(word)
		}
	}
	result, err := parseWord(sides[1])
	if err != nil {
		return nil, err
	}
	if len(result) > width {
		width = len(result)
	}

	// Store each column from right to left, omitting missing addend digits.
	columns := make([][]int, width)
	for _, word := range addends {
		for column := 0; column < len(word); column++ {
			columns[column] = append(columns[column], word[len(word)-1-column])
		}
	}
	digits := make([]int, len(letters))
	for i := range digits {
		digits[i] = -1
	}
	var used [10]bool
	var search func(column, row, total int) bool
	search = func(column, row, total int) bool {
		if column == width {
			return total == 0
		}
		if row < len(columns[column]) {
			id := columns[column][row]
			if digits[id] >= 0 {
				return search(column, row+1, total+digits[id])
			}
			for digit := 0; digit < 10; digit++ {
				if used[digit] || (digit == 0 && leading[id]) {
					continue
				}
				digits[id], used[digit] = digit, true
				if search(column, row+1, total+digit) {
					return true
				}
				digits[id], used[digit] = -1, false
			}
			return false
		}

		// The sum determines the result digit and the carry exactly.
		digit, carry := total%10, total/10
		if column >= len(result) {
			return digit == 0 && search(column+1, 0, carry)
		}
		id := result[len(result)-1-column]
		if digits[id] >= 0 {
			return digits[id] == digit && search(column+1, 0, carry)
		}
		if used[digit] || (digit == 0 && leading[id]) {
			return false
		}
		digits[id], used[digit] = digit, true
		if search(column+1, 0, carry) {
			return true
		}
		digits[id], used[digit] = -1, false
		return false
	}
	if !search(0, 0, 0) {
		return nil, errors.New("puzzle has no solution")
	}

	solution := make(map[string]int, len(letters))
	for letter, id := range letters {
		solution[string(letter)] = digits[id]
	}
	return solution, nil
}

package alphametics

import (
	"math/big"
	"reflect"
	"strings"
	"testing"
)

func TestSendMoreMoney(t *testing.T) {
	got, err := Solve("SEND + MORE == MONEY")
	want := map[string]int{"M": 1, "O": 0, "N": 6, "E": 5, "Y": 2, "S": 9, "D": 7, "R": 8}
	if err != nil || !reflect.DeepEqual(got, want) {
		t.Fatalf("Solve returned %v, %v; want %v, nil", got, err, want)
	}
}

func TestSolutionsSatisfyPuzzle(t *testing.T) {
	puzzles := []string{
		"A == A",
		"A+B==B",
		"AA + B == AA",
		"I + BB == ILL",
		"AS + A == MOM",
		"NO + NO + TOO == LATE",
		"HE + SEES + THE == LIGHT",
		"DONALD + GERALD == ROBERT",
		"ELEVEN + NINE + FIVE + FIVE == THIRTY",
		"SATURN + URANUS + NEPTUNE + PLUTO == PLANETS",
		"AND + A + STRONG + OFFENSE + AS + A + GOOD == DEFENSE",
		strings.Repeat("A + ", 19) + "A == BC",
		strings.Repeat("A", 50) + " == " + strings.Repeat("A", 50),
	}
	for _, puzzle := range puzzles {
		t.Run(puzzle, func(t *testing.T) {
			solution, err := Solve(puzzle)
			if err != nil {
				t.Fatalf("expected a solution: %v", err)
			}
			seen := make(map[int]string)
			for letter, digit := range solution {
				if digit < 0 || digit > 9 {
					t.Fatalf("invalid digit %d for %s", digit, letter)
				}
				if other, exists := seen[digit]; exists {
					t.Fatalf("%s and %s both use %d", letter, other, digit)
				}
				seen[digit] = letter
			}
			letters := make(map[string]bool)
			value := func(text string) *big.Int {
				word := []rune(strings.TrimSpace(text))
				n := new(big.Int)
				for i, letter := range word {
					key := string(letter)
					letters[key] = true
					digit, exists := solution[key]
					if !exists {
						t.Fatalf("missing letter %s", key)
					}
					if i == 0 && len(word) > 1 && digit == 0 {
						t.Fatalf("leading zero in %s", text)
					}
					n.Mul(n, big.NewInt(10))
					n.Add(n, big.NewInt(int64(digit)))
				}
				return n
			}
			sides := strings.Split(puzzle, "==")
			sum := new(big.Int)
			for _, word := range strings.Split(sides[0], "+") {
				sum.Add(sum, value(word))
			}
			result := value(sides[1])
			if sum.Cmp(result) != 0 {
				t.Fatalf("%v gives %s != %s", solution, sum, result)
			}
			if len(solution) != len(letters) {
				t.Fatalf("solution contains unexpected letters: %v", solution)
			}
		})
	}
}

func TestImpossiblePuzzles(t *testing.T) {
	for _, puzzle := range []string{
		"A == B",
		"A + B == AA",
		"A == AA",
		"AAA + AAA == AAA",
		"AA + BB == A",
		"AB + AB == AB",
		"ABCDEFGHIJK == ABCDEFGHIJK",
	} {
		t.Run(puzzle, func(t *testing.T) {
			if got, err := Solve(puzzle); err == nil {
				t.Fatalf("expected no solution, got %v", got)
			}
		})
	}
}

func TestMalformedPuzzles(t *testing.T) {
	for _, puzzle := range []string{"", "A = B", "A == B == C", "A + == B", "A ==", "A1 == A"} {
		if got, err := Solve(puzzle); err == nil {
			t.Errorf("Solve(%q) = %v, nil; expected an error", puzzle, got)
		}
	}
}

//
// This is only a SKELETON file for the 'Grade School' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class GradeSchool {
  constructor() {
    this.students = new Map();
  }

  roster() {
    const roster = {};
    const grades = new Map();

    for (const [student, grade] of this.students) {
      if (!grades.has(grade)) grades.set(grade, []);
      grades.get(grade).push(student);
    }

    for (const grade of [...grades.keys()].sort((a, b) => a - b)) {
      roster[grade] = grades.get(grade).sort();
    }

    return roster;
  }

  add(student, grade) {
    this.students.set(student, grade);
  }

  grade(grade) {
    return [...this.students]
      .filter(([, studentGrade]) => studentGrade === grade)
      .map(([student]) => student)
      .sort();
  }
}

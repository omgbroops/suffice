package alphametics

import (
	"errors"
	"strings"
	"unicode"
)

// Solve finds a digit assignment that makes the addition represented by puzzle
// true. Each distinct letter receives a distinct decimal digit.
func Solve(puzzle string) (map[string]int, error) {
	parts := strings.Split(puzzle, "==")
	if len(parts) != 2 {
		return nil, errors.New("alphametics: puzzle must contain exactly one ==")
	}

	left := strings.TrimSpace(parts[0])
	resultText := strings.TrimSpace(parts[1])
	rawAddends := strings.Split(left, "+")
	if resultText == "" || len(rawAddends) == 0 {
		return nil, errors.New("alphametics: empty word")
	}

	parseWord := func(s string) ([]rune, error) {
		s = strings.TrimSpace(s)
		if s == "" {
			return nil, errors.New("alphametics: empty word")
		}
		word := []rune(s)
		for _, r := range word {
			if !unicode.IsLetter(r) {
				return nil, errors.New("alphametics: words must contain only letters")
			}
		}
		return word, nil
	}

	addends := make([][]rune, len(rawAddends))
	for i, raw := range rawAddends {
		word, err := parseWord(raw)
		if err != nil {
			return nil, err
		}
		addends[i] = word
	}
	result, err := parseWord(resultText)
	if err != nil {
		return nil, err
	}

	letters := make(map[rune]bool)
	leading := make(map[rune]bool)
	maxColumns := len(result)
	for _, word := range addends {
		if len(word) > maxColumns {
			maxColumns = len(word)
		}
	}
	for _, word := range append(append([][]rune{}, addends...), result) {
		for _, r := range word {
			letters[r] = true
		}
		if len(word) > 1 {
			leading[word[0]] = true
		}
	}
	if len(letters) > 10 {
		return nil, errors.New("alphametics: more than ten distinct letters")
	}

	assignment := make(map[rune]int, len(letters))
	used := [10]bool{}

	var solveColumn func(column, carry int) bool
	solveColumn = func(column, carry int) bool {
		if column == maxColumns {
			return carry == 0
		}

		// Assign the letters in this column of every addend, then check the
		// required result digit. Repeated letters naturally share assignments.
		var addColumn func(index, sum int) bool
		addColumn = func(index, sum int) bool {
			if index == len(addends) {
				total := sum + carry
				digit := total % 10
				nextCarry := total / 10
				if column >= len(result) {
					return digit == 0 && solveColumn(column+1, nextCarry)
				}
				r := result[len(result)-1-column]
				if value, ok := assignment[r]; ok {
					return value == digit && solveColumn(column+1, nextCarry)
				}
				if used[digit] || (digit == 0 && leading[r]) {
					return false
				}
				assignment[r] = digit
				used[digit] = true
				if solveColumn(column+1, nextCarry) {
					return true
				}
				delete(assignment, r)
				used[digit] = false
				return false
			}

			word := addends[index]
			if column >= len(word) {
				return addColumn(index+1, sum)
			}
			r := word[len(word)-1-column]
			if value, ok := assignment[r]; ok {
				return addColumn(index+1, sum+value)
			}
			for digit := 0; digit <= 9; digit++ {
				if used[digit] || (digit == 0 && leading[r]) {
					continue
				}
				assignment[r] = digit
				used[digit] = true
				if addColumn(index+1, sum+digit) {
					return true
				}
				delete(assignment, r)
				used[digit] = false
			}
			return false
		}
		return addColumn(0, 0)
	}

	if !solveColumn(0, 0) {
		return nil, errors.New("alphametics: puzzle has no solution")
	}
	answer := make(map[string]int, len(assignment))
	for letter, digit := range assignment {
		answer[string(letter)] = digit
	}
	return answer, nil
}

#include "catch.hpp"
#include "all_your_base.h"

#include <limits>
#include <stdexcept>
#include <vector>

using all_your_base::convert;
using Digits = std::vector<unsigned int>;

TEST_CASE("Equivalent positional representations") {
    REQUIRE(convert(2, {1, 0, 1, 0, 1, 0}, 10) == Digits{4, 2});
    REQUIRE(convert(10, {4, 2}, 2) == Digits{1, 0, 1, 0, 1, 0});
    REQUIRE(convert(3, {1, 1, 2, 0}, 10) == Digits{4, 2});
    REQUIRE(convert(2, {1}, 10) == Digits{1});
    REQUIRE(convert(16, {10, 11, 12}, 10) == Digits{2, 7, 4, 8});
    REQUIRE(convert(10, {2, 7, 4, 8}, 16) == Digits{10, 11, 12});
    REQUIRE(convert(7, {6, 0, 5}, 7) == Digits{6, 0, 5});
}

TEST_CASE("Zero and leading zeros are normalized") {
    REQUIRE(convert(2, {}, 10).empty());
    REQUIRE(convert(10, {0}, 2).empty());
    REQUIRE(convert(10, {0, 0, 0}, 2).empty());
    REQUIRE(convert(10, {0, 0, 4, 2}, 10) == Digits{4, 2});
    REQUIRE(convert(2, {0, 0, 1, 0}, 10) == Digits{2});
}

TEST_CASE("Invalid bases are rejected even for empty input") {
    for (unsigned int base : {0u, 1u}) {
        REQUIRE_THROWS_AS(convert(base, {}, 10), std::invalid_argument);
        REQUIRE_THROWS_AS(convert(10, {}, base), std::invalid_argument);
        REQUIRE_THROWS_AS(convert(base, {0}, 10), std::invalid_argument);
        REQUIRE_THROWS_AS(convert(10, {0}, base), std::invalid_argument);
    }
}

TEST_CASE("Every input digit must belong to its base") {
    REQUIRE_THROWS_AS(convert(2, {2}, 10), std::invalid_argument);
    REQUIRE_THROWS_AS(convert(10, {1, 10, 0}, 2), std::invalid_argument);
    REQUIRE_THROWS_AS(convert(2, {0, 0, 3}, 10), std::invalid_argument);
    REQUIRE_THROWS_AS(convert(10, {static_cast<unsigned int>(-1)}, 2),
                      std::invalid_argument);
}

TEST_CASE("Numbers larger than machine integers retain all digits") {
    Digits binary(101, 0);
    binary.front() = 1;
    const Digits decimal{1, 2, 6, 7, 6, 5, 0, 6, 0, 0, 2, 2, 8,
                         2, 2, 9, 4, 0, 1, 4, 9, 6, 7, 0, 3, 2,
                         0, 5, 3, 7, 6};
    REQUIRE(convert(2, binary, 10) == decimal);
    REQUIRE(convert(10, decimal, 2) == binary);
}

TEST_CASE("Large bases do not overflow intermediate arithmetic") {
    const auto base = std::numeric_limits<unsigned int>::max();
    REQUIRE(convert(base, {base - 1, base - 1}, base - 1) == Digits{1, 2, 0});
    REQUIRE(convert(base - 1, {1, 2, 0}, base) == Digits{base - 1, base - 1});
}

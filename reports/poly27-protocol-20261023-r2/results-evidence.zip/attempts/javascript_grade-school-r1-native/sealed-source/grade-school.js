//
// This is only a SKELETON file for the 'Grade School' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class GradeSchool {
  constructor() {
    this.students = new Map();
  }

  roster() {
    const roster = {};

    for (const [student, grade] of this.students) {
      if (!roster[grade]) {
        roster[grade] = [];
      }
      roster[grade].push(student);
    }

    for (const students of Object.values(roster)) {
      students.sort();
    }

    return roster;
  }

  add(student, grade) {
    this.students.set(student, grade);
  }

  grade(grade) {
    return [...this.students]
      .filter(([, studentGrade]) => studentGrade === grade)
      .map(([student]) => student)
      .sort();
  }
}

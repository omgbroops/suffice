import { GradeSchool } from '../grade-school.js';

test('a new school has an empty roster and empty grades', () => {
  const school = new GradeSchool();
  expect(school.roster()).toEqual({});
  expect(school.grade(2)).toEqual([]);
  expect(school.roster()).toEqual({});
});

test('adding students groups them by grade and sorts names and grades', () => {
  const school = new GradeSchool();
  expect(school.add('Jim', 10)).toBeUndefined();
  school.add('Zoe', 2);
  school.add('Charlie', 1);
  school.add('Alex', 2);
  school.add('Barb', 1);
  school.add('Anna', 1);
  school.add('Peter', 2);

  expect(school.grade(1)).toEqual(['Anna', 'Barb', 'Charlie']);
  expect(school.grade(2)).toEqual(['Alex', 'Peter', 'Zoe']);
  expect(school.grade(3)).toEqual([]);
  expect(school.roster()).toEqual({
    1: ['Anna', 'Barb', 'Charlie'],
    2: ['Alex', 'Peter', 'Zoe'],
    10: ['Jim'],
  });
  expect(Object.keys(school.roster())).toEqual(['1', '2', '10']);
});

test('adding the same student to the same grade does not duplicate them', () => {
  const school = new GradeSchool();
  school.add('Jim', 2);
  school.add('Jim', 2);
  expect(school.grade(2)).toEqual(['Jim']);
  expect(school.roster()).toEqual({ 2: ['Jim'] });
});

test('adding an existing student updates their grade and removes empty grades', () => {
  const school = new GradeSchool();
  school.add('Jim', 2);
  school.add('Anna', 1);
  expect(school.add('Jim', 1)).toBeUndefined();
  expect(school.grade(2)).toEqual([]);
  expect(school.grade(1)).toEqual(['Anna', 'Jim']);
  expect(school.roster()).toEqual({ 1: ['Anna', 'Jim'] });
});

test('moving a student preserves other students in the previous grade', () => {
  const school = new GradeSchool();
  school.add('Jim', 2);
  school.add('Alex', 2);
  school.add('Jim', 5);
  expect(school.roster()).toEqual({ 2: ['Alex'], 5: ['Jim'] });
});

test('returned grades and rosters cannot mutate stored enrollment', () => {
  const school = new GradeSchool();
  school.add('Jim', 2);
  const grade = school.grade(2);
  const roster = school.roster();
  grade.push('Anna');
  roster[2].push('Barb');
  roster[3] = ['Zoe'];
  expect(school.grade(2)).toEqual(['Jim']);
  expect(school.roster()).toEqual({ 2: ['Jim'] });

  school.add('Alex', 2);
  expect(grade).toEqual(['Jim', 'Anna']);
  expect(roster[2]).toEqual(['Jim', 'Barb']);
});

test('school instances keep separate enrollments', () => {
  const first = new GradeSchool();
  const second = new GradeSchool();
  first.add('Jim', 2);
  expect(second.roster()).toEqual({});
  second.add('Jim', 3);
  expect(first.grade(2)).toEqual(['Jim']);
  expect(second.roster()).toEqual({ 3: ['Jim'] });
});

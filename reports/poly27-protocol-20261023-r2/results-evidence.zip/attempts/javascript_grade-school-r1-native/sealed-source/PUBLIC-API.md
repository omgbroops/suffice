# Public interface

new GradeSchool(). add(student: string, grade: number): void. grade(grade: number): string[] returns alphabetically sorted students. roster(): Record<number, string[]> groups students by grade. A student has one grade; adding the same student again updates that grade.

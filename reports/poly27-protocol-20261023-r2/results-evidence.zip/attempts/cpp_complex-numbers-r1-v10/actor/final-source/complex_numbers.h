#if !defined(COMPLEX_NUMBERS_H)
#define COMPLEX_NUMBERS_H

#include <iosfwd>

namespace complex_numbers {

class Complex {
 public:
  Complex(double real, double imaginary);

  Complex operator+(const Complex& other) const;
  Complex operator-(const Complex& other) const;
  Complex operator*(const Complex& other) const;
  Complex operator/(const Complex& other) const;

  double abs() const;
  Complex conj() const;
  double real() const;
  double imag() const;
  Complex exp() const;

 private:
  double real_;
  double imaginary_;
};

bool operator==(const Complex& lhs, const Complex& rhs);
std::ostream& operator<<(std::ostream& out, const Complex& value);

Complex operator+(const Complex& lhs, double rhs);
Complex operator+(double lhs, const Complex& rhs);
Complex operator-(const Complex& lhs, double rhs);
Complex operator-(double lhs, const Complex& rhs);
Complex operator*(const Complex& lhs, double rhs);
Complex operator*(double lhs, const Complex& rhs);
Complex operator/(const Complex& lhs, double rhs);
Complex operator/(double lhs, const Complex& rhs);

}  // namespace complex_numbers

#endif  // COMPLEX_NUMBERS_H

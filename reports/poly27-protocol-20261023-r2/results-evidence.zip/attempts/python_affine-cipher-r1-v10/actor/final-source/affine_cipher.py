from math import gcd


def encode(plain_text, a, b):
    """Encrypt text with an affine cipher and group output in blocks of five."""
    modulus = 26
    if gcd(a, modulus) != 1:
        raise ValueError("a and m must be coprime.")

    encrypted = []
    for character in plain_text.lower():
        if character.isalpha() and character.isascii():
            index = ord(character) - ord("a")
            encrypted.append(chr((a * index + b) % modulus + ord("a")))
        elif character.isdigit() and character.isascii():
            encrypted.append(character)

    return " ".join(
        "".join(encrypted[index:index + 5])
        for index in range(0, len(encrypted), 5)
    )


def decode(ciphered_text, a, b):
    """Decrypt text encrypted with an affine cipher."""
    modulus = 26
    if gcd(a, modulus) != 1:
        raise ValueError("a and m must be coprime.")

    inverse = pow(a, -1, modulus)
    decoded = []
    for character in ciphered_text.lower():
        if character.isalpha() and character.isascii():
            index = ord(character) - ord("a")
            decoded.append(chr((inverse * (index - b)) % modulus + ord("a")))
        elif character.isdigit() and character.isascii():
            decoded.append(character)

    return "".join(decoded)

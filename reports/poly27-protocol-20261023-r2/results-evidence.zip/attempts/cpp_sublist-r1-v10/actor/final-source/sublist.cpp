#include "sublist.h"

#include <algorithm>

namespace sublist {

List_comparison sublist(const std::vector<int>& first,
                        const std::vector<int>& second) {
    if (first == second) {
        return List_comparison::equal;
    }

    if (std::search(first.begin(), first.end(), second.begin(), second.end()) !=
        first.end()) {
        return List_comparison::superlist;
    }

    if (std::search(second.begin(), second.end(), first.begin(), first.end()) !=
        second.end()) {
        return List_comparison::sublist;
    }

    return List_comparison::unequal;
}

}  // namespace sublist

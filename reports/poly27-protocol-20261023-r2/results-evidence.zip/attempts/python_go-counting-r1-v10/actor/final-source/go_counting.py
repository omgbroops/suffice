"""Count territories of each player in a Go game."""


class Board:
    """Count territories of each player in a Go game.

    Args:
        board (list[str]): A two-dimensional Go board. Rows are indexed by
            ``y`` and columns by ``x``; ``B`` and ``W`` are stones and spaces
            are empty intersections.
    """

    def __init__(self, board):
        self.board = [list(row) for row in board]
        self.height = len(self.board)
        self.width = len(self.board[0]) if self.height else 0

    def _check_coordinate(self, x, y):
        if not (isinstance(x, int) and isinstance(y, int)
                and 0 <= x < self.width and 0 <= y < self.height):
            raise ValueError("Invalid coordinate")

    def _neighbors(self, x, y):
        for nx, ny in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
            if 0 <= nx < self.width and 0 <= ny < self.height:
                yield nx, ny

    def _region(self, x, y):
        """Return the connected empty region and the colors bordering it."""
        pending = [(x, y)]
        region = set()
        bordering_colors = set()
        while pending:
            point = pending.pop()
            if point in region:
                continue
            px, py = point
            region.add(point)
            for nx, ny in self._neighbors(px, py):
                cell = self.board[ny][nx]
                if cell == " ":
                    if (nx, ny) not in region:
                        pending.append((nx, ny))
                elif cell in ("B", "W"):
                    bordering_colors.add(cell)
        return region, bordering_colors

    def territory(self, x, y):
        """Find the owner and territory of the area at ``(x, y)``.

        Returns an owner (``"W"``, ``"B"`` or ``""``) and a set of
        ``(x, y)`` coordinates. An occupied intersection has no empty
        territory, so its stone color is returned with an empty set.
        """
        self._check_coordinate(x, y)
        cell = self.board[y][x]
        if cell != " ":
            return (cell if cell in ("B", "W") else ""), set()

        region, bordering_colors = self._region(x, y)
        owner = next(iter(bordering_colors)) if len(bordering_colors) == 1 else ""
        return owner, region

    def territories(self):
        """Return all territory coordinates grouped by owner."""
        result = {"B": set(), "W": set(), "": set()}
        visited = set()
        for y in range(self.height):
            for x in range(self.width):
                if self.board[y][x] != " " or (x, y) in visited:
                    continue
                region, bordering_colors = self._region(x, y)
                visited.update(region)
                owner = next(iter(bordering_colors)) if len(bordering_colors) == 1 else ""
                result[owner].update(region)
        return result

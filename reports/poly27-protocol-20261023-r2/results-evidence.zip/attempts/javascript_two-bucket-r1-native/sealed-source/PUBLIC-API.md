# Public interface

new TwoBucket(size1: number, size2: number, goal: number, start: "one" | "two"). solve(): {moves: number, goalBucket: "one" | "two", otherBucket: number}.

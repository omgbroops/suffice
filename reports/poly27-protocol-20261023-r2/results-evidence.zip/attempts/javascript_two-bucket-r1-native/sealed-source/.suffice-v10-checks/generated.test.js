import { TwoBucket } from '../two-bucket.js';

test.each([
  [3, 5, 1, 'one', { moves: 4, goalBucket: 'one', otherBucket: 5 }],
  [3, 5, 1, 'two', { moves: 8, goalBucket: 'two', otherBucket: 3 }],
  [7, 11, 2, 'one', { moves: 14, goalBucket: 'one', otherBucket: 11 }],
  [7, 11, 2, 'two', { moves: 18, goalBucket: 'two', otherBucket: 7 }],
  [1, 3, 3, 'one', { moves: 2, goalBucket: 'two', otherBucket: 1 }],
  [3, 1, 3, 'two', { moves: 2, goalBucket: 'one', otherBucket: 1 }],
  [3, 5, 3, 'one', { moves: 1, goalBucket: 'one', otherBucket: 0 }],
  [3, 5, 5, 'two', { moves: 1, goalBucket: 'two', otherBucket: 0 }],
  [6, 15, 9, 'one', { moves: 10, goalBucket: 'two', otherBucket: 0 }],
  [15, 6, 9, 'two', { moves: 10, goalBucket: 'one', otherBucket: 0 }],
])('solves sizes %i and %i, goal %i, starting with %s',
  (size1, size2, goal, start, expected) => {
    expect(new TwoBucket(size1, size2, goal, start).solve()).toEqual(expected);
  });

test('rejects an amount that is not divisible by the capacities’ common divisor', () => {
  expect(() => new TwoBucket(6, 15, 5, 'one').solve()).toThrow();
});

test('rejects an amount larger than either bucket', () => {
  expect(() => new TwoBucket(3, 5, 8, 'two').solve()).toThrow();
});

test('repeated solves preserve the initial conditions', () => {
  const buckets = new TwoBucket(3, 5, 1, 'one');
  const expected = { moves: 4, goalBucket: 'one', otherBucket: 5 };
  expect(buckets.solve()).toEqual(expected);
  expect(buckets.solve()).toEqual(expected);
});

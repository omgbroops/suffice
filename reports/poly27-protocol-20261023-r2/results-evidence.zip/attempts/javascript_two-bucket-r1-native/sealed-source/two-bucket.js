//
// This is only a SKELETON file for the 'Two Bucket' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class TwoBucket {
  constructor(size1, size2, goal, start) {
    this.size1 = size1;
    this.size2 = size2;
    this.goal = goal;
    this.start = start;
  }

  solve() {
    let divisor = this.size1;
    let remainder = this.size2;
    while (remainder !== 0) {
      [divisor, remainder] = [remainder, divisor % remainder];
    }

    if (
      this.goal > Math.max(this.size1, this.size2) ||
      this.goal % divisor !== 0
    ) {
      throw new Error('The goal cannot be reached');
    }

    const startsWithOne = this.start === 'one';
    const initial = startsWithOne ? [this.size1, 0] : [0, this.size2];
    const queue = [[...initial, 1]];
    const visited = new Set([initial.join(',')]);

    // Explore states in action order so the first solution uses the fewest moves.
    for (let index = 0; index < queue.length; index += 1) {
      const [one, two, moves] = queue[index];
      if (one === this.goal || two === this.goal) {
        return {
          moves,
          goalBucket: one === this.goal ? 'one' : 'two',
          otherBucket: one === this.goal ? two : one,
        };
      }

      const pourToTwo = Math.min(one, this.size2 - two);
      const pourToOne = Math.min(two, this.size1 - one);
      const nextStates = [
        [this.size1, two],
        [one, this.size2],
        [0, two],
        [one, 0],
        [one - pourToTwo, two + pourToTwo],
        [one + pourToOne, two - pourToOne],
      ];

      for (const [nextOne, nextTwo] of nextStates) {
        const forbidden = startsWithOne
          ? nextOne === 0 && nextTwo === this.size2
          : nextTwo === 0 && nextOne === this.size1;
        const key = `${nextOne},${nextTwo}`;
        if (!forbidden && !visited.has(key)) {
          visited.add(key);
          queue.push([nextOne, nextTwo, moves + 1]);
        }
      }
    }

    throw new Error('The goal cannot be reached');
  }
}

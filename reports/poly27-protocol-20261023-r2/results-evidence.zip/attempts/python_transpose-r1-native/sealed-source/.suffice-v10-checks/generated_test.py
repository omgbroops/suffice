import pytest

from transpose import transpose


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("", ""),
        ("A", "A"),
        ("ABC", "A\nB\nC"),
        ("A\nB\nC", "ABC"),
        ("ABC\nDEF", "AD\nBE\nCF"),
        ("ABC\nDE", "AD\nBE\nC"),
        ("AB\nDEF", "AD\nBE\n F"),
        ("A\nBCD\nE\nFGHI", "ABEF\n C G\n D H\n   I"),
        ("\nAB", " A\n B"),
        ("AB\n\nCD", "A C\nB D"),
        ("AB\n", "A\nB"),
        ("\n\n", ""),
        ("A \nB ", "AB\n  "),
        ("ABC\nD \n  ", "AD \nB  \nC"),
        (" \n  ", "  \n  "),
        ("A\t\nB ", "AB\n\t "),
        ("αβ\n猫", "α猫\nβ"),
    ],
)
def test_transpose_public_behavior(text, expected):
    assert transpose(text) == expected

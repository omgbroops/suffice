package wordsearch

import (
	"fmt"
)

func Solve(words []string, puzzle []string) (map[string][2][2]int, error) {
	grid := make([][]rune, len(puzzle))
	size := len(puzzle)
	for row, line := range puzzle {
		grid[row] = []rune(line)
		if len(grid[row]) != size {
			return nil, fmt.Errorf("puzzle must be square: row %d has %d letters, want %d", row+1, len(grid[row]), size)
		}
	}

	found := make(map[string][2][2]int, len(words))
	directions := [][2]int{
		{0, 1}, {0, -1},
		{1, 0}, {-1, 0},
		{1, 1}, {1, -1}, {-1, 1}, {-1, -1},
	}

	for _, word := range words {
		letters := []rune(word)
		if len(letters) == 0 {
			continue
		}
		search:
		for row := 0; row < size; row++ {
			for col := 0; col < size; col++ {
				for _, dir := range directions {
					endRow := row + (len(letters)-1)*dir[0]
					endCol := col + (len(letters)-1)*dir[1]
					if endRow < 0 || endRow >= size || endCol < 0 || endCol >= size {
						continue
					}
					match := true
					for i, letter := range letters {
						if grid[row+i*dir[0]][col+i*dir[1]] != letter {
							match = false
							break
						}
					}
					if match {
						found[word] = [2][2]int{{row + 1, col + 1}, {endRow + 1, endCol + 1}}
						break search
					}
				}
			}
		}
	}

	return found, nil
}

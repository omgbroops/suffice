import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class GeneratedCheck {
    private final PigLatinTranslator translator = new PigLatinTranslator();

    @Test
    void wordsStartingWithEachVowel() {
        assertEquals("appleay", translator.translate("apple"));
        assertEquals("earay", translator.translate("ear"));
        assertEquals("iglooay", translator.translate("igloo"));
        assertEquals("objectay", translator.translate("object"));
        assertEquals("underay", translator.translate("under"));
        assertEquals("equalay", translator.translate("equal"));
    }

    @Test
    void vowelSoundExceptions() {
        assertEquals("xrayay", translator.translate("xray"));
        assertEquals("yttriaay", translator.translate("yttria"));
        assertEquals("enonxay", translator.translate("xenon"));
    }

    @Test
    void initialConsonantsAndClusters() {
        assertEquals("igpay", translator.translate("pig"));
        assertEquals("oatcay", translator.translate("coat"));
        assertEquals("airchay", translator.translate("chair"));
        assertEquals("ushthray", translator.translate("thrush"));
        assertEquals("oolschay", translator.translate("school"));
        assertEquals("erapythay", translator.translate("therapy"));
    }

    @Test
    void quMovesWithTheInitialConsonants() {
        assertEquals("ickquay", translator.translate("quick"));
        assertEquals("eenquay", translator.translate("queen"));
        assertEquals("aresquay", translator.translate("square"));
        assertEquals("ealsquay", translator.translate("squeal"));
        assertEquals("iquidlay", translator.translate("liquid"));
    }

    @Test
    void yActsAsAVowelOnlyAfterAnInitialConsonant() {
        assertEquals("ymay", translator.translate("my"));
        assertEquals("ythmrhay", translator.translate("rhythm"));
        assertEquals("yphglay", translator.translate("glyph"));
        assertEquals("ellowyay", translator.translate("yellow"));
    }

    @Test
    void translatesEveryWordInPhrases() {
        assertEquals("ickquay astfay unray", translator.translate("quick fast run"));
        assertEquals("ymay airchay isay aresquay", translator.translate("my chair is square"));
        assertEquals("ythmrhay appleay xrayay yttriaay", translator.translate("rhythm apple xray yttria"));
    }
}

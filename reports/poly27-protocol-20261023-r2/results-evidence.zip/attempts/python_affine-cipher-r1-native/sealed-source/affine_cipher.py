from math import gcd


def _validate_key(a):
    if gcd(a, 26) != 1:
        raise ValueError("a and m must be coprime.")


def _transform(text, multiplier, offset):
    result = []
    for character in text.lower():
        if "a" <= character <= "z":
            index = ord(character) - ord("a")
            result.append(chr((multiplier * index + offset) % 26 + ord("a")))
        elif "0" <= character <= "9":
            result.append(character)
    return "".join(result)


def encode(plain_text, a, b):
    _validate_key(a)
    encrypted = _transform(plain_text, a, b)
    return " ".join(encrypted[start:start + 5] for start in range(0, len(encrypted), 5))


def decode(ciphered_text, a, b):
    _validate_key(a)
    inverse = pow(a, -1, 26)
    return _transform(ciphered_text, inverse, -inverse * b)

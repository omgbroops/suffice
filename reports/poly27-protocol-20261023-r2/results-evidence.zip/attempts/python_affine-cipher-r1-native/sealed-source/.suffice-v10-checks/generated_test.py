import pytest

from affine_cipher import decode, encode


@pytest.mark.parametrize(
    "plain_text,a,b,cipher_text",
    [
        ("test", 5, 7, "ybty"),
        ("yes", 5, 7, "xbt"),
        ("OMG", 21, 3, "lvz"),
        ("O M G", 21, 3, "lvz"),
        ("mindblowingly", 11, 15, "rzcwa gnxzc dgt"),
        ("Testing,1 2 3, testing.", 3, 4, "jqgjc rw123 jqgjc rw"),
        ("Truth is fiction.", 5, 17, "iynia fdqfb ifje"),
        (
            "The quick brown fox jumps over the lazy dog.",
            19,
            13,
            "kqlfd jzvgy tpaet icdhm rtwly kqlon ubstx",
        ),
    ],
)
def test_known_encodings_and_decodings(plain_text, a, b, cipher_text):
    assert encode(plain_text, a, b) == cipher_text
    expected_plain = "".join(c for c in plain_text.lower() if c.isalnum())
    assert decode(cipher_text, a, b) == expected_plain


def test_decoding_with_a_different_valid_key():
    assert decode("ybty", 11, 7) == "lqul"


@pytest.mark.parametrize("text", ["", "   ", "!?.,;:-_\n\t"])
def test_empty_or_discarded_input(text):
    assert encode(text, 5, 7) == ""
    assert decode(text, 5, 7) == ""


def test_digits_remain_unchanged_and_count_towards_groups():
    assert encode("0123456789", 5, 7) == "01234 56789"
    assert decode("01234 56789", 5, 7) == "0123456789"
    assert encode("abcd1e", 1, 0) == "abcd1 e"
    assert encode("abcde", 1, 0) == "abcde"


def test_decoding_ignores_spacing_punctuation_and_case():
    assert decode("YB! T\nY", 5, 7) == "test"


@pytest.mark.parametrize("operation", [encode, decode])
@pytest.mark.parametrize("a", [0, 2, 13, 18, 26, -2, 52])
@pytest.mark.parametrize("text", ["test", ""])
def test_non_coprime_key_raises_required_error(operation, a, text):
    with pytest.raises(ValueError, match=r"^a and m must be coprime\.$"):
        operation(text, a, 13)


@pytest.mark.parametrize("a", [1, 3, 5, 7, 9, 11, 15, 17, 19, 21, 23, 25, -5, 31])
@pytest.mark.parametrize("b", [0, 7, 25, 26, -13, 100])
def test_alphabet_mapping_and_round_trip(a, b):
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    expected = "".join(alphabet[(a * i + b) % 26] for i in range(26))
    grouped = " ".join(expected[i:i + 5] for i in range(0, 26, 5))
    assert encode(alphabet, a, b) == grouped
    assert decode(grouped, a, b) == alphabet

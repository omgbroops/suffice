//
// This is only a SKELETON file for the 'Two Bucket' exercise. It's been provided as a
// convenience to get you started writing code faster.
//
export class TwoBucket {
  constructor(size1, size2, goal, start) {
    if (!Number.isInteger(size1) || !Number.isInteger(size2) ||
        !Number.isInteger(goal) || size1 < 0 || size2 < 0 ||
        (start !== 'one' && start !== 'two')) {
      throw new Error('Invalid bucket configuration');
    }

    this.sizes = [size1, size2];
    this.goal = goal;
    this.start = start === 'one' ? 0 : 1;
  }

  solve() {
    const [capacity1, capacity2] = this.sizes;
    const capacities = [capacity1, capacity2];
    const startState = [0, 0];
    startState[this.start] = capacities[this.start];

    const queue = [{ state: startState, moves: 1 }];
    const visited = new Set();

    while (queue.length > 0) {
      const { state, moves } = queue.shift();
      const key = state.join(',');
      if (visited.has(key)) continue;
      visited.add(key);

      if (state[0] === this.goal) {
        return { moves, goalBucket: 'one', otherBucket: state[1] };
      }
      if (state[1] === this.goal) {
        return { moves, goalBucket: 'two', otherBucket: state[0] };
      }

      const nextStates = [];
      // Fill either bucket.
      nextStates.push([capacities[0], state[1]]);
      nextStates.push([state[0], capacities[1]]);
      // Empty either bucket.
      nextStates.push([0, state[1]]);
      nextStates.push([state[0], 0]);
      // Pour bucket one into bucket two, and vice versa.
      const intoTwo = Math.min(state[0], capacities[1] - state[1]);
      nextStates.push([state[0] - intoTwo, state[1] + intoTwo]);
      const intoOne = Math.min(state[1], capacities[0] - state[0]);
      nextStates.push([state[0] + intoOne, state[1] - intoOne]);

      for (const next of nextStates) {
        if (next[0] === state[0] && next[1] === state[1]) continue;
        // The starting bucket may not be empty while the other is full.
        if (next[this.start] === 0 && next[1 - this.start] === capacities[1 - this.start]) continue;
        const nextKey = next.join(',');
        if (!visited.has(nextKey)) queue.push({ state: next, moves: moves + 1 });
      }
    }

    throw new Error('Goal cannot be reached');
  }
}

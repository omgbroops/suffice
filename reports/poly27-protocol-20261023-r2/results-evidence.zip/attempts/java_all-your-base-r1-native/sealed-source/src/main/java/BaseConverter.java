import java.util.ArrayList;
import java.util.List;

class BaseConverter {

    private final int originalBase;
    private final int[] originalDigits;

    BaseConverter(int originalBase, int[] originalDigits) {
        validateBase(originalBase);
        for (int digit : originalDigits) {
            if (digit < 0) {
                throw new IllegalArgumentException("Digits may not be negative.");
            }
            if (digit >= originalBase) {
                throw new IllegalArgumentException("All digits must be strictly less than the base.");
            }
        }
        this.originalBase = originalBase;
        this.originalDigits = originalDigits.clone();
    }

    int[] convertToBase(int newBase) {
        validateBase(newBase);
        int[] quotient = originalDigits.clone();
        List<Integer> remainders = new ArrayList<>();
        int start = 0;

        while (start < quotient.length && quotient[start] == 0) {
            start++;
        }

        while (start < quotient.length) {
            long remainder = 0;
            // Divide in the original base, collecting output digits least significant first.
            for (int i = start; i < quotient.length; i++) {
                long value = remainder * originalBase + quotient[i];
                quotient[i] = (int) (value / newBase);
                remainder = value % newBase;
            }
            remainders.add((int) remainder);
            while (start < quotient.length && quotient[start] == 0) {
                start++;
            }
        }

        if (remainders.isEmpty()) {
            return new int[]{0};
        }
        int[] result = new int[remainders.size()];
        for (int i = 0; i < result.length; i++) {
            result[i] = remainders.get(result.length - 1 - i);
        }
        return result;
    }

    private static void validateBase(int base) {
        if (base < 2) {
            throw new IllegalArgumentException("Bases must be at least 2.");
        }
    }

}

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GeneratedCheck {
    @Test
    void convertsExamplesInBothDirections() {
        assertArrayEquals(new int[]{1, 0, 1, 0, 1, 0},
                new BaseConverter(10, new int[]{4, 2}).convertToBase(2));
        assertArrayEquals(new int[]{4, 2},
                new BaseConverter(2, new int[]{1, 0, 1, 0, 1, 0}).convertToBase(10));
        assertArrayEquals(new int[]{4, 2},
                new BaseConverter(3, new int[]{1, 1, 2, 0}).convertToBase(10));
    }

    @Test
    void convertsBetweenNonDecimalBases() {
        assertArrayEquals(new int[]{2, 10},
                new BaseConverter(3, new int[]{1, 1, 2, 0}).convertToBase(16));
        assertArrayEquals(new int[]{1, 1, 2, 0},
                new BaseConverter(16, new int[]{2, 10}).convertToBase(3));
    }

    @Test
    void normalizesZeroAndLeadingZeros() {
        assertArrayEquals(new int[]{0}, new BaseConverter(10, new int[]{}).convertToBase(2));
        assertArrayEquals(new int[]{0}, new BaseConverter(2, new int[]{0}).convertToBase(10));
        assertArrayEquals(new int[]{0}, new BaseConverter(3, new int[]{0, 0, 0}).convertToBase(3));
        assertArrayEquals(new int[]{4, 2},
                new BaseConverter(10, new int[]{0, 0, 4, 2}).convertToBase(10));
    }

    @Test
    void preservesInternalZeros() {
        assertArrayEquals(new int[]{1, 0, 0},
                new BaseConverter(2, new int[]{1, 1, 0, 0, 1, 0, 0}).convertToBase(10));
    }

    @Test
    void rejectsInvalidInputBases() {
        for (int base : new int[]{Integer.MIN_VALUE, -2, 0, 1}) {
            assertThrows(IllegalArgumentException.class,
                    () -> new BaseConverter(base, new int[]{0}));
        }
    }

    @Test
    void rejectsInvalidOutputBasesEvenForZero() {
        for (int base : new int[]{Integer.MIN_VALUE, -2, 0, 1}) {
            assertThrows(IllegalArgumentException.class,
                    () -> new BaseConverter(10, new int[]{}).convertToBase(base));
        }
    }

    @Test
    void rejectsDigitsOutsideTheInputBase() {
        assertThrows(IllegalArgumentException.class,
                () -> new BaseConverter(2, new int[]{1, -1}));
        assertThrows(IllegalArgumentException.class,
                () -> new BaseConverter(2, new int[]{1, 2}));
        assertThrows(IllegalArgumentException.class,
                () -> new BaseConverter(10, new int[]{11}));
    }

    @Test
    void convertsNumbersLargerThanLong() {
        int[] binary = new int[81];
        binary[0] = 1;
        int[] hexadecimal = new int[21];
        hexadecimal[0] = 1;
        assertArrayEquals(hexadecimal, new BaseConverter(2, binary).convertToBase(16));
        assertArrayEquals(binary, new BaseConverter(16, hexadecimal).convertToBase(2));
    }

    @Test
    void handlesLargestIntBaseWithoutOverflow() {
        assertArrayEquals(new int[]{4, 6, 1, 1, 6, 8, 6, 0, 1, 4, 1, 3, 2, 4, 2, 0, 6, 0, 8},
                new BaseConverter(Integer.MAX_VALUE,
                        new int[]{Integer.MAX_VALUE - 1, Integer.MAX_VALUE - 1}).convertToBase(10));
        assertArrayEquals(new int[]{1, 0},
                new BaseConverter(10, new int[]{2, 1, 4, 7, 4, 8, 3, 6, 4, 7})
                        .convertToBase(Integer.MAX_VALUE));
    }

    @Test
    void supportsRepeatedConversionsWithoutMutatingInputsOrResults() {
        int[] input = {4, 2};
        BaseConverter converter = new BaseConverter(10, input);
        assertArrayEquals(new int[]{2, 10}, converter.convertToBase(16));
        assertArrayEquals(new int[]{4, 2}, input);
        input[0] = 9;
        int[] result = converter.convertToBase(10);
        assertArrayEquals(new int[]{4, 2}, result);
        result[0] = 8;
        assertArrayEquals(new int[]{4, 2}, converter.convertToBase(10));
    }
}

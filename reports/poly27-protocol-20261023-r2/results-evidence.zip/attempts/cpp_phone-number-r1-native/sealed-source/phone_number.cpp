#include "phone_number.h"

#include <cctype>
#include <stdexcept>

namespace phone_number {

phone_number::phone_number(const std::string& input) {
    for (unsigned char character : input) {
        if (character >= '0' && character <= '9') {
            digits_ += static_cast<char>(character);
        } else if (!std::isspace(character) && character != '+' &&
                   character != '(' && character != ')' &&
                   character != '-' && character != '.') {
            throw std::invalid_argument("Invalid character in phone number");
        }
    }

    if (digits_.size() == 11 && digits_.front() == '1') {
        digits_.erase(0, 1);
    }
    if (digits_.size() != 10) {
        throw std::invalid_argument("Phone number must contain ten digits, optionally prefixed by 1");
    }
    if (digits_[0] < '2') {
        throw std::invalid_argument("Area code must start with a digit from 2 through 9");
    }
    if (digits_[3] < '2') {
        throw std::invalid_argument("Exchange code must start with a digit from 2 through 9");
    }
}

std::string phone_number::area_code() const {
    return digits_.substr(0, 3);
}

std::string phone_number::number() const {
    return digits_;
}

phone_number::operator std::string() const {
    return "(" + area_code() + ") " + digits_.substr(3, 3) + "-" +
           digits_.substr(6, 4);
}

}  // namespace phone_number

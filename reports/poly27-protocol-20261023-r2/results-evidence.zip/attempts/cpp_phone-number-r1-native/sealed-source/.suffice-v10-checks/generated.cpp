#include "catch.hpp"
#include "phone_number.h"

#include <stdexcept>
#include <string>

TEST_CASE("Formatting and optional country code are cleaned") {
    for (const std::string input : {"+1 (613)-995-0253", "613-995-0253",
                                    "1 613 995 0253", "613.995.0253",
                                    "6139950253"}) {
        const phone_number::phone_number phone(input);
        REQUIRE(phone.number() == "6139950253");
        REQUIRE(phone.area_code() == "613");
        REQUIRE(static_cast<std::string>(phone) == "(613) 995-0253");
    }
}

TEST_CASE("Valid code boundaries and zeroes in remaining positions") {
    const phone_number::phone_number low("2002000000");
    REQUIRE(low.number() == "2002000000");
    REQUIRE(low.area_code() == "200");
    const phone_number::phone_number high("1 (999) 999-9999");
    REQUIRE(high.number() == "9999999999");
    REQUIRE(static_cast<std::string>(high) == "(999) 999-9999");
}

TEST_CASE("Invalid lengths and country codes are rejected") {
    for (const std::string input : {"", "123456789", "223456789012",
                                    "22345678901", "+2 (613) 995-0253",
                                    "161399502531"}) {
        REQUIRE_THROWS_AS(phone_number::phone_number{input}, std::invalid_argument);
    }
}

TEST_CASE("Area and exchange codes cannot start with zero or one") {
    for (const std::string input : {"0139950253", "1139950253",
                                    "6130950253", "6131950253",
                                    "10139950253", "11139950253",
                                    "16130950253", "16131950253"}) {
        REQUIRE_THROWS_AS(phone_number::phone_number{input}, std::invalid_argument);
    }
}

TEST_CASE("Letters and unsupported punctuation are rejected") {
    for (const std::string input : {"613-abc-0253", "6139950253x",
                                    "613@995:0253", "613/995/0253"}) {
        REQUIRE_THROWS_AS(phone_number::phone_number{input}, std::invalid_argument);
    }
}

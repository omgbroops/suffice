# Public interface

namespace phone_number { class phone_number { public: phone_number(const std::string&); std::string area_code() const; std::string number() const; explicit operator std::string() const; }; }

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Satellite {
    public Tree treeFromTraversals(List<Character> preorderInput, List<Character> inorderInput) {
        if (preorderInput == null || inorderInput == null) {
            throw new IllegalArgumentException("Traversals must not be null");
        }
        if (preorderInput.size() != inorderInput.size()) {
            throw new IllegalArgumentException("Traversals must have the same length");
        }

        Map<Character, Integer> inorderPositions = new HashMap<>();
        Set<Character> preorderValues = new HashSet<>();
        for (int i = 0; i < inorderInput.size(); i++) {
            Character value = inorderInput.get(i);
            if (value == null || inorderPositions.put(value, i) != null) {
                throw new IllegalArgumentException("Traversals must contain unique, non-null values");
            }
        }
        for (Character value : preorderInput) {
            if (value == null || !preorderValues.add(value)) {
                throw new IllegalArgumentException("Traversals must contain unique, non-null values");
            }
        }
        if (!preorderValues.equals(inorderPositions.keySet())) {
            throw new IllegalArgumentException("Traversals must contain the same values");
        }

        int[] preorderIndex = {0};
        Node root = build(preorderInput, inorderPositions, preorderIndex, 0, inorderInput.size());
        if (preorderIndex[0] != preorderInput.size()) {
            throw new IllegalArgumentException("Inconsistent traversals");
        }
        return new Tree(root);
    }

    private Node build(List<Character> preorder, Map<Character, Integer> positions,
                       int[] preorderIndex, int start, int end) {
        if (start >= end) {
            return null;
        }
        if (preorderIndex[0] >= preorder.size()) {
            throw new IllegalArgumentException("Inconsistent traversals");
        }

        char value = preorder.get(preorderIndex[0]++);
        Integer split = positions.get(value);
        if (split == null || split < start || split >= end) {
            throw new IllegalArgumentException("Inconsistent traversals");
        }

        Node node = new Node(value);
        node.left = build(preorder, positions, preorderIndex, start, split);
        node.right = build(preorder, positions, preorderIndex, split + 1, end);
        return node;
    }
}

import java.util.ArrayList;
import java.util.List;

class BaseConverter {

    private final int[] originalDigits;
    private final int originalBase;

    BaseConverter(int originalBase, int[] originalDigits) {
        if (originalBase < 2) {
            throw new IllegalArgumentException("Bases must be at least 2.");
        }
        if (originalDigits == null || originalDigits.length == 0) {
            throw new IllegalArgumentException("Digits must not be empty.");
        }
        for (int digit : originalDigits) {
            if (digit < 0 || digit >= originalBase) {
                throw new IllegalArgumentException("Digit is not valid for the original base.");
            }
        }
        this.originalBase = originalBase;
        this.originalDigits = originalDigits.clone();
    }

    int[] convertToBase(int newBase) {
        if (newBase < 2) {
            throw new IllegalArgumentException("Bases must be at least 2.");
        }

        // Repeatedly divide the number, represented in its original base, by
        // the target base. The remainders are the target-base digits in reverse.
        int firstNonZero = 0;
        while (firstNonZero < originalDigits.length && originalDigits[firstNonZero] == 0) {
            firstNonZero++;
        }
        if (firstNonZero == originalDigits.length) {
            return new int[] {0};
        }

        int[] work = new int[originalDigits.length - firstNonZero];
        System.arraycopy(originalDigits, firstNonZero, work, 0, work.length);
        List<Integer> reversedResult = new ArrayList<>();

        while (work.length > 0) {
            int[] quotient = new int[work.length];
            int quotientLength = 0;
            long remainder = 0;
            for (int digit : work) {
                long value = remainder * originalBase + digit;
                int quotientDigit = (int) (value / newBase);
                remainder = value % newBase;
                if (quotientLength > 0 || quotientDigit != 0) {
                    quotient[quotientLength++] = quotientDigit;
                }
            }
            reversedResult.add((int) remainder);
            if (quotientLength == 0) {
                break;
            }
            work = new int[quotientLength];
            System.arraycopy(quotient, 0, work, 0, quotientLength);
        }

        int[] result = new int[reversedResult.size()];
        for (int i = 0; i < result.length; i++) {
            result[i] = reversedResult.get(result.length - 1 - i);
        }
        return result;
    }
}

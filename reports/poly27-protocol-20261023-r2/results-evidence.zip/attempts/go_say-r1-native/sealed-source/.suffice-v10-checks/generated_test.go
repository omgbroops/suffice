package say

import "testing"

func TestSayPublicExamplesAndEdges(t *testing.T) {
	cases := []struct {
		n    int64
		want string
	}{
		{0, "zero"},
		{1, "one"},
		{9, "nine"},
		{10, "ten"},
		{11, "eleven"},
		{12, "twelve"},
		{13, "thirteen"},
		{14, "fourteen"},
		{15, "fifteen"},
		{16, "sixteen"},
		{17, "seventeen"},
		{18, "eighteen"},
		{19, "nineteen"},
		{20, "twenty"},
		{22, "twenty-two"},
		{30, "thirty"},
		{40, "forty"},
		{50, "fifty"},
		{60, "sixty"},
		{70, "seventy"},
		{80, "eighty"},
		{90, "ninety"},
		{98, "ninety-eight"},
		{99, "ninety-nine"},
		{100, "one hundred"},
		{101, "one hundred one"},
		{110, "one hundred ten"},
		{115, "one hundred fifteen"},
		{123, "one hundred twenty-three"},
		{999, "nine hundred ninety-nine"},
		{1000, "one thousand"},
		{1001, "one thousand one"},
		{1010, "one thousand ten"},
		{1100, "one thousand one hundred"},
		{12345, "twelve thousand three hundred forty-five"},
		{1000000, "one million"},
		{1000001, "one million one"},
		{1001000, "one million one thousand"},
		{1000000000, "one billion"},
		{1000000001, "one billion one"},
		{1001001001, "one billion one million one thousand one"},
		{1234567890, "one billion two hundred thirty-four million five hundred sixty-seven thousand eight hundred ninety"},
		{987654321123, "nine hundred eighty-seven billion six hundred fifty-four million three hundred twenty-one thousand one hundred twenty-three"},
		{999999999999, "nine hundred ninety-nine billion nine hundred ninety-nine million nine hundred ninety-nine thousand nine hundred ninety-nine"},
	}
	for _, tc := range cases {
		got, ok := Say(tc.n)
		if !ok || got != tc.want {
			t.Errorf("Say(%d) = (%q, %v), want (%q, true)", tc.n, got, ok, tc.want)
		}
	}
}

func TestSayRejectsOutOfRange(t *testing.T) {
	for _, n := range []int64{-1, -100, -9223372036854775808, 1000000000000, 1000000000001, 9223372036854775807} {
		got, ok := Say(n)
		if ok || got != "" {
			t.Errorf("Say(%d) = (%q, %v), want (\"\", false)", n, got, ok)
		}
	}
}

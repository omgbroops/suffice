package say

import "strings"

func Say(n int64) (string, bool) {
	if n < 0 || n > 999_999_999_999 {
		return "", false
	}
	if n == 0 {
		return "zero", true
	}

	var parts []string
	for _, scale := range []struct {
		value int64
		name  string
	}{
		{1_000_000_000, "billion"},
		{1_000_000, "million"},
		{1_000, "thousand"},
		{1, ""},
	} {
		if chunk := n / scale.value; chunk > 0 {
			part := sayChunk(chunk)
			if scale.name != "" {
				part += " " + scale.name
			}
			parts = append(parts, part)
		}
		n %= scale.value
	}
	return strings.Join(parts, " "), true
}

// sayChunk spells a nonzero number below one thousand.
func sayChunk(n int64) string {
	units := [...]string{
		"", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
		"ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen",
		"seventeen", "eighteen", "nineteen",
	}
	tens := [...]string{"", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"}

	var result string
	if n >= 100 {
		result = units[n/100] + " hundred"
		n %= 100
		if n == 0 {
			return result
		}
		result += " "
	}
	if n < 20 {
		return result + units[n]
	}
	result += tens[n/10]
	if n%10 != 0 {
		result += "-" + units[n%10]
	}
	return result
}

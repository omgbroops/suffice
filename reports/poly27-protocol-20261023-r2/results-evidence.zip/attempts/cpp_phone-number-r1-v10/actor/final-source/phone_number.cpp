#include "phone_number.h"

#include <cctype>
#include <stdexcept>

namespace phone_number {

phone_number::phone_number(const std::string& input) {
    for (const unsigned char character : input) {
        if (std::isdigit(character) != 0) {
            number_.push_back(static_cast<char>(character));
        }
    }

    if (number_.size() == 11) {
        if (number_.front() != '1') {
            throw std::domain_error("invalid country code");
        }
        number_.erase(number_.begin());
    } else if (number_.size() != 10) {
        throw std::domain_error("invalid phone number length");
    }

    if (number_[0] < '2' || number_[0] > '9') {
        throw std::domain_error("invalid area code");
    }
    if (number_[3] < '2' || number_[3] > '9') {
        throw std::domain_error("invalid exchange code");
    }
}

std::string phone_number::area_code() const {
    return number_.substr(0, 3);
}

std::string phone_number::number() const {
    return number_;
}

phone_number::operator std::string() const {
    return number_;
}

}  // namespace phone_number

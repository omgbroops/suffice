import pytest

from go_counting import Board


@pytest.mark.parametrize("stone", ["B", "W"])
def test_enclosed_connected_territory(stone):
    board = Board([stone * 4, stone + "  " + stone,
                   stone + " " + stone * 2, stone * 4])
    region = {(1, 1), (2, 1), (1, 2)}
    for x, y in region:
        assert board.territory(x, y) == (stone, region)
    assert board.territories() == {
        "B": region if stone == "B" else set(),
        "W": region if stone == "W" else set(),
        "": set(),
    }


def test_mixed_borders_make_entire_connected_region_neutral():
    board = Board(["B   W", "B   W"])
    region = {(x, y) for x in range(1, 4) for y in range(2)}
    assert board.territory(1, 0) == ("", region)
    assert board.territories() == {"B": set(), "W": set(), "": region}


def test_board_edges_and_diagonal_stones():
    board = Board([" B", "BW"])
    assert board.territory(0, 0) == ("B", {(0, 0)})


def test_diagonally_touching_empty_regions_are_separate():
    board = Board([" BW", "B W", "WWW"])
    assert board.territory(0, 0) == ("B", {(0, 0)})
    assert board.territory(1, 1) == ("", {(1, 1)})


def test_all_owners_and_disconnected_regions():
    board = Board([" B W ", "BB WW", " B W "])
    assert board.territories() == {
        "B": {(0, 0), (0, 2)},
        "W": {(4, 0), (4, 2)},
        "": {(2, 0), (2, 1), (2, 2)},
    }


@pytest.mark.parametrize("rows", [["B"], ["W"], ["BW", "WB"]])
def test_stones_have_no_territory(rows):
    board = Board(rows)
    for y, row in enumerate(rows):
        for x in range(len(row)):
            assert board.territory(x, y) == ("", set())
    assert board.territories() == {"B": set(), "W": set(), "": set()}


@pytest.mark.parametrize("rows", [[" "], ["   ", "   "], [" " * 50] * 50])
def test_board_without_stones_is_neutral(rows):
    board = Board(rows)
    region = {(x, y) for y, row in enumerate(rows) for x in range(len(row))}
    assert board.territory(0, 0) == ("", region)
    assert board.territories() == {"B": set(), "W": set(), "": region}


@pytest.mark.parametrize("x,y", [(-1, 0), (0, -1), (3, 0), (0, 2), (9, 9)])
def test_invalid_coordinates_raise_with_message(x, y):
    with pytest.raises(ValueError, match=".+"):
        Board(["   ", "   "]).territory(x, y)


@pytest.mark.parametrize("rows", [[], [""]])
def test_empty_board(rows):
    board = Board(rows)
    assert board.territories() == {"B": set(), "W": set(), "": set()}
    with pytest.raises(ValueError, match=".+"):
        board.territory(0, 0)


def test_returned_sets_do_not_change_future_results():
    board = Board(["B "])
    owner, region = board.territory(1, 0)
    assert owner == "B"
    region.clear()
    result = board.territories()
    result["B"].clear()
    assert board.territory(1, 0) == ("B", {(1, 0)})
    assert board.territories() == {"B": {(1, 0)}, "W": set(), "": set()}

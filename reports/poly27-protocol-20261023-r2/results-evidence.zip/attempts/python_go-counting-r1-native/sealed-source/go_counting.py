
class Board:
    """Count territories of each player in a Go game

    Args:
        board (list[str]): A two-dimensional Go board
    """

    def __init__(self, board):
        self.board = tuple(board)
        self.height = len(self.board)
        self.width = len(self.board[0]) if self.height else 0

    def territory(self, x, y):
        """Find the owner and the territories given a coordinate on
           the board

        Args:
            x (int): Column on the board
            y (int): Row on the board

        Returns:
            (str, set): A tuple, the first element being the owner
                        of that area.  One of "W", "B", "".  The
                        second being a set of coordinates, representing
                        the owner's territories.
        """
        if not (0 <= x < self.width and 0 <= y < self.height):
            raise ValueError("Invalid coordinate")
        if self.board[y][x] != " ":
            return "", set()

        region = {(x, y)}
        pending = [(x, y)]
        borders = set()
        while pending:
            column, row = pending.pop()
            for nx, ny in ((column - 1, row), (column + 1, row),
                           (column, row - 1), (column, row + 1)):
                if not (0 <= nx < self.width and 0 <= ny < self.height):
                    continue
                stone = self.board[ny][nx]
                if stone == " ":
                    if (nx, ny) not in region:
                        region.add((nx, ny))
                        pending.append((nx, ny))
                else:
                    borders.add(stone)

        owner = next(iter(borders)) if len(borders) == 1 else ""
        return owner, region

    def territories(self):
        """Find the owners and the territories of the whole board

        Args:
            none

        Returns:
            dict(str, set): A dictionary whose key being the owner
                        , i.e. "W", "B", "".  The value being a set
                        of coordinates owned by the owner.
        """
        result = {"B": set(), "W": set(), "": set()}
        visited = set()
        for y, row in enumerate(self.board):
            for x, stone in enumerate(row):
                if stone == " " and (x, y) not in visited:
                    owner, region = self.territory(x, y)
                    result[owner].update(region)
                    visited.update(region)
        return result

package twobucket

import "testing"

func TestSolveMeasurements(t *testing.T) {
	tests := []struct {
		name             string
		one, two, goal   int
		start, bucket    string
		steps, remaining int
	}{
		{"start one", 3, 5, 1, "one", "one", 4, 5},
		{"start two", 3, 5, 1, "two", "two", 8, 3},
		{"larger buckets start one", 7, 11, 2, "one", "one", 14, 11},
		{"larger buckets start two", 7, 11, 2, "two", "two", 18, 7},
		{"first fill solves one", 3, 5, 3, "one", "one", 1, 0},
		{"first fill solves two", 3, 5, 5, "two", "two", 1, 0},
		{"fill other bucket directly", 2, 3, 3, "one", "two", 2, 2},
		{"fill smaller other bucket", 5, 3, 3, "one", "two", 2, 5},
		{"goal in other bucket", 3, 5, 4, "one", "two", 8, 0},
		{"common divisor still solvable", 6, 10, 2, "one", "one", 4, 10},
		{"common divisor reverse", 6, 10, 2, "two", "two", 8, 6},
		{"unit bucket", 1, 3, 3, "one", "two", 2, 1},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			bucket, steps, remaining, err := Solve(tt.one, tt.two, tt.goal, tt.start)
			if err != nil {
				t.Fatalf("Solve returned error: %v", err)
			}
			if bucket != tt.bucket || steps != tt.steps || remaining != tt.remaining {
				t.Fatalf("got (%q, %d, %d), want (%q, %d, %d)", bucket, steps, remaining, tt.bucket, tt.steps, tt.remaining)
			}
		})
	}
}

func TestSolveRejectsInvalidAndImpossibleInputs(t *testing.T) {
	tests := []struct {
		one, two, goal int
		start          string
	}{
		{0, 5, 1, "one"},
		{3, 0, 1, "two"},
		{-3, 5, 1, "one"},
		{3, -5, 1, "two"},
		{3, 5, 0, "one"},
		{3, 5, -1, "one"},
		{3, 5, 1, ""},
		{3, 5, 1, "three"},
		{3, 5, 1, "ONE"},
		{3, 5, 6, "one"},
		{6, 10, 3, "one"},
		{6, 10, 3, "two"},
	}
	for _, tt := range tests {
		if _, _, _, err := Solve(tt.one, tt.two, tt.goal, tt.start); err == nil {
			t.Errorf("Solve(%d, %d, %d, %q) should return an error", tt.one, tt.two, tt.goal, tt.start)
		}
	}
}

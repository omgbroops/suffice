package twobucket

import "errors"

// Solve finds the fewest actions needed to measure goalAmount in either bucket.
func Solve(sizeBucketOne, sizeBucketTwo, goalAmount int, startBucket string) (string, int, int, error) {
	if sizeBucketOne <= 0 || sizeBucketTwo <= 0 || goalAmount <= 0 {
		return "", 0, 0, errors.New("bucket sizes and goal must be positive")
	}
	if startBucket != "one" && startBucket != "two" {
		return "", 0, 0, errors.New("starting bucket must be one or two")
	}
	if goalAmount > sizeBucketOne && goalAmount > sizeBucketTwo {
		return "", 0, 0, errors.New("goal exceeds both bucket sizes")
	}

	a, b := sizeBucketOne, sizeBucketTwo
	for b != 0 {
		a, b = b, a%b
	}
	if goalAmount%a != 0 {
		return "", 0, 0, errors.New("goal cannot be measured with these bucket sizes")
	}

	type state struct {
		one, two, steps int
	}
	first := state{one: sizeBucketOne, steps: 1}
	forbidden := [2]int{0, sizeBucketTwo}
	if startBucket == "two" {
		first = state{two: sizeBucketTwo, steps: 1}
		forbidden = [2]int{sizeBucketOne, 0}
	}
	queue := []state{first}
	seen := map[[2]int]bool{{first.one, first.two}: true}
	for head := 0; head < len(queue); head++ {
		current := queue[head]
		if current.one == goalAmount {
			return "one", current.steps, current.two, nil
		}
		if current.two == goalAmount {
			return "two", current.steps, current.one, nil
		}

		pourToTwo := current.one
		if room := sizeBucketTwo - current.two; pourToTwo > room {
			pourToTwo = room
		}
		pourToOne := current.two
		if room := sizeBucketOne - current.one; pourToOne > room {
			pourToOne = room
		}
		nextLevels := [][2]int{
			{sizeBucketOne, current.two},
			{current.one, sizeBucketTwo},
			{0, current.two},
			{current.one, 0},
			{current.one - pourToTwo, current.two + pourToTwo},
			{current.one + pourToOne, current.two - pourToOne},
		}
		for _, levels := range nextLevels {
			// Previously visited states also exclude actions that change nothing.
			if levels == forbidden || seen[levels] {
				continue
			}
			seen[levels] = true
			queue = append(queue, state{levels[0], levels[1], current.steps + 1})
		}
	}
	return "", 0, 0, errors.New("no solution found")
}

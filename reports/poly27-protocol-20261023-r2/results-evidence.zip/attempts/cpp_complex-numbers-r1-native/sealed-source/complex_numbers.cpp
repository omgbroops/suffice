#include "complex_numbers.h"

#include <cmath>
#include <ostream>

namespace complex_numbers {

Complex::Complex(double real, double imaginary)
    : real_{real}, imaginary_{imaginary} {}

Complex Complex::operator+(const Complex& other) const {
    return {real_ + other.real_, imaginary_ + other.imaginary_};
}

Complex Complex::operator-(const Complex& other) const {
    return {real_ - other.real_, imaginary_ - other.imaginary_};
}

Complex Complex::operator*(const Complex& other) const {
    return {real_ * other.real_ - imaginary_ * other.imaginary_,
            imaginary_ * other.real_ + real_ * other.imaginary_};
}

Complex Complex::operator/(const Complex& other) const {
    const double denominator = other.real_ * other.real_ +
                               other.imaginary_ * other.imaginary_;
    return {(real_ * other.real_ + imaginary_ * other.imaginary_) / denominator,
            (imaginary_ * other.real_ - real_ * other.imaginary_) / denominator};
}

double Complex::abs() const {
    return std::hypot(real_, imaginary_);
}

Complex Complex::conj() const {
    return {real_, -imaginary_};
}

double Complex::real() const {
    return real_;
}

double Complex::imag() const {
    return imaginary_;
}

Complex Complex::exp() const {
    const double magnitude = std::exp(real_);
    return {magnitude * std::cos(imaginary_), magnitude * std::sin(imaginary_)};
}

bool operator==(const Complex& left, const Complex& right) {
    return left.real() == right.real() && left.imag() == right.imag();
}

std::ostream& operator<<(std::ostream& stream, const Complex& value) {
    return stream << '(' << value.real() << ',' << value.imag() << ')';
}

Complex operator+(const Complex& left, double right) {
    return left + Complex{right, 0.0};
}

Complex operator+(double left, const Complex& right) {
    return Complex{left, 0.0} + right;
}

Complex operator-(const Complex& left, double right) {
    return left - Complex{right, 0.0};
}

Complex operator-(double left, const Complex& right) {
    return Complex{left, 0.0} - right;
}

Complex operator*(const Complex& left, double right) {
    return {left.real() * right, left.imag() * right};
}

Complex operator*(double left, const Complex& right) {
    return right * left;
}

Complex operator/(const Complex& left, double right) {
    return {left.real() / right, left.imag() / right};
}

Complex operator/(double left, const Complex& right) {
    return Complex{left, 0.0} / right;
}

}  // namespace complex_numbers

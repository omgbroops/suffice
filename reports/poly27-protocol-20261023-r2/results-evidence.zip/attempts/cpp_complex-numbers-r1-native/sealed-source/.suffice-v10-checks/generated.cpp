#include "catch.hpp"
#include "complex_numbers.h"

#include <cmath>
#include <sstream>

using complex_numbers::Complex;

TEST_CASE("Construction and exact component equality") {
    const Complex z{1.25, -2.5};
    REQUIRE(z.real() == 1.25);
    REQUIRE(z.imag() == -2.5);
    REQUIRE(z == Complex{1.25, -2.5});
    REQUIRE_FALSE(z == Complex{1.25, 2.5});
    REQUIRE_FALSE(z == Complex{2.5, -2.5});
    REQUIRE(Complex{0.0, -0.0} == Complex{-0.0, 0.0});
}

TEST_CASE("Complex arithmetic follows the component formulas") {
    const Complex a{1, 2};
    const Complex b{3, 4};
    REQUIRE(a + b == Complex{4, 6});
    REQUIRE(a - b == Complex{-2, -2});
    REQUIRE(a * b == Complex{-5, 10});
    const Complex quotient = a / b;
    REQUIRE(quotient.real() == Approx(0.44));
    REQUIRE(quotient.imag() == Approx(0.08));
    REQUIRE(a == Complex{1, 2});
    REQUIRE(b == Complex{3, 4});
}

TEST_CASE("Zero, real, and imaginary arithmetic") {
    const Complex zero{0, 0};
    const Complex i{0, 1};
    REQUIRE(i * i == Complex{-1, 0});
    REQUIRE(i / i == Complex{1, 0});
    REQUIRE(zero / i == zero);
    REQUIRE(i + zero == i);
    REQUIRE(i - i == zero);
    REQUIRE(i * zero == zero);
    REQUIRE(Complex{6, 0} / Complex{3, 0} == Complex{2, 0});
    REQUIRE(Complex{0, 6} / Complex{0, 3} == Complex{2, 0});
    REQUIRE(Complex{6, 0} / Complex{0, 3} == Complex{0, -2});
}

TEST_CASE("Mixed arithmetic supports doubles on either side") {
    const Complex z{1, 2};
    REQUIRE(z + 3.0 == Complex{4, 2});
    REQUIRE(3.0 + z == Complex{4, 2});
    REQUIRE(z - 3.0 == Complex{-2, 2});
    REQUIRE(3.0 - z == Complex{2, -2});
    REQUIRE(z * 3.0 == Complex{3, 6});
    REQUIRE(3.0 * z == Complex{3, 6});
    REQUIRE(z / 2.0 == Complex{0.5, 1});
    const Complex quotient = 3.0 / z;
    REQUIRE(quotient.real() == Approx(0.6));
    REQUIRE(quotient.imag() == Approx(-1.2));
    REQUIRE(z * 0.0 == Complex{0, 0});
    REQUIRE(0.0 / z == Complex{0, 0});
}

TEST_CASE("Absolute value and conjugation") {
    const Complex z{-3, -4};
    REQUIRE(z.abs() == Approx(5));
    REQUIRE(Complex{0, 0}.abs() == 0);
    REQUIRE(Complex{-5, 0}.abs() == 5);
    REQUIRE(Complex{0, -5}.abs() == 5);
    REQUIRE(z.conj() == Complex{-3, 4});
    REQUIRE(z.conj().conj() == z);
    REQUIRE(z * z.conj() == Complex{25, 0});
    REQUIRE(Complex{1e200, 1e200}.abs() / 1e200 == Approx(std::sqrt(2.0)));
}

TEST_CASE("Exponential uses Euler's formula") {
    const double pi = std::acos(-1.0);
    REQUIRE(Complex{0, 0}.exp() == Complex{1, 0});
    const Complex real_exp = Complex{1, 0}.exp();
    REQUIRE(real_exp.real() == Approx(std::exp(1.0)));
    REQUIRE(real_exp.imag() == 0);
    const Complex imaginary_exp = Complex{0, pi}.exp();
    REQUIRE(imaginary_exp.real() == Approx(-1));
    REQUIRE(imaginary_exp.imag() == Approx(0).margin(1e-12));
    const Complex general_exp = Complex{std::log(2.0), pi / 4}.exp();
    REQUIRE(general_exp.real() == Approx(std::sqrt(2.0)));
    REQUIRE(general_exp.imag() == Approx(std::sqrt(2.0)));
}

TEST_CASE("Streaming writes both components and permits chaining") {
    std::ostringstream stream;
    std::ostream& result = stream << Complex{1.25, -2.5};
    REQUIRE(&result == &stream);
    REQUIRE(stream.str().find("1.25") != std::string::npos);
    REQUIRE(stream.str().find("-2.5") != std::string::npos);
    result << 'x';
    REQUIRE(stream.str().back() == 'x');
}

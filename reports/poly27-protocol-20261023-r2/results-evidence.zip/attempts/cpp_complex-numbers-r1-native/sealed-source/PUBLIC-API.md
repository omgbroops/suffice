# Public interface

namespace complex_numbers { class Complex { public: Complex(double real, double imaginary); Complex operator+(const Complex&) const; Complex operator-(const Complex&) const; Complex operator*(const Complex&) const; Complex operator/(const Complex&) const; double abs() const; Complex conj() const; double real() const; double imag() const; Complex exp() const; }; bool operator==(const Complex&, const Complex&); std::ostream& operator<<(std::ostream&, const Complex&); }
Also provide free arithmetic operators +, -, *, / for (Complex, double) and (double, Complex).

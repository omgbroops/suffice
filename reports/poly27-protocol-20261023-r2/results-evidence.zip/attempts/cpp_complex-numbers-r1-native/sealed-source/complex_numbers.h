#if !defined(COMPLEX_NUMBERS_H)
#define COMPLEX_NUMBERS_H

#include <iosfwd>

namespace complex_numbers {

class Complex {
public:
    Complex(double real, double imaginary);

    Complex operator+(const Complex&) const;
    Complex operator-(const Complex&) const;
    Complex operator*(const Complex&) const;
    Complex operator/(const Complex&) const;

    double abs() const;
    Complex conj() const;
    double real() const;
    double imag() const;
    Complex exp() const;

private:
    double real_;
    double imaginary_;
};

bool operator==(const Complex&, const Complex&);
std::ostream& operator<<(std::ostream&, const Complex&);

Complex operator+(const Complex&, double);
Complex operator+(double, const Complex&);
Complex operator-(const Complex&, double);
Complex operator-(double, const Complex&);
Complex operator*(const Complex&, double);
Complex operator*(double, const Complex&);
Complex operator/(const Complex&, double);
Complex operator/(double, const Complex&);

}  // namespace complex_numbers

#endif  // COMPLEX_NUMBERS_H

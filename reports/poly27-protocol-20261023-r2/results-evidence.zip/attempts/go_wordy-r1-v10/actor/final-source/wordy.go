package wordy

import (
	"strconv"
	"strings"
)

// Answer evaluates a word problem containing integer arithmetic. Operations are
// applied from left to right, as specified by the word-problem format.
func Answer(question string) (int, bool) {
	const prefix = "What is "
	if !strings.HasPrefix(question, prefix) {
		return 0, false
	}

	expression := strings.TrimSuffix(strings.TrimPrefix(question, prefix), "?")
	fields := strings.Fields(expression)
	if len(fields) == 0 {
		return 0, false
	}

	value, err := strconv.Atoi(fields[0])
	if err != nil {
		return 0, false
	}

	for i := 1; i < len(fields); {
		var op byte
		switch fields[i] {
		case "plus":
			op = '+'
			i++
		case "minus":
			op = '-'
			i++
		case "multiplied":
			if i+1 >= len(fields) || fields[i+1] != "by" {
				return 0, false
			}
			op = '*'
			i += 2
		case "divided":
			if i+1 >= len(fields) || fields[i+1] != "by" {
				return 0, false
			}
			op = '/'
			i += 2
		default:
			return 0, false
		}

		if i >= len(fields) {
			return 0, false
		}
		operand, err := strconv.Atoi(fields[i])
		if err != nil {
			return 0, false
		}
		i++

		switch op {
		case '+':
			value += operand
		case '-':
			value -= operand
		case '*':
			value *= operand
		case '/':
			if operand == 0 {
				return 0, false
			}
			value /= operand
		}
	}

	return value, true
}

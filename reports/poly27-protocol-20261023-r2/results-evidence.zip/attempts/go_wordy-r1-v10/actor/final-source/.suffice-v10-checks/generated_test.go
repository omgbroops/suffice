package wordy

import "testing"

func TestWordyPublicExamples(t *testing.T) {
	tests := []struct {
		question string
		want     int
	}{
		{"What is 5?", 5},
		{"What is 5 plus 13?", 18},
		{"What is 7 minus 5?", 2},
		{"What is 6 multiplied by 4?", 24},
		{"What is 25 divided by 5?", 5},
		{"What is 5 plus 13 plus 6?", 24},
		{"What is 3 plus 2 multiplied by 3?", 15},
		{"What is -1000000 plus 7?", -999993},
		{"What is 10 divided by 3?", 3},
	}
	for _, test := range tests {
		got, ok := Answer(test.question)
		if !ok || got != test.want {
			t.Errorf("Answer(%q) = (%d, %v), want (%d, true)", test.question, got, ok, test.want)
		}
	}
}

func TestWordyRejectsInvalidQuestions(t *testing.T) {
	for _, question := range []string{
		"What is 52 cubed?",
		"Who is the President of the United States",
		"What is 1 plus plus 2?",
		"What is",
		"What is 1 divided by 0?",
		"What is 1 multiplied 2?",
		"What is 1 plus 2 extra?",
	} {
		if got, ok := Answer(question); ok {
			t.Errorf("Answer(%q) = (%d, true), want rejection", question, got)
		}
	}
}

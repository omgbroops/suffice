import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Satellite {
    public Tree treeFromTraversals(List<Character> preorderInput, List<Character> inorderInput) {
        if (preorderInput.size() != inorderInput.size()) {
            throw new IllegalArgumentException("traversals must have the same length");
        }

        Map<Character, Integer> inorderPositions = new HashMap<>();
        int position = 0;
        for (Character value : inorderInput) {
            if (inorderPositions.put(value, position++) != null) {
                throw new IllegalArgumentException("traversals must contain unique items");
            }
        }

        Set<Character> preorderValues = new HashSet<>(preorderInput);
        if (preorderValues.size() != preorderInput.size()) {
            throw new IllegalArgumentException("traversals must contain unique items");
        }
        if (!preorderValues.equals(inorderPositions.keySet())) {
            throw new IllegalArgumentException("traversals must have the same elements");
        }

        return new Tree(buildTree(preorderInput.iterator(), inorderPositions, 0, inorderInput.size()));
    }

    private Node buildTree(Iterator<Character> preorder, Map<Character, Integer> inorderPositions,
                           int start, int end) {
        if (start == end) {
            return null;
        }

        char value = preorder.next();
        int rootPosition = inorderPositions.get(value);
        if (rootPosition < start || rootPosition >= end) {
            throw new IllegalArgumentException("traversals must describe the same tree");
        }

        Node root = new Node(value);
        root.left = buildTree(preorder, inorderPositions, start, rootPosition);
        root.right = buildTree(preorder, inorderPositions, rootPosition + 1, end);
        return root;
    }
}

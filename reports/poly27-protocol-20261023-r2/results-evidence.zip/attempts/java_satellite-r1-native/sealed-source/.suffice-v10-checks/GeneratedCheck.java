import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class GeneratedCheck {
    private final Satellite satellite = new Satellite();

    private List<Character> characters(String values) {
        List<Character> result = new ArrayList<>();
        for (char value : values.toCharArray()) {
            result.add(value);
        }
        return result;
    }

    private void assertTree(String preorder, String inorder, String postorder) {
        Tree tree = satellite.treeFromTraversals(characters(preorder), characters(inorder));
        assertEquals(characters(preorder), tree.preorder());
        assertEquals(characters(inorder), tree.inorder());
        assertEquals(characters(postorder), tree.postorder());
    }

    @Test
    void emptyTree() {
        assertTree("", "", "");
    }

    @Test
    void singleNode() {
        assertTree("a", "a", "a");
    }

    @Test
    void exampleTree() {
        assertTree("aixfr", "iafxr", "ifrxa");
    }

    @Test
    void balancedTree() {
        assertTree("dbacfeg", "abcdefg", "acbegfd");
    }

    @Test
    void oneSidedTrees() {
        assertTree("abcd", "dcba", "dcba");
        assertTree("abcd", "abcd", "dcba");
    }

    @Test
    void alternatingBranchesAndNonAlphabeticValues() {
        assertTree("aB1?", "B?1a", "?1Ba");
    }

    @Test
    void inputsAreUnchangedAndLinkedListsAreSupported() {
        List<Character> preorder = new LinkedList<>(characters("aixfr"));
        List<Character> inorder = new LinkedList<>(characters("iafxr"));
        Tree tree = satellite.treeFromTraversals(preorder, inorder);
        assertEquals(characters("ifrxa"), tree.postorder());
        assertEquals(characters("aixfr"), preorder);
        assertEquals(characters("iafxr"), inorder);
    }

    @Test
    void immutableInputsAndRepeatedCallsAreSupported() {
        Tree first = satellite.treeFromTraversals(List.of('b', 'a', 'c'), List.of('a', 'b', 'c'));
        Tree second = satellite.treeFromTraversals(List.of('z'), List.of('z'));
        assertEquals(characters("acb"), first.postorder());
        assertEquals(characters("z"), second.postorder());
    }

    @Test
    void rejectsDifferentLengths() {
        assertThrows(IllegalArgumentException.class,
                () -> satellite.treeFromTraversals(characters("ab"), characters("a")));
        assertThrows(IllegalArgumentException.class,
                () -> satellite.treeFromTraversals(List.of(), List.of('a')));
    }

    @Test
    void rejectsDifferentElements() {
        assertThrows(IllegalArgumentException.class,
                () -> satellite.treeFromTraversals(characters("ab"), characters("ac")));
    }

    @Test
    void rejectsRepeatingItemsInEitherTraversal() {
        assertThrows(IllegalArgumentException.class,
                () -> satellite.treeFromTraversals(characters("aa"), characters("aa")));
        assertThrows(IllegalArgumentException.class,
                () -> satellite.treeFromTraversals(characters("aab"), characters("abb")));
        assertThrows(IllegalArgumentException.class,
                () -> satellite.treeFromTraversals(characters("aab"), characters("abc")));
        assertThrows(IllegalArgumentException.class,
                () -> satellite.treeFromTraversals(characters("abc"), characters("abb")));
    }

    @Test
    void rejectsIncompatibleTraversalOrders() {
        assertThrows(IllegalArgumentException.class,
                () -> satellite.treeFromTraversals(characters("abc"), characters("cab")));
    }
}

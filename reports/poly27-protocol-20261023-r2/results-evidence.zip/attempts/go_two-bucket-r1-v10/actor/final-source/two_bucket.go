package twobucket

import "fmt"

type bucketState struct {
	one   int
	two   int
	steps int
}

func Solve(sizeBucketOne, sizeBucketTwo, goalAmount int, startBucket string) (goalBucket string, numSteps, otherBucketLevel int, e error) {
	if sizeBucketOne <= 0 || sizeBucketTwo <= 0 || sizeBucketOne == sizeBucketTwo {
		return "", 0, 0, fmt.Errorf("bucket sizes must be positive and different")
	}
	if goalAmount <= 0 || goalAmount > sizeBucketOne && goalAmount > sizeBucketTwo {
		return "", 0, 0, fmt.Errorf("invalid goal amount")
	}
	if startBucket != "one" && startBucket != "two" {
		return "", 0, 0, fmt.Errorf("invalid starting bucket %q", startBucket)
	}

	start := bucketState{}
	if startBucket == "one" {
		start.one = sizeBucketOne
	} else {
		start.two = sizeBucketTwo
	}
	start.steps = 1
	seen := map[[2]int]bool{{start.one, start.two}: true}
	queue := []bucketState{start}

	for len(queue) > 0 {
		current := queue[0]
		queue = queue[1:]
		if current.one == goalAmount {
			return "one", current.steps, current.two, nil
		}
		if current.two == goalAmount {
			return "two", current.steps, current.one, nil
		}

		one, two := current.one, current.two
		transfer := one
		if sizeBucketTwo-two < transfer {
			transfer = sizeBucketTwo - two
		}
		addState := func(nextOne, nextTwo int) {
			// The starting bucket must never be empty while the other is full.
			if (startBucket == "one" && nextOne == 0 && nextTwo == sizeBucketTwo) ||
				(startBucket == "two" && nextTwo == 0 && nextOne == sizeBucketOne) {
				return
			}
			key := [2]int{nextOne, nextTwo}
			if !seen[key] {
				seen[key] = true
				queue = append(queue, bucketState{one: nextOne, two: nextTwo, steps: current.steps + 1})
			}
		}
		// Fill or empty either bucket, and pour in either direction.
		addState(sizeBucketOne, two)
		addState(one, sizeBucketTwo)
		addState(0, two)
		addState(one, 0)
		addState(one-transfer, two+transfer)

		transfer = two
		if sizeBucketOne-one < transfer {
			transfer = sizeBucketOne - one
		}
		addState(one+transfer, two-transfer)
	}
	return "", 0, 0, fmt.Errorf("goal amount cannot be measured")
}

package twobucket

import "testing"

func TestSolveClassic(t *testing.T) {
	bucket, steps, other, err := Solve(3, 5, 1, "one")
	if err != nil || bucket != "one" || steps != 4 || other != 5 {
		t.Fatalf("Solve(3,5,1,one) = %q, %d, %d, %v; want one, 4, 3, nil", bucket, steps, other, err)
	}
}

func TestSolveOtherDirection(t *testing.T) {
	bucket, steps, other, err := Solve(7, 11, 6, "one")
	if err != nil || bucket != "one" || steps != 10 || other != 11 {
		t.Fatalf("Solve(7,11,6,one) = %q, %d, %d, %v; want one, 14, 8, nil", bucket, steps, other, err)
	}
}

func TestSolveGoalStartsFull(t *testing.T) {
	bucket, steps, other, err := Solve(7, 11, 7, "one")
	if err != nil || bucket != "one" || steps != 1 || other != 0 {
		t.Fatalf("got %q, %d, %d, %v; want one, 1, 0, nil", bucket, steps, other, err)
	}
}

func TestSolveRejectsInvalidAndImpossible(t *testing.T) {
	cases := []struct {
		one, two, goal int
		start string
	}{
		{0, 5, 1, "one"},
		{3, 3, 1, "one"},
		{3, 5, 0, "one"},
		{3, 5, 6, "one"},
		{3, 5, 1, "bad"},
		{4, 6, 3, "one"},
	}
	for _, tc := range cases {
		if _, _, _, err := Solve(tc.one, tc.two, tc.goal, tc.start); err == nil {
			t.Errorf("Solve(%d,%d,%d,%q) returned nil error", tc.one, tc.two, tc.goal, tc.start)
		}
	}
}

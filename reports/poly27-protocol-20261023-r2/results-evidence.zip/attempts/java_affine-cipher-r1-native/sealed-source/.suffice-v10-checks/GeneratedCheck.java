import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class GeneratedCheck {
    private final AffineCipher cipher = new AffineCipher();

    @Test
    void encryptsAndDecryptsInstructionExamples() {
        assertEquals("ybty", cipher.encode("test", 5, 7));
        assertEquals("test", cipher.decode("ybty", 5, 7));
        assertEquals("lqul", cipher.decode("ybty", 11, 7));
        String plaintext = "thequickbrownfoxjumpsoverthelazydog";
        String ciphertext = "kqlfd jzvgy tpaet icdhm rtwly kqlon ubstx";
        assertEquals(ciphertext, cipher.encode(plaintext, 19, 13));
        assertEquals(plaintext, cipher.decode(ciphertext, 19, 13));
    }

    @Test
    void filtersPunctuationNormalizesCaseAndPreservesDigits() {
        assertEquals("ybty1 2345", cipher.encode("TeSt, 12! 345.", 5, 7));
        assertEquals("test12345", cipher.decode("YBTY1 23!45.", 5, 7));
        assertEquals("01234 56789", cipher.encode("0123456789", 3, 4));
        assertEquals("0123456789", cipher.decode("01234 56789", 3, 4));
    }

    @Test
    void groupsOnlyEncodedOutputWithoutTrailingSpaces() {
        assertEquals("abcde", cipher.encode("a b, c! d? e", 1, 0));
        assertEquals("abcde f", cipher.encode("abcdef", 1, 0));
        assertEquals("abcde fghij", cipher.encode("abcdefghij", 1, 0));
        assertEquals("abcdef", cipher.decode("a bc def", 1, 0));
    }

    @Test
    void handlesEmptyAndPunctuationOnlyInput() {
        for (String text : new String[] {"", " \t\n.,!?-"}) {
            assertEquals("", cipher.encode(text, 5, 7));
            assertEquals("", cipher.decode(text, 5, 7));
        }
    }

    @Test
    void rejectsNonCoprimeKeysEvenForEmptyInput() {
        for (int key : new int[] {0, 2, 13, 18, 26, -13, Integer.MIN_VALUE}) {
            assertThrows(IllegalArgumentException.class, () -> cipher.encode("test", key, 7));
            assertThrows(IllegalArgumentException.class, () -> cipher.decode("ybty", key, 7));
            assertThrows(IllegalArgumentException.class, () -> cipher.encode("", key, 7));
            assertThrows(IllegalArgumentException.class, () -> cipher.decode("", key, 7));
        }
    }

    @Test
    void usesMathematicalModuloAndAvoidsIntegerOverflow() {
        assertEquals("czhc", cipher.encode("test", -5, -7));
        assertEquals("test", cipher.decode("czhc", -5, -7));
        assertEquals("czwli f0123 45", cipher.encode("abcxyz012345", Integer.MAX_VALUE, Integer.MIN_VALUE));
        assertEquals("abcxyz012345", cipher.decode("czwli f0123 45", Integer.MAX_VALUE, Integer.MIN_VALUE));
    }

    @Test
    void roundTripsEveryLetterAndDigitForAllCoprimeResidues() {
        String plaintext = "abcdefghijklmnopqrstuvwxyz0123456789";
        for (int multiplier : new int[] {1, 3, 5, 7, 9, 11, 15, 17, 19, 21, 23, 25}) {
            for (int offset = 0; offset < 26; offset++) {
                assertEquals(plaintext, cipher.decode(cipher.encode(plaintext, multiplier, offset), multiplier, offset));
            }
        }
    }
}

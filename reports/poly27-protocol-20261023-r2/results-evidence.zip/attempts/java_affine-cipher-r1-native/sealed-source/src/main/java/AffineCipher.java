public class AffineCipher {
    private static final int ALPHABET_SIZE = 26;

    public String encode(String text, int coefficient1, int coefficient2) {
        int multiplier = validateMultiplier(coefficient1);
        int offset = Math.floorMod(coefficient2, ALPHABET_SIZE);
        return transform(text, multiplier, offset, true);
    }

    public String decode(String text, int coefficient1, int coefficient2) {
        int multiplier = validateMultiplier(coefficient1);
        int inverse = 1;
        while (multiplier * inverse % ALPHABET_SIZE != 1) {
            inverse++;
        }
        int offset = -inverse * Math.floorMod(coefficient2, ALPHABET_SIZE);
        return transform(text, inverse, offset, false);
    }

    private int validateMultiplier(int coefficient) {
        int multiplier = Math.floorMod(coefficient, ALPHABET_SIZE);
        if (multiplier % 2 == 0 || multiplier % 13 == 0) {
            throw new IllegalArgumentException("Error: keyA and alphabet size must be coprime.");
        }
        return multiplier;
    }

    private String transform(String text, int multiplier, int offset, boolean grouped) {
        StringBuilder result = new StringBuilder();
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            char character = text.charAt(i);
            if (character >= 'A' && character <= 'Z') {
                character = (char) (character - 'A' + 'a');
            }
            if (character >= 'a' && character <= 'z') {
                int index = Math.floorMod(multiplier * (character - 'a') + offset, ALPHABET_SIZE);
                character = (char) ('a' + index);
            } else if (character < '0' || character > '9') {
                continue;
            }
            if (grouped && count > 0 && count % 5 == 0) {
                result.append(' ');
            }
            result.append(character);
            count++;
        }
        return result.toString();
    }
}

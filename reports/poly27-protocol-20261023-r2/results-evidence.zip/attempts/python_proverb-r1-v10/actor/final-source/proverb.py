def proverb(*input_data, qualifier=None):
    """Return the verses of the proverb for the supplied items."""
    if not input_data:
        return []

    verses = [
        f"For want of a {first} the {second} was lost."
        for first, second in zip(input_data, input_data[1:])
    ]

    final_item = f"{qualifier} {input_data[0]}" if qualifier else input_data[0]
    verses.append(f"And all for the want of a {final_item}.")
    return verses

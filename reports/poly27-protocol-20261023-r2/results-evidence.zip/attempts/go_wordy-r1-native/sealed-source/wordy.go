package wordy

import (
	"strconv"
	"strings"
)

// Answer evaluates a word problem from left to right.
func Answer(question string) (int, bool) {
	if !strings.HasPrefix(question, "What is ") || !strings.HasSuffix(question, "?") {
		return 0, false
	}
	words := strings.Fields(question[len("What is ") : len(question)-1])
	if len(words) == 0 {
		return 0, false
	}
	answer, ok := number(words[0])
	if !ok {
		return 0, false
	}
	for i := 1; i < len(words); {
		operation := words[i]
		i++
		switch operation {
		case "plus", "minus":
		case "multiplied", "divided":
			if i >= len(words) || words[i] != "by" {
				return 0, false
			}
			i++
		default:
			return 0, false
		}
		if i >= len(words) {
			return 0, false
		}
		operand, ok := number(words[i])
		if !ok {
			return 0, false
		}
		i++
		switch operation {
		case "plus":
			answer += operand
		case "minus":
			answer -= operand
		case "multiplied":
			answer *= operand
		case "divided":
			if operand == 0 {
				return 0, false
			}
			answer /= operand
		}
	}
	return answer, true
}

func number(word string) (int, bool) {
	digits := strings.TrimPrefix(word, "-")
	if digits == "" {
		return 0, false
	}
	for _, digit := range digits {
		if digit < '0' || digit > '9' {
			return 0, false
		}
	}
	value, err := strconv.Atoi(word)
	return value, err == nil
}

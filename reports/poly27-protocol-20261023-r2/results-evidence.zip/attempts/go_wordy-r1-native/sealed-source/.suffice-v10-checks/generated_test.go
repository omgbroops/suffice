package wordy

import "testing"

func TestValidProblems(t *testing.T) {
	cases := []struct {
		question string
		want     int
	}{
		{"What is 5?", 5},
		{"What is 0?", 0},
		{"What is -123?", -123},
		{"What is 5 plus 13?", 18},
		{"What is 123456789 plus 123456789?", 246913578},
		{"What is -1 plus -10?", -11},
		{"What is 7 minus 5?", 2},
		{"What is 3 minus 8?", -5},
		{"What is -3 minus -8?", 5},
		{"What is 6 multiplied by 4?", 24},
		{"What is -3 multiplied by 25?", -75},
		{"What is -3 multiplied by -25?", 75},
		{"What is 25 divided by 5?", 5},
		{"What is -12 divided by 2?", -6},
		{"What is 12 divided by -2?", -6},
		{"What is -12 divided by -2?", 6},
		{"What is 0 divided by 5?", 0},
		{"What is 5 plus 13 plus 6?", 24},
		{"What is 3 plus 2 multiplied by 3?", 15},
		{"What is 9 minus 3 minus 2?", 4},
		{"What is 8 minus 2 plus 3?", 9},
		{"What is 2 multiplied by 3 multiplied by 4?", 24},
		{"What is 100 divided by 2 divided by 5?", 10},
		{"What is 20 minus 5 divided by 3 plus 2 multiplied by -4?", -28},
	}
	for _, tc := range cases {
		t.Run(tc.question, func(t *testing.T) {
			got, ok := Answer(tc.question)
			if !ok || got != tc.want {
				t.Fatalf("Answer(%q) = (%d, %v), want (%d, true)", tc.question, got, ok, tc.want)
			}
		})
	}
}

func TestInvalidProblems(t *testing.T) {
	questions := []string{
		"", "What is?", "What is ?", "What is 5", "What is 5??",
		"Who is the President of the United States", "What is 52 cubed?",
		"What is 2 raised to the 5th power?", "What is 1 plus plus 2?",
		"What is plus 1 2?", "What is 1 2 plus?", "What is 1 plus?",
		"What is 1 2?", "What is 1 plus 2 3?", "What is 1 plus minus 2?",
		"What is 1 multiplied 2?", "What is 1 divided 2?",
		"What is 1 multiplied by?", "What is 1 divided by?",
		"What is 1 multiplied by by 2?", "What is 1 plus by 2?",
		"What is 1 divided by 0?", "What is 1.5 plus 2?",
		"What is --2?", "What is -?", "What is two?",
		"What is 999999999999999999999999999999999999999?",
		"What is 5? trailing", "prefix What is 5?",
	}
	for _, question := range questions {
		t.Run(question, func(t *testing.T) {
			if got, ok := Answer(question); ok {
				t.Fatalf("Answer(%q) = (%d, true), want rejection", question, got)
			}
		})
	}
}

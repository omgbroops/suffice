#include "catch.hpp"
#include "sublist.h"

#include <limits>
#include <vector>

using sublist::List_comparison;

TEST_CASE("Equal lists have identical values and order") {
    REQUIRE(sublist::sublist({}, {}) == List_comparison::equal);
    REQUIRE(sublist::sublist({1}, {1}) == List_comparison::equal);
    REQUIRE(sublist::sublist({1, 2, 3}, {1, 2, 3}) == List_comparison::equal);
    REQUIRE(sublist::sublist({2, 2, 2}, {2, 2, 2}) == List_comparison::equal);
}

TEST_CASE("An empty list is contained in every nonempty list") {
    REQUIRE(sublist::sublist({}, {1, 2, 3}) == List_comparison::sublist);
    REQUIRE(sublist::sublist({1, 2, 3}, {}) == List_comparison::superlist);
    REQUIRE(sublist::sublist({}, {0}) == List_comparison::sublist);
    REQUIRE(sublist::sublist({0}, {}) == List_comparison::superlist);
}

TEST_CASE("Contiguous matches can occur at the beginning middle or end") {
    const std::vector<int> longer{1, 2, 3, 4, 5};
    const std::vector<std::vector<int>> parts{{1, 2, 3}, {2, 3, 4},
                                              {3, 4, 5}, {3, 4}, {5}};
    for (const auto& part : parts) {
        REQUIRE(sublist::sublist(part, longer) == List_comparison::sublist);
        REQUIRE(sublist::sublist(longer, part) == List_comparison::superlist);
    }
}

TEST_CASE("Skipped elements and reordered elements do not match") {
    REQUIRE(sublist::sublist({1, 2, 4}, {1, 2, 3, 4, 5}) == List_comparison::unequal);
    REQUIRE(sublist::sublist({1, 2, 3, 4, 5}, {1, 2, 4}) == List_comparison::unequal);
    REQUIRE(sublist::sublist({1, 2, 3}, {1, 3, 2}) == List_comparison::unequal);
    REQUIRE(sublist::sublist({1, 2, 3}, {3, 2, 1}) == List_comparison::unequal);
    REQUIRE(sublist::sublist({7}, {1, 2, 3}) == List_comparison::unequal);
    REQUIRE(sublist::sublist({1, 2, 3}, {7}) == List_comparison::unequal);
}

TEST_CASE("Overlapping candidate matches are retried") {
    REQUIRE(sublist::sublist({1, 1, 2}, {1, 1, 1, 2}) == List_comparison::sublist);
    REQUIRE(sublist::sublist({1, 1, 1, 2}, {1, 1, 2}) == List_comparison::superlist);
    REQUIRE(sublist::sublist({1, 2, 1, 2, 3}, {1, 2, 1, 2, 1, 2, 3}) == List_comparison::sublist);
    REQUIRE(sublist::sublist({1, 1, 1}, {1, 1}) == List_comparison::superlist);
    REQUIRE(sublist::sublist({1, 1, 1}, {1, 1, 2}) == List_comparison::unequal);
    REQUIRE(sublist::sublist({1, 2, 3}, {0, 1, 2}) == List_comparison::unequal);
}

TEST_CASE("All integer values are compared directly") {
    const int low = std::numeric_limits<int>::min();
    const int high = std::numeric_limits<int>::max();
    REQUIRE(sublist::sublist({low, 0, high}, {low, 0, high}) == List_comparison::equal);
    REQUIRE(sublist::sublist({-2, 0}, {low, -2, 0, high}) == List_comparison::sublist);
    REQUIRE(sublist::sublist({low, -2, 0, high}, {0, high}) == List_comparison::superlist);
    REQUIRE(sublist::sublist({low}, {high}) == List_comparison::unequal);
}

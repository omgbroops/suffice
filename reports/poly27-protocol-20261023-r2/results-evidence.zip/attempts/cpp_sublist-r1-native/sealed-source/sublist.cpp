#include "sublist.h"

#include <algorithm>

namespace sublist {

List_comparison sublist(const std::vector<int>& first,
                        const std::vector<int>& second) {
    if (first == second) {
        return List_comparison::equal;
    }

    if (first.size() < second.size()) {
        if (first.empty() || std::search(second.begin(), second.end(),
                                         first.begin(), first.end()) != second.end()) {
            return List_comparison::sublist;
        }
    } else if (second.size() < first.size()) {
        if (second.empty() || std::search(first.begin(), first.end(),
                                          second.begin(), second.end()) != first.end()) {
            return List_comparison::superlist;
        }
    }

    return List_comparison::unequal;
}

}  // namespace sublist

public class AffineCipher {

    private static final int MODULUS = 26;

    public String encode(String text, int coefficient1, int coefficient2) {
        validateCoefficient(coefficient1);

        StringBuilder encoded = new StringBuilder();
        int groupLength = 0;
        for (int i = 0; i < text.length(); i++) {
            char character = text.charAt(i);
            if (character >= 'A' && character <= 'Z') {
                character = Character.toLowerCase(character);
            }
            if (character >= 'a' && character <= 'z') {
                int value = character - 'a';
                int encrypted = (int) Math.floorMod((long) coefficient1 * value + coefficient2, MODULUS);
                encoded.append((char) ('a' + encrypted));
                groupLength++;
            } else if (character >= '0' && character <= '9') {
                encoded.append(character);
                groupLength++;
            }

            if (groupLength == 5) {
                encoded.append(' ');
                groupLength = 0;
            }
        }

        if (encoded.length() > 0 && encoded.charAt(encoded.length() - 1) == ' ') {
            encoded.setLength(encoded.length() - 1);
        }
        return encoded.toString();
    }

    public String decode(String text, int coefficient1, int coefficient2) {
        validateCoefficient(coefficient1);
        int inverse = modularInverse(coefficient1);

        StringBuilder decoded = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char character = text.charAt(i);
            if (character >= 'A' && character <= 'Z') {
                character = Character.toLowerCase(character);
            }
            if (character >= 'a' && character <= 'z') {
                int value = character - 'a';
                int plain = (int) Math.floorMod((long) inverse * (value - (long) coefficient2), MODULUS);
                decoded.append((char) ('a' + plain));
            } else if (character >= '0' && character <= '9') {
                decoded.append(character);
            }
        }
        return decoded.toString();
    }

    private static void validateCoefficient(int coefficient) {
        if (gcd(coefficient, MODULUS) != 1) {
            throw new IllegalArgumentException("Coefficient 'a' and modulus 26 must be coprime.");
        }
    }

    private static long gcd(int value, int modulus) {
        long a = Math.abs((long) value);
        long b = modulus;
        while (b != 0) {
            long remainder = a % b;
            a = b;
            b = remainder;
        }
        return a;
    }

    private static int modularInverse(int coefficient) {
        int normalized = Math.floorMod(coefficient, MODULUS);
        for (int candidate = 1; candidate < MODULUS; candidate++) {
            if ((normalized * candidate) % MODULUS == 1) {
                return candidate;
            }
        }
        throw new IllegalArgumentException("Coefficient 'a' has no modular inverse.");
    }
}

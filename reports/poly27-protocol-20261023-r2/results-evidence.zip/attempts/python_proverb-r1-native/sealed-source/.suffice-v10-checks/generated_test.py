from proverb import proverb


def test_empty_proverb():
    assert proverb() == []
    assert proverb(qualifier="horseshoe") == []


def test_single_item():
    assert proverb("nail") == ["And all for the want of a nail."]


def test_two_items():
    assert proverb("nail", "shoe") == [
        "For want of a nail the shoe was lost.",
        "And all for the want of a nail.",
    ]


def test_full_proverb():
    items = ["nail", "shoe", "horse", "rider", "message", "battle", "kingdom"]
    assert proverb(*items) == [
        "For want of a nail the shoe was lost.",
        "For want of a shoe the horse was lost.",
        "For want of a horse the rider was lost.",
        "For want of a rider the message was lost.",
        "For want of a message the battle was lost.",
        "For want of a battle the kingdom was lost.",
        "And all for the want of a nail.",
    ]


def test_qualifier_only_changes_final_verse():
    assert proverb("nail", "shoe", "horse", qualifier="horseshoe") == [
        "For want of a nail the shoe was lost.",
        "For want of a shoe the horse was lost.",
        "And all for the want of a horseshoe nail.",
    ]
    assert proverb("nail", qualifier="horseshoe") == [
        "And all for the want of a horseshoe nail."
    ]


def test_absent_or_empty_qualifier():
    expected = ["And all for the want of a pin."]
    assert proverb("pin", qualifier=None) == expected
    assert proverb("pin", qualifier="") == expected


def test_arbitrary_items_and_repeated_calls():
    assert proverb("pin", "wheel", "cart") == [
        "For want of a pin the wheel was lost.",
        "For want of a wheel the cart was lost.",
        "And all for the want of a pin.",
    ]
    assert proverb("red thread", "coat", qualifier="strong") == [
        "For want of a red thread the coat was lost.",
        "And all for the want of a strong red thread.",
    ]
    assert proverb() == []

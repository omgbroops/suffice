#include "all_your_base.h"

#include <algorithm>
#include <cstdint>
#include <stdexcept>
#include <vector>

namespace all_your_base {

std::vector<unsigned int> convert(unsigned int input_base,
                                  const std::vector<unsigned int>& input_digits,
                                  unsigned int output_base) {
    if (input_base < 2 || output_base < 2 || input_digits.empty()) {
        throw std::domain_error("bases must be at least 2 and input must not be empty");
    }

    for (const unsigned int digit : input_digits) {
        if (digit >= input_base) {
            throw std::domain_error("input digit is not valid for the input base");
        }
    }

    // Repeated long division converts the digit sequence without constructing
    // an intermediate integer that could overflow.
    std::vector<unsigned int> remaining(input_digits);
    std::vector<unsigned int> result;
    while (!remaining.empty()) {
        unsigned int remainder = 0;
        std::vector<unsigned int> quotient;
        quotient.reserve(remaining.size());

        for (const unsigned int digit : remaining) {
            const std::uint64_t current =
                static_cast<std::uint64_t>(remainder) * input_base + digit;
            const unsigned int quotient_digit =
                static_cast<unsigned int>(current / output_base);
            remainder = static_cast<unsigned int>(current % output_base);
            if (!quotient.empty() || quotient_digit != 0) {
                quotient.push_back(quotient_digit);
            }
        }

        result.push_back(remainder);
        remaining.swap(quotient);
    }

    std::reverse(result.begin(), result.end());
    return result;
}

}  // namespace all_your_base

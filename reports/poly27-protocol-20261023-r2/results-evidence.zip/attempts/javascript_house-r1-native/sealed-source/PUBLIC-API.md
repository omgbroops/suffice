# Public interface

House.verse(verseNumber: number): string[] returns the lines of one verse, numbered from 1. House.verses(start: number, end: number): string[] returns the inclusive verse range, with an empty string between verses.

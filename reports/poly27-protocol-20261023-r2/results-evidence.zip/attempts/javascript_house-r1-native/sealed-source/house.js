//
// This is only a SKELETON file for the 'House' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

const subjects = [
  'the house that Jack built.',
  'the malt',
  'the rat',
  'the cat',
  'the dog',
  'the cow with the crumpled horn',
  'the maiden all forlorn',
  'the man all tattered and torn',
  'the priest all shaven and shorn',
  'the rooster that crowed in the morn',
  'the farmer sowing his corn',
  'the horse and the hound and the horn',
];

const actions = [
  'lay in',
  'ate',
  'killed',
  'worried',
  'tossed',
  'milked',
  'kissed',
  'married',
  'woke',
  'kept',
  'belonged to',
];

export class House {
  static verse(verseNumber) {
    const lines = [`This is ${subjects[verseNumber - 1]}`];

    for (let index = verseNumber - 2; index >= 0; index -= 1) {
      lines.push(`that ${actions[index]} ${subjects[index]}`);
    }

    return lines;
  }

  static verses(start, end) {
    const lines = [];

    for (let verseNumber = start; verseNumber <= end; verseNumber += 1) {
      if (verseNumber > start) lines.push('');
      lines.push(...House.verse(verseNumber));
    }

    return lines;
  }
}

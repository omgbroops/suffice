import { House } from '../house.js';

const expectedVerses = [
  [
    "This is the house that Jack built."
  ],
  [
    "This is the malt",
    "that lay in the house that Jack built."
  ],
  [
    "This is the rat",
    "that ate the malt",
    "that lay in the house that Jack built."
  ],
  [
    "This is the cat",
    "that killed the rat",
    "that ate the malt",
    "that lay in the house that Jack built."
  ],
  [
    "This is the dog",
    "that worried the cat",
    "that killed the rat",
    "that ate the malt",
    "that lay in the house that Jack built."
  ],
  [
    "This is the cow with the crumpled horn",
    "that tossed the dog",
    "that worried the cat",
    "that killed the rat",
    "that ate the malt",
    "that lay in the house that Jack built."
  ],
  [
    "This is the maiden all forlorn",
    "that milked the cow with the crumpled horn",
    "that tossed the dog",
    "that worried the cat",
    "that killed the rat",
    "that ate the malt",
    "that lay in the house that Jack built."
  ],
  [
    "This is the man all tattered and torn",
    "that kissed the maiden all forlorn",
    "that milked the cow with the crumpled horn",
    "that tossed the dog",
    "that worried the cat",
    "that killed the rat",
    "that ate the malt",
    "that lay in the house that Jack built."
  ],
  [
    "This is the priest all shaven and shorn",
    "that married the man all tattered and torn",
    "that kissed the maiden all forlorn",
    "that milked the cow with the crumpled horn",
    "that tossed the dog",
    "that worried the cat",
    "that killed the rat",
    "that ate the malt",
    "that lay in the house that Jack built."
  ],
  [
    "This is the rooster that crowed in the morn",
    "that woke the priest all shaven and shorn",
    "that married the man all tattered and torn",
    "that kissed the maiden all forlorn",
    "that milked the cow with the crumpled horn",
    "that tossed the dog",
    "that worried the cat",
    "that killed the rat",
    "that ate the malt",
    "that lay in the house that Jack built."
  ],
  [
    "This is the farmer sowing his corn",
    "that kept the rooster that crowed in the morn",
    "that woke the priest all shaven and shorn",
    "that married the man all tattered and torn",
    "that kissed the maiden all forlorn",
    "that milked the cow with the crumpled horn",
    "that tossed the dog",
    "that worried the cat",
    "that killed the rat",
    "that ate the malt",
    "that lay in the house that Jack built."
  ],
  [
    "This is the horse and the hound and the horn",
    "that belonged to the farmer sowing his corn",
    "that kept the rooster that crowed in the morn",
    "that woke the priest all shaven and shorn",
    "that married the man all tattered and torn",
    "that kissed the maiden all forlorn",
    "that milked the cow with the crumpled horn",
    "that tossed the dog",
    "that worried the cat",
    "that killed the rat",
    "that ate the malt",
    "that lay in the house that Jack built."
  ]
];

test.each(expectedVerses.map((lines, index) => [index + 1, lines]))(
  'verse %i matches the supplied rhyme exactly',
  (verseNumber, expected) => {
    expect(House.verse(verseNumber)).toEqual(expected);
  },
);

const ranges = [];
for (let start = 1; start <= 12; start += 1) {
  for (let end = start; end <= 12; end += 1) {
    ranges.push([start, end]);
  }
}

test.each(ranges)('verses %i through %i are inclusive and separated correctly', (start, end) => {
  const expected = expectedVerses.slice(start - 1, end)
    .map((lines) => lines.join('\n')).join('\n\n').split('\n');
  expect(House.verses(start, end)).toEqual(expected);
});

test('returned arrays can be modified without changing subsequent recitations', () => {
  const verse = House.verse(12);
  verse[0] = 'changed';
  verse.pop();
  const range = House.verses(1, 12);
  range.splice(0, range.length);
  expect(House.verse(12)).toEqual(expectedVerses[11]);
  expect(House.verses(1, 1)).toEqual(expectedVerses[0]);
});

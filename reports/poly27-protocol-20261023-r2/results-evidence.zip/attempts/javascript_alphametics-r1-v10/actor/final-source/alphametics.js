//
// This is only a SKELETON file for the 'Alphametics' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export const solve = (puzzle) => {
  if (typeof puzzle !== 'string') return null;

  const sides = puzzle.split('=');
  if (sides.length !== 2) return null;

  const addends = sides[0].split('+').map((word) => word.trim());
  const result = sides[1].trim();
  const validWord = (word) => /^[A-Za-z]+$/.test(word);
  if (addends.length === 0 || addends.some((word) => !validWord(word)) || !validWord(result)) {
    return null;
  }

  const letters = new Set([...result, ...addends.flatMap((word) => [...word])]);
  if (letters.size > 10) return null;

  const leading = new Set();
  for (const word of [...addends, result]) {
    if (word.length > 1) leading.add(word[0]);
  }

  const assignment = Object.create(null);
  const used = Array(10).fill(false);
  const maxColumns = Math.max(result.length, ...addends.map((word) => word.length));

  const solveColumn = (column, carry) => {
    if (column === maxColumns) return carry === 0 ? { ...assignment } : null;

    const columnLetters = addends
      .map((word) => word[word.length - 1 - column])
      .filter((letter) => letter !== undefined);

    const assignAddends = (index, sum) => {
      if (index < columnLetters.length) {
        const letter = columnLetters[index];
        if (Object.hasOwn(assignment, letter)) {
          return assignAddends(index + 1, sum + assignment[letter]);
        }

        for (let digit = 0; digit <= 9; digit += 1) {
          if (used[digit] || (digit === 0 && leading.has(letter))) continue;
          assignment[letter] = digit;
          used[digit] = true;
          const solution = assignAddends(index + 1, sum + digit);
          if (solution) return solution;
          delete assignment[letter];
          used[digit] = false;
        }
        return null;
      }

      const total = sum + carry;
      const digit = total % 10;
      const nextCarry = Math.floor(total / 10);
      const resultLetter = result[result.length - 1 - column];

      if (resultLetter === undefined) {
        return digit === 0 ? solveColumn(column + 1, nextCarry) : null;
      }
      if (Object.hasOwn(assignment, resultLetter)) {
        if (assignment[resultLetter] !== digit) return null;
        return solveColumn(column + 1, nextCarry);
      }
      if (used[digit] || (digit === 0 && leading.has(resultLetter))) return null;

      assignment[resultLetter] = digit;
      used[digit] = true;
      const solution = solveColumn(column + 1, nextCarry);
      if (solution) return solution;
      delete assignment[resultLetter];
      used[digit] = false;
      return null;
    };

    return assignAddends(0, 0);
  };

  return solveColumn(0, 0);
};

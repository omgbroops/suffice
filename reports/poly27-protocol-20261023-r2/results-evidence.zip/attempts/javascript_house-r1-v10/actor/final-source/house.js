export class House {
  static #subjects = [
    'the house',
    'the malt',
    'the rat',
    'the cat',
    'the dog',
    'the cow with the crumpled horn',
    'the maiden all forlorn',
    'the man all tattered and torn',
    'the priest all shaven and shorn',
    'the rooster that crowed in the morn',
    'the farmer sowing his corn',
    'the horse and the hound and the horn',
  ];

  static #actions = [
    'that lay in',
    'that ate',
    'that killed',
    'that worried',
    'that tossed',
    'that milked',
    'that kissed',
    'that married',
    'that woke',
    'that kept',
    'that belonged to',
  ];

  static verse(verseNumber) {
    if (!Number.isInteger(verseNumber) || verseNumber < 1 || verseNumber > this.#subjects.length) {
      return [];
    }

    const lines = [`This is ${this.#subjects[verseNumber - 1]}`];
    for (let index = verseNumber - 2; index >= 0; index -= 1) {
      lines.push(`${this.#actions[index]} ${this.#subjects[index]}`);
    }

    lines[lines.length - 1] += ' that Jack built.';
    return lines;
  }

  static verses(start, end) {
    if (!Number.isInteger(start) || !Number.isInteger(end) || start < 1 || end > this.#subjects.length || start > end) {
      return [];
    }

    const result = [];
    for (let verseNumber = start; verseNumber <= end; verseNumber += 1) {
      if (result.length > 0) result.push('');
      result.push(...this.verse(verseNumber));
    }
    return result;
  }
}

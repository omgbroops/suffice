import { House } from '../house.js';

test('returns the first and final verses', () => {
  expect(House.verse(1)).toEqual(['This is the house that Jack built.']);
  expect(House.verse(12)).toEqual([
    'This is the horse and the hound and the horn',
    'that belonged to the farmer sowing his corn',
    'that kept the rooster that crowed in the morn',
    'that woke the priest all shaven and shorn',
    'that married the man all tattered and torn',
    'that kissed the maiden all forlorn',
    'that milked the cow with the crumpled horn',
    'that tossed the dog',
    'that worried the cat',
    'that killed the rat',
    'that ate the malt',
    'that lay in the house that Jack built.',
  ]);
});

test('joins a verse range with blank separators', () => {
  expect(House.verses(1, 2)).toEqual([
    'This is the house that Jack built.',
    '',
    'This is the malt',
    'that lay in the house that Jack built.',
  ]);
});

test('returns no verses for an invalid range', () => {
  expect(House.verse(0)).toEqual([]);
  expect(House.verses(3, 2)).toEqual([]);
});

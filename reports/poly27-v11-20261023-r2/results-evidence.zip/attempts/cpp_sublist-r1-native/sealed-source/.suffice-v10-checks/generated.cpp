#include "catch.hpp"
#include "sublist.h"

#include <limits>
#include <vector>

using sublist::List_comparison;

TEST_CASE("Empty lists and equality") {
    REQUIRE(sublist::sublist({}, {}) == List_comparison::equal);
    REQUIRE(sublist::sublist({}, {1, 2, 3}) == List_comparison::sublist);
    REQUIRE(sublist::sublist({1, 2, 3}, {}) == List_comparison::superlist);
    REQUIRE(sublist::sublist({1, 2, 3}, {1, 2, 3}) == List_comparison::equal);
    REQUIRE(sublist::sublist({7}, {7}) == List_comparison::equal);
}

TEST_CASE("Contiguous matches at each position in both directions") {
    const std::vector<int> whole{1, 2, 3, 4, 5};
    for (const auto& part : std::vector<std::vector<int>>{
             {1, 2, 3}, {3, 4, 5}, {3, 4}, {2, 3, 4}, {1}, {5}}) {
        REQUIRE(sublist::sublist(part, whole) == List_comparison::sublist);
        REQUIRE(sublist::sublist(whole, part) == List_comparison::superlist);
    }
}

TEST_CASE("Order, contiguity, and length matter") {
    REQUIRE(sublist::sublist({1, 2, 4}, {1, 2, 3, 4, 5}) ==
            List_comparison::unequal);
    REQUIRE(sublist::sublist({1, 2, 3, 4, 5}, {1, 2, 4}) ==
            List_comparison::unequal);
    REQUIRE(sublist::sublist({1, 2, 3}, {1, 3, 2}) == List_comparison::unequal);
    REQUIRE(sublist::sublist({1, 2}, {2, 1}) == List_comparison::unequal);
    REQUIRE(sublist::sublist({1}, {2}) == List_comparison::unequal);
    REQUIRE(sublist::sublist({1, 1, 1}, {1, 1}) == List_comparison::superlist);
    REQUIRE(sublist::sublist({1, 1, 2}, {1, 1}) == List_comparison::superlist);
    REQUIRE(sublist::sublist({1, 1, 1}, {1, 2}) == List_comparison::unequal);
}

TEST_CASE("Repeated prefixes allow a later overlapping match") {
    REQUIRE(sublist::sublist({1, 1, 2}, {1, 1, 1, 2}) ==
            List_comparison::sublist);
    REQUIRE(sublist::sublist({1, 2, 1, 2, 1, 3}, {1, 2, 1, 3}) ==
            List_comparison::superlist);
    REQUIRE(sublist::sublist({1, 2, 1, 3}, {1, 2, 1, 2, 1, 4}) ==
            List_comparison::unequal);
}

TEST_CASE("All integer values are compared without changing inputs") {
    const std::vector<int> part{std::numeric_limits<int>::min(), 0,
                                std::numeric_limits<int>::max()};
    const std::vector<int> whole{-1, std::numeric_limits<int>::min(), 0,
                                 std::numeric_limits<int>::max(), -2};
    const auto original_part = part;
    const auto original_whole = whole;
    REQUIRE(sublist::sublist(part, whole) == List_comparison::sublist);
    REQUIRE(sublist::sublist(whole, part) == List_comparison::superlist);
    REQUIRE(part == original_part);
    REQUIRE(whole == original_whole);
}

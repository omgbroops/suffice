class ConnectGame:
    def __init__(self, board):
        self.board = ["".join(row.split()) for row in board.splitlines()
                      if row.strip()]

    def get_winner(self):
        if not self.board:
            return ""

        height, width = len(self.board), len(self.board[0])
        directions = ((-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0))

        for player in ("X", "O"):
            starts = ((row, 0) for row in range(height)) if player == "X" else (
                (0, column) for column in range(width)
            )
            pending = [position for position in starts
                       if self.board[position[0]][position[1]] == player]
            visited = set(pending)

            while pending:
                row, column = pending.pop()
                if (player == "X" and column == width - 1) or (
                    player == "O" and row == height - 1
                ):
                    return player

                for row_delta, column_delta in directions:
                    neighbor = (row + row_delta, column + column_delta)
                    next_row, next_column = neighbor
                    if (0 <= next_row < height and 0 <= next_column < width
                            and neighbor not in visited
                            and self.board[next_row][next_column] == player):
                        visited.add(neighbor)
                        pending.append(neighbor)

        return ""

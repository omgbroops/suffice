from itertools import product

import pytest

from connect import ConnectGame


@pytest.mark.parametrize(("board", "winner"), [
    ("", ""),
    (". ", ""),
    ("X", "X"),
    ("O", "O"),
    ("X X X X", "X"),
    ("O O O O", "O"),
    ("X\nX\nX", "X"),
    ("O\nO\nO", "O"),
    ("X .\n . X", ""),
    ("O .\n . O", ""),
    (". X\n X .", "X"),
    (". O\n O .", "O"),
    ("O O .\n X X X", "X"),
    ("X O .\n X O .", "O"),
    ("X . X\n . . .", ""),
    ("O .\n . .\n O .", ""),
    (". O . X .\n . X X O .\n  O O O X .\n   . X O X O\n    X O O O X", ""),
    ("\n  X X X\n", "X"),
])
def test_winner(board, winner):
    game = ConnectGame(board)
    assert game.get_winner() == winner
    assert game.get_winner() == winner


def connected_by_union_find(cells, height, width):
    """Build undirected components, then check which borders they touch."""
    parent = list(range(len(cells)))

    def root(index):
        while parent[index] != index:
            index = parent[index]
        return index

    for row in range(height):
        for column in range(width):
            index = row * width + column
            for next_row, next_column in ((row, column + 1),
                                          (row + 1, column),
                                          (row + 1, column - 1)):
                if 0 <= next_row < height and 0 <= next_column < width:
                    neighbor = next_row * width + next_column
                    if cells[index] == cells[neighbor] != ".":
                        parent[root(index)] = root(neighbor)

    left = {root(row * width) for row in range(height)
            if cells[row * width] == "X"}
    right = {root(row * width + width - 1) for row in range(height)
             if cells[row * width + width - 1] == "X"}
    top = {root(column) for column in range(width) if cells[column] == "O"}
    bottom = {root((height - 1) * width + column) for column in range(width)
              if cells[(height - 1) * width + column] == "O"}
    if left & right:
        return "X"
    if top & bottom:
        return "O"
    return ""


@pytest.mark.parametrize(("height", "width"), [(1, 3), (3, 1), (2, 3), (3, 2), (3, 3)])
def test_all_small_boards(height, width):
    for cells in product(".XO", repeat=height * width):
        board = "\n".join(" " * row + " ".join(cells[row * width:(row + 1) * width])
                          for row in range(height))
        assert ConnectGame(board).get_winner() == connected_by_union_find(cells, height, width), board


def test_long_connections_do_not_require_recursion():
    assert ConnectGame(" ".join(["X"] * 2000)).get_winner() == "X"
    assert ConnectGame("\n".join(["O"] * 2000)).get_winner() == "O"

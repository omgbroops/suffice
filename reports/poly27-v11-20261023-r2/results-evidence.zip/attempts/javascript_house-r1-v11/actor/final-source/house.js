export class House {
  static verse(verseNumber) {
    const items = [
      {
        subject: 'the malt',
        link: 'that lay in the house that Jack built.',
      },
      { subject: 'the rat', link: 'that ate the malt' },
      { subject: 'the cat', link: 'that killed the rat' },
      { subject: 'the dog', link: 'that worried the cat' },
      {
        subject: 'the cow with the crumpled horn',
        link: 'that tossed the dog',
      },
      {
        subject: 'the maiden all forlorn',
        link: 'that milked the cow with the crumpled horn',
      },
      {
        subject: 'the man all tattered and torn',
        link: 'that kissed the maiden all forlorn',
      },
      {
        subject: 'the priest all shaven and shorn',
        link: 'that married the man all tattered and torn',
      },
      {
        subject: 'the rooster that crowed in the morn',
        link: 'that woke the priest all shaven and shorn',
      },
      {
        subject: 'the farmer sowing his corn',
        link: 'that kept the rooster that crowed in the morn',
      },
      {
        subject: 'the horse and the hound and the horn',
        link: 'that belonged to the farmer sowing his corn',
      },
    ];

    if (!Number.isInteger(verseNumber) || verseNumber < 1 || verseNumber > 12) {
      return [];
    }
    if (verseNumber === 1) return ['This is the house that Jack built.'];

    const lines = [`This is ${items[verseNumber - 2].subject}`];
    for (let index = verseNumber - 2; index >= 0; index -= 1) {
      lines.push(items[index].link);
    }
    return lines;
  }

  static verses(start, end) {
    const result = [];
    for (let number = start; number <= end; number += 1) {
      if (number > start) result.push('');
      result.push(...House.verse(number));
    }
    return result;
  }
}

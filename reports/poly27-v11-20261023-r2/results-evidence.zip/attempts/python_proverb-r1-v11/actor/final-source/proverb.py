def proverb(words, qualifier=None):
    """Return the verses of the proverb for the given sequence of words."""
    if not words:
        return []

    verses = [
        f"For want of a {first} the {second} was lost."
        for first, second in zip(words, words[1:])
    ]

    final_word = f"{qualifier} {words[0]}" if qualifier else str(words[0])
    verses.append(f"And all for the want of a {final_word}.")
    return verses

#include "catch.hpp"
#include "complex_numbers.h"

#include <cmath>
#include <sstream>
#include <type_traits>

using complex_numbers::Complex;

namespace {
void require_parts(const Complex& number, double real, double imaginary) {
    REQUIRE(number.real() == Approx(real).margin(1e-12));
    REQUIRE(number.imag() == Approx(imaginary).margin(1e-12));
}
}

TEST_CASE("Construction and equality preserve both components") {
    const Complex z{3.5, -4.5};
    require_parts(z, 3.5, -4.5);
    REQUIRE(z == Complex{3.5, -4.5});
    REQUIRE_FALSE(z == Complex{3.5, 4.5});
    REQUIRE_FALSE(z == Complex{-3.5, -4.5});
    REQUIRE(Complex{0, 0} == Complex{-0.0, 0});
}

TEST_CASE("Addition and subtraction combine components independently") {
    const Complex a{1, 2};
    const Complex b{3, 4};
    require_parts(a + b, 4, 6);
    require_parts(a - b, -2, -2);
    require_parts(a - a, 0, 0);
    require_parts(Complex{0, 2} + Complex{0, -3}, 0, -1);
    require_parts(Complex{2, 0} - Complex{-3, 0}, 5, 0);
    require_parts(a, 1, 2);
    require_parts(b, 3, 4);
}

TEST_CASE("Multiplication obeys i squared equals minus one") {
    require_parts(Complex{1, 2} * Complex{3, 4}, -5, 10);
    require_parts(Complex{0, 1} * Complex{0, 1}, -1, 0);
    require_parts(Complex{2, 0} * Complex{3, 0}, 6, 0);
    require_parts(Complex{2, -3} * Complex{0, 0}, 0, 0);
    require_parts(Complex{2, -3} * Complex{1, 0}, 2, -3);
}

TEST_CASE("Division handles general numbers and real and imaginary axes") {
    require_parts(Complex{1, 2} / Complex{3, 4}, 11.0 / 25, 2.0 / 25);
    require_parts(Complex{1, 0} / Complex{1, 1}, 0.5, -0.5);
    require_parts(Complex{0, 1} / Complex{0, 1}, 1, 0);
    require_parts(Complex{6, 0} / Complex{3, 0}, 2, 0);
    require_parts(Complex{0, 0} / Complex{-2, 3}, 0, 0);
    require_parts(Complex{-2, 3} / Complex{-2, 3}, 1, 0);
}

TEST_CASE("Conjugate reverses the imaginary component") {
    const Complex z{3, -4};
    require_parts(z.conj(), 3, 4);
    REQUIRE(z.conj().conj() == z);
    require_parts(z * z.conj(), 25, 0);
    require_parts(Complex{0, 2}.conj(), 0, -2);
    require_parts(Complex{2, 0}.conj(), 2, 0);
}

TEST_CASE("Absolute value is the Euclidean magnitude") {
    REQUIRE(Complex{0, 0}.abs() == 0);
    REQUIRE(Complex{-5, 0}.abs() == 5);
    REQUIRE(Complex{0, -5}.abs() == 5);
    REQUIRE(Complex{3, -4}.abs() == 5);
    REQUIRE(Complex{1, 1}.abs() == Approx(std::sqrt(2.0)));
    REQUIRE(std::isfinite(Complex{1e200, 1e200}.abs()));
}

TEST_CASE("Exponent implements Euler's formula") {
    const double pi = std::acos(-1.0);
    require_parts(Complex{0, 0}.exp(), 1, 0);
    require_parts(Complex{1, 0}.exp(), std::exp(1.0), 0);
    require_parts(Complex{0, pi}.exp(), -1, 0);
    require_parts(Complex{0, pi / 2}.exp(), 0, 1);
    require_parts(Complex{std::log(2.0), pi / 4}.exp(),
                  std::sqrt(2.0), std::sqrt(2.0));
}

TEST_CASE("Double arithmetic works on either side including noncommutative operations") {
    const Complex z{3, 4};
    require_parts(z + 2.0, 5, 4);
    require_parts(2.0 + z, 5, 4);
    require_parts(z - 2.0, 1, 4);
    require_parts(2.0 - z, -1, -4);
    require_parts(z * 2.0, 6, 8);
    require_parts(2.0 * z, 6, 8);
    require_parts(z / 2.0, 1.5, 2);
    require_parts(2.0 / z, 6.0 / 25, -8.0 / 25);
    require_parts(0.0 - z, -3, -4);
    require_parts(z * 0.0, 0, 0);
    require_parts(z / -2.0, -1.5, -2);
}

TEST_CASE("Stream insertion supports chaining and returns the same stream") {
    std::ostringstream stream;
    std::ostream& result = stream << Complex{3, -4};
    REQUIRE(&result == &stream);
    REQUIRE_FALSE(stream.str().empty());
    stream << ' ' << Complex{0, 0};
    REQUIRE(stream.good());
}

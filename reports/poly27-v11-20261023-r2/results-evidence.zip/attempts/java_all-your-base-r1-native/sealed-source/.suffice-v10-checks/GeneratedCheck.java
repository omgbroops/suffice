import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GeneratedCheck {
    @Test
    void convertsTheExamplesInBothDirections() {
        int[] binary = {1, 0, 1, 0, 1, 0};
        int[] ternary = {1, 1, 2, 0};
        assertArrayEquals(new int[] {4, 2}, new BaseConverter(2, binary).convertToBase(10));
        assertArrayEquals(binary, new BaseConverter(10, new int[] {4, 2}).convertToBase(2));
        assertArrayEquals(ternary, new BaseConverter(2, binary).convertToBase(3));
        assertArrayEquals(binary, new BaseConverter(3, ternary).convertToBase(2));
    }

    @Test
    void convertsBetweenNonDecimalBases() {
        assertArrayEquals(new int[] {2, 10},
                new BaseConverter(3, new int[] {1, 1, 2, 0}).convertToBase(16));
        assertArrayEquals(new int[] {6, 10, 45},
                new BaseConverter(97, new int[] {3, 46, 60}).convertToBase(73));
        assertArrayEquals(new int[] {15, 15},
                new BaseConverter(10, new int[] {2, 5, 5}).convertToBase(16));
    }

    @Test
    void normalizesZeroAndLeadingZeros() {
        for (int[] digits : new int[][] {{}, {0}, {0, 0, 0}}) {
            assertArrayEquals(new int[] {0}, new BaseConverter(10, digits).convertToBase(2));
        }
        assertArrayEquals(new int[] {4, 2},
                new BaseConverter(10, new int[] {0, 0, 4, 2}).convertToBase(10));
        assertArrayEquals(new int[] {1, 0, 1, 0, 1, 0},
                new BaseConverter(10, new int[] {0, 4, 2}).convertToBase(2));
    }

    @Test
    void rejectsInvalidBases() {
        for (int base : new int[] {Integer.MIN_VALUE, -1, 0, 1}) {
            assertEquals("Bases must be at least 2.", assertThrows(IllegalArgumentException.class,
                    () -> new BaseConverter(base, new int[] {1})).getMessage());
            assertEquals("Bases must be at least 2.", assertThrows(IllegalArgumentException.class,
                    () -> new BaseConverter(2, new int[] {}).convertToBase(base)).getMessage());
        }
    }

    @Test
    void rejectsInvalidDigits() {
        assertEquals("Digits may not be negative.", assertThrows(IllegalArgumentException.class,
                () -> new BaseConverter(10, new int[] {1, -1})).getMessage());
        for (int digit : new int[] {2, 3, Integer.MAX_VALUE}) {
            assertEquals("All digits must be strictly less than the base.",
                    assertThrows(IllegalArgumentException.class,
                            () -> new BaseConverter(2, new int[] {0, digit})).getMessage());
        }
    }

    @Test
    void supportsNumbersBeyondLongRange() {
        int[] binary = new int[129];
        binary[0] = 1;
        int[] hexadecimal = new int[33];
        hexadecimal[0] = 1;
        assertArrayEquals(hexadecimal, new BaseConverter(2, binary).convertToBase(16));
        assertArrayEquals(binary, new BaseConverter(16, hexadecimal).convertToBase(2));
    }

    @Test
    void supportsMaximumIntegerBases() {
        int base = Integer.MAX_VALUE;
        assertArrayEquals(new int[] {1, 2, 0},
                new BaseConverter(base, new int[] {base - 1, base - 1}).convertToBase(base - 1));
        assertArrayEquals(new int[] {base - 1, base - 1},
                new BaseConverter(base - 1, new int[] {1, 2, 0}).convertToBase(base));
    }

    @Test
    void preservesInputAndAllowsRepeatedConversions() {
        int[] input = {4, 2};
        BaseConverter converter = new BaseConverter(10, input);
        assertArrayEquals(new int[] {2, 10}, converter.convertToBase(16));
        assertArrayEquals(new int[] {4, 2}, input);
        input[0] = 9;
        int[] output = converter.convertToBase(10);
        output[0] = 8;
        assertArrayEquals(new int[] {4, 2}, converter.convertToBase(10));
        assertArrayEquals(new int[] {1, 1, 2, 0}, converter.convertToBase(3));
    }
}

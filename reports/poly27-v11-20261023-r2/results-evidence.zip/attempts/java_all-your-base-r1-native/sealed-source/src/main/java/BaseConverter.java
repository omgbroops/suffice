import java.util.ArrayList;
import java.util.List;

class BaseConverter {

    private final int originalBase;
    private final int[] originalDigits;

    BaseConverter(int originalBase, int[] originalDigits) {
        validateBase(originalBase);
        for (int digit : originalDigits) {
            if (digit < 0) {
                throw new IllegalArgumentException("Digits may not be negative.");
            }
            if (digit >= originalBase) {
                throw new IllegalArgumentException("All digits must be strictly less than the base.");
            }
        }
        this.originalBase = originalBase;
        this.originalDigits = originalDigits.clone();
    }

    int[] convertToBase(int newBase) {
        validateBase(newBase);
        int[] quotient = originalDigits.clone();
        List<Integer> reversedDigits = new ArrayList<>();
        int firstNonzero = 0;

        while (firstNonzero < quotient.length && quotient[firstNonzero] == 0) {
            firstNonzero++;
        }
        while (firstNonzero < quotient.length) {
            long remainder = 0;
            // Divide in the original base; each remainder is a new-base digit.
            for (int i = firstNonzero; i < quotient.length; i++) {
                long value = remainder * originalBase + quotient[i];
                quotient[i] = (int) (value / newBase);
                remainder = value % newBase;
            }
            reversedDigits.add((int) remainder);
            while (firstNonzero < quotient.length && quotient[firstNonzero] == 0) {
                firstNonzero++;
            }
        }

        if (reversedDigits.isEmpty()) {
            return new int[] {0};
        }
        int[] result = new int[reversedDigits.size()];
        for (int i = 0; i < result.length; i++) {
            result[i] = reversedDigits.get(result.length - 1 - i);
        }
        return result;
    }

    private static void validateBase(int base) {
        if (base < 2) {
            throw new IllegalArgumentException("Bases must be at least 2.");
        }
    }
}

package twobucket

import "fmt"

type state struct {
	one   int
	two   int
	steps int
}

func Solve(sizeBucketOne, sizeBucketTwo, goalAmount int, startBucket string) (goalBucket string, numSteps, otherBucketLevel int, e error) {
	if sizeBucketOne <= 0 || sizeBucketTwo <= 0 {
		return "", 0, 0, fmt.Errorf("bucket sizes must be positive")
	}
	if sizeBucketOne == sizeBucketTwo {
		return "", 0, 0, fmt.Errorf("bucket sizes must be different")
	}
	if goalAmount < 0 || goalAmount > sizeBucketOne && goalAmount > sizeBucketTwo {
		return "", 0, 0, fmt.Errorf("goal amount is outside the bucket capacities")
	}
	if startBucket != "one" && startBucket != "two" {
		return "", 0, 0, fmt.Errorf("start bucket must be one or two")
	}

	// Breadth-first search finds a solution with the fewest actions, counting
	// the required initial fill. The visited set prevents cycling between
	// states, and the forbidden state check enforces the starting-bucket rule.
	queue := []state{{}}
	visited := map[[2]int]bool{{0, 0}: true}
	for head := 0; head < len(queue); head++ {
		current := queue[head]
		nextStates := [][2]int{
			{sizeBucketOne, current.two}, // fill bucket one
			{current.one, sizeBucketTwo}, // fill bucket two
			{0, current.two},             // empty bucket one
			{current.one, 0},             // empty bucket two
			{current.one - min(current.one, sizeBucketTwo-current.two),
				current.two + min(current.one, sizeBucketTwo-current.two)}, // pour one into two
			{current.one + min(current.two, sizeBucketOne-current.one),
				current.two - min(current.two, sizeBucketOne-current.one)}, // pour two into one
		}

		for _, next := range nextStates {
			if startBucket == "one" && next[0] == 0 && next[1] == sizeBucketTwo ||
				startBucket == "two" && next[1] == 0 && next[0] == sizeBucketOne {
				continue
			}
			key := next
			if visited[key] {
				continue
			}
			visited[key] = true
			steps := current.steps + 1
			if next[0] == goalAmount {
				return "one", steps, next[1], nil
			}
			if next[1] == goalAmount {
				return "two", steps, next[0], nil
			}
			queue = append(queue, state{one: next[0], two: next[1], steps: steps})
		}
	}
	return "", 0, 0, fmt.Errorf("goal amount cannot be reached")
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

package alphametics

import (
	"errors"
	"strings"
	"unicode"
)

func Solve(puzzle string) (map[string]int, error) {
	sides := strings.Split(puzzle, "==")
	if len(sides) != 2 {
		return nil, errors.New("puzzle must contain one == operator")
	}
	terms := strings.Split(sides[0], "+")
	terms = append(terms, sides[1])

	// Encode letters as small indices shared by every word.
	letters := make(map[rune]int)
	var leading []bool
	words := make([][]int, len(terms))
	for i, term := range terms {
		word := []rune(strings.TrimSpace(term))
		if len(word) == 0 {
			return nil, errors.New("puzzle contains an empty word")
		}
		for j, letter := range word {
			if !unicode.IsLetter(letter) {
				return nil, errors.New("words must contain only letters")
			}
			index, ok := letters[letter]
			if !ok {
				index = len(letters)
				letters[letter] = index
				leading = append(leading, false)
			}
			words[i] = append(words[i], index)
			if j == 0 && len(word) > 1 {
				leading[index] = true
			}
		}
	}
	if len(letters) > 10 {
		return nil, errors.New("more letters than available digits")
	}

	addends, result := words[:len(words)-1], words[len(words)-1]
	for _, word := range addends {
		if len(word) > len(result) {
			return nil, errors.New("no solution")
		}
	}
	digits := make([]int, len(letters))
	for i := range digits {
		digits[i] = -1
	}
	var used [10]bool

	// Work from right to left. Once all addends in a column have been
	// assigned, its result digit is forced by the sum and incoming carry.
	var search func(column, row, total int) bool
	search = func(column, row, total int) bool {
		if column == len(result) {
			return total == 0
		}
		for row < len(addends) {
			word := addends[row]
			row++
			if column >= len(word) {
				continue
			}
			letter := word[len(word)-1-column]
			if digits[letter] >= 0 {
				total += digits[letter]
				continue
			}
			for digit := 0; digit < 10; digit++ {
				if used[digit] || (digit == 0 && leading[letter]) {
					continue
				}
				digits[letter], used[digit] = digit, true
				if search(column, row, total+digit) {
					return true
				}
				digits[letter], used[digit] = -1, false
			}
			return false
		}

		letter := result[len(result)-1-column]
		digit, carry := total%10, total/10
		if digits[letter] >= 0 {
			return digits[letter] == digit && search(column+1, 0, carry)
		}
		if used[digit] || (digit == 0 && leading[letter]) {
			return false
		}
		digits[letter], used[digit] = digit, true
		if search(column+1, 0, carry) {
			return true
		}
		digits[letter], used[digit] = -1, false
		return false
	}
	if !search(0, 0, 0) {
		return nil, errors.New("no solution")
	}

	solution := make(map[string]int, len(letters))
	for letter, index := range letters {
		solution[string(letter)] = digits[index]
	}
	return solution, nil
}

package alphametics

import (
	"math/big"
	"reflect"
	"strings"
	"testing"
)

func assertSolution(t *testing.T, puzzle string) map[string]int {
	t.Helper()
	solution, err := Solve(puzzle)
	if err != nil {
		t.Fatalf("Solve(%q): %v", puzzle, err)
	}
	seenLetters := make(map[string]bool)
	seenDigits := make(map[int]string)
	sides := strings.Split(puzzle, "==")
	value := func(word string) *big.Int {
		word = strings.TrimSpace(word)
		n := new(big.Int)
		for i, letter := range []rune(word) {
			key := string(letter)
			digit, ok := solution[key]
			if !ok || digit < 0 || digit > 9 {
				t.Fatalf("invalid or missing digit for %q: %v", key, solution)
			}
			if i == 0 && len([]rune(word)) > 1 && digit == 0 {
				t.Fatalf("leading zero in %q: %v", word, solution)
			}
			if other, used := seenDigits[digit]; used && other != key {
				t.Fatalf("%q and %q share digit %d", other, key, digit)
			}
			seenLetters[key], seenDigits[digit] = true, key
			n.Mul(n, big.NewInt(10))
			n.Add(n, big.NewInt(int64(digit)))
		}
		return n
	}
	sum := new(big.Int)
	for _, word := range strings.Split(sides[0], "+") {
		sum.Add(sum, value(word))
	}
	want := value(sides[1])
	if sum.Cmp(want) != 0 {
		t.Fatalf("Solve(%q) = %v: %s != %s", puzzle, solution, sum, want)
	}
	if len(solution) != len(seenLetters) {
		t.Fatalf("unexpected substitutions: %v", solution)
	}
	return solution
}

func TestSendMoreMoney(t *testing.T) {
	got := assertSolution(t, "SEND + MORE == MONEY")
	want := map[string]int{"M": 1, "O": 0, "N": 6, "E": 5, "Y": 2, "S": 9, "D": 7, "R": 8}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("got %v, want %v", got, want)
	}
}

func TestSolvablePuzzles(t *testing.T) {
	for _, puzzle := range []string{
		"A == A",
		"AA == AA",
		"A + B == A",
		"I + BB == ILL",
		"AS + A == MOM",
		"NO + NO + TOO == LATE",
		"HE + SEES + THE == LIGHT",
		"DONALD + GERALD == ROBERT",
		"THIS + IS + TOO == FUNNY",
		"A+B+C+D+E+F+G+H+I+J == BD",
		"  SEND+MORE==MONEY  ",
		strings.Repeat("A", 80) + " + " + strings.Repeat("A", 80) + " == " + strings.Repeat("B", 80),
	} {
		t.Run(puzzle, func(t *testing.T) { assertSolution(t, puzzle) })
	}
}

func TestNoSolution(t *testing.T) {
	for _, puzzle := range []string{
		"A == B",
		"A == AA",
		"AA == A",
		"A + B == AA",
		"A + B == BA",
		"ABCDEF == GHIJKL",
	} {
		t.Run(puzzle, func(t *testing.T) {
			if solution, err := Solve(puzzle); err == nil {
				t.Fatalf("Solve(%q) returned %v without an error", puzzle, solution)
			}
		})
	}
}

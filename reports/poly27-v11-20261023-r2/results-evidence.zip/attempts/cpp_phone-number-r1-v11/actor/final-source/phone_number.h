#if !defined(PHONE_NUMBER_H)
#define PHONE_NUMBER_H

#include <string>

namespace phone_number {

class phone_number {
 public:
  explicit phone_number(const std::string& input);

  std::string area_code() const;
  std::string number() const;
  explicit operator std::string() const;

 private:
  std::string number_;
};

}  // namespace phone_number

#endif  // PHONE_NUMBER_H

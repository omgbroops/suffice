#include "phone_number.h"

#include <stdexcept>

namespace phone_number {

phone_number::phone_number(const std::string& input) {
  for (const char character : input) {
    if (character >= '0' && character <= '9') {
      number_.push_back(character);
    }
  }

  if (number_.size() == 11 && number_[0] == '1') {
    number_.erase(0, 1);
  } else if (number_.size() != 10) {
    throw std::domain_error("Invalid phone number");
  }

  if (number_[0] < '2' || number_[0] > '9' ||
      number_[3] < '2' || number_[3] > '9') {
    throw std::domain_error("Invalid phone number");
  }
}

std::string phone_number::area_code() const {
  return number_.substr(0, 3);
}

std::string phone_number::number() const {
  return number_;
}

phone_number::operator std::string() const {
  return number_;
}

}  // namespace phone_number

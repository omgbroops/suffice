from math import gcd


_ALPHABET_SIZE = 26


def _validate_key(a):
    if gcd(a, _ALPHABET_SIZE) != 1:
        raise ValueError("a and m must be coprime.")


def encode(plain_text, a, b):
    """Encrypt text with an affine cipher and group output in blocks of five."""
    _validate_key(a)
    encoded = []
    for character in plain_text.lower():
        if character.isalpha() and "a" <= character <= "z":
            value = ord(character) - ord("a")
            encoded.append(chr((a * value + b) % _ALPHABET_SIZE + ord("a")))
        elif character.isdigit():
            encoded.append(character)

    text = "".join(encoded)
    return " ".join(text[index:index + 5] for index in range(0, len(text), 5))


def decode(ciphered_text, a, b):
    """Decrypt text encoded with an affine cipher."""
    _validate_key(a)
    inverse = pow(a, -1, _ALPHABET_SIZE)
    decoded = []
    for character in ciphered_text.lower():
        if character.isalpha() and "a" <= character <= "z":
            value = ord(character) - ord("a")
            decoded.append(chr((inverse * (value - b)) % _ALPHABET_SIZE + ord("a")))
        elif character.isdigit():
            decoded.append(character)
    return "".join(decoded)

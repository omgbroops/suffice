package wordsearch

func Solve(words []string, puzzle []string) (map[string][2][2]int, error) {
	found := make(map[string][2][2]int, len(words))
	if len(puzzle) == 0 {
		return found, nil
	}

	// A puzzle is a square grid. Working with each row's actual length also
	// keeps the search safe if a caller supplies a malformed grid.
	directions := [][2]int{
		{0, 1},   // right
		{1, 1},   // down-right
		{1, 0},   // down
		{1, -1},  // down-left
		{0, -1},  // left
		{-1, -1}, // up-left
		{-1, 0},  // up
		{-1, 1},  // up-right
	}

	for _, word := range words {
		if word == "" {
			continue
		}
		// Words are case-sensitive, as are the letters in the supplied grid.
		for row := range puzzle {
			for col := 0; col < len(puzzle[row]); col++ {
				for _, direction := range directions {
					dr, dc := direction[0], direction[1]
					endRow := row + (len(word)-1)*dr
					endCol := col + (len(word)-1)*dc
					if endRow < 0 || endRow >= len(puzzle) || endCol < 0 {
						continue
					}
					if endCol >= len(puzzle[endRow]) {
						continue
					}

					matches := true
					for i := 0; i < len(word); i++ {
						r, c := row+i*dr, col+i*dc
						if r < 0 || r >= len(puzzle) || c < 0 || c >= len(puzzle[r]) || puzzle[r][c] != word[i] {
							matches = false
							break
						}
					}
					if matches {
						found[word] = [2][2]int{
							{row + 1, col + 1},
							{endRow + 1, endCol + 1},
						}
						goto nextWord
					}
				}
			}
		}
	nextWord:
	}
	return found, nil
}

package wordsearch

import "testing"

func TestAllDirectionsAndSingleLetter(t *testing.T) {
	want := map[string][2][2]int{
		"abc": {{0, 0}, {2, 0}},
		"cba": {{2, 0}, {0, 0}},
		"adg": {{0, 0}, {0, 2}},
		"gda": {{0, 2}, {0, 0}},
		"aei": {{0, 0}, {2, 2}},
		"iea": {{2, 2}, {0, 0}},
		"ceg": {{2, 0}, {0, 2}},
		"gec": {{0, 2}, {2, 0}},
		"e":   {{1, 1}, {1, 1}},
	}
	words := make([]string, 0, len(want))
	for word := range want {
		words = append(words, word)
	}
	got, err := Solve(words, []string{"abc", "def", "ghi"})
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != len(want) {
		t.Fatalf("got %d locations, want %d", len(got), len(want))
	}
	for word, location := range want {
		if actual, ok := got[word]; !ok || actual != location {
			t.Errorf("%q: got %v (present %v), want %v", word, actual, ok, location)
		}
	}
}

func TestExamplePuzzle(t *testing.T) {
	puzzle := []string{
		"jefblpepre", "camdcimgtc", "oivokprjsm", "pbwasqroua", "rixilelhrs",
		"wolcqlirpc", "screeaumgr", "alxhpburyi", "jalaycalmp", "clojurermt",
	}
	got, err := Solve([]string{"clojure", "java"}, puzzle)
	if err != nil {
		t.Fatal(err)
	}
	for word, want := range map[string][2][2]int{
		"clojure": {{0, 9}, {6, 9}},
		"java":    {{0, 0}, {3, 3}},
	} {
		if actual, ok := got[word]; !ok || actual != want {
			t.Errorf("%s: got %v (present %v), want %v", word, actual, ok, want)
		}
	}
}

func TestMissingWords(t *testing.T) {
	for _, word := range []string{"xyz", "abf", "cab", "abcabc", "aaa"} {
		t.Run(word, func(t *testing.T) {
			if _, err := Solve([]string{word}, []string{"abc", "def", "ghi"}); err == nil {
				t.Errorf("expected an error for missing word %q", word)
			}
		})
	}
	if _, err := Solve([]string{"a"}, nil); err == nil {
		t.Error("expected an error for a word in an empty puzzle")
	}
}

func TestRectangularPuzzleAndDuplicateRequests(t *testing.T) {
	got, err := Solve([]string{"ejo", "agm", "ejo"}, []string{"abcde", "fghij", "klmno"})
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 2 || got["ejo"] != ([2][2]int{{4, 0}, {4, 2}}) || got["agm"] != ([2][2]int{{0, 0}, {2, 2}}) {
		t.Fatalf("unexpected locations: %v", got)
	}
}

func TestNoRequestedWords(t *testing.T) {
	got, err := Solve(nil, nil)
	if err != nil || len(got) != 0 {
		t.Fatalf("got %v, %v; want no locations and no error", got, err)
	}
}

package wordsearch

import "fmt"

// Solve locates each word, returning its start and end as zero-based (column, row)
// coordinates. It returns an error if any requested word cannot be found.
func Solve(words []string, puzzle []string) (map[string][2][2]int, error) {
	grid := make([][]rune, len(puzzle))
	for row, line := range puzzle {
		grid[row] = []rune(line)
	}

	locations := make(map[string][2][2]int, len(words))
	for _, word := range words {
		location, found := findWord(grid, []rune(word))
		if !found {
			return nil, fmt.Errorf("word %q not found", word)
		}
		locations[word] = location
	}
	return locations, nil
}

func findWord(grid [][]rune, word []rune) ([2][2]int, bool) {
	if len(word) == 0 {
		return [2][2]int{}, false
	}
	for row, line := range grid {
		for col, letter := range line {
			if letter != word[0] {
				continue
			}
			for dy := -1; dy <= 1; dy++ {
				for dx := -1; dx <= 1; dx++ {
					if dx == 0 && dy == 0 {
						continue
					}
					matched := true
					for i, want := range word {
						x, y := col+i*dx, row+i*dy
						if y < 0 || y >= len(grid) || x < 0 || x >= len(grid[y]) || grid[y][x] != want {
							matched = false
							break
						}
					}
					if matched {
						return [2][2]int{{col, row}, {col + (len(word)-1)*dx, row + (len(word)-1)*dy}}, true
					}
				}
			}
		}
	}
	return [2][2]int{}, false
}

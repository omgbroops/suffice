class BaseConverter {

    private final int originalBase;
    private final int[] originalDigits;

    BaseConverter(int originalBase, int[] originalDigits) {
        if (originalBase < 2) {
            throw new IllegalArgumentException("Original base must be at least 2");
        }
        if (originalDigits == null || originalDigits.length == 0) {
            throw new IllegalArgumentException("Digits must not be empty");
        }
        for (int digit : originalDigits) {
            if (digit < 0 || digit >= originalBase) {
                throw new IllegalArgumentException("Digit is invalid for the original base");
            }
        }
        this.originalBase = originalBase;
        this.originalDigits = originalDigits.clone();
    }

    int[] convertToBase(int newBase) {
        if (newBase < 2) {
            throw new IllegalArgumentException("New base must be at least 2");
        }

        // Repeatedly divide the source-base digit sequence by the target base.
        // Keeping the intermediate number as digits avoids overflowing a primitive
        // integer (or relying on a library to perform the conversion).
        int first = 0;
        while (first < originalDigits.length - 1 && originalDigits[first] == 0) {
            first++;
        }
        int[] work = new int[originalDigits.length - first];
        System.arraycopy(originalDigits, first, work, 0, work.length);

        boolean zero = true;
        for (int digit : work) {
            if (digit != 0) {
                zero = false;
                break;
            }
        }
        if (zero) {
            return new int[] {0};
        }

        int[] reversed = new int[work.length * 32 + 1];
        int resultLength = 0;
        while (work.length > 0) {
            int remainder = 0;
            int[] quotient = new int[work.length];
            int quotientLength = 0;
            for (int digit : work) {
                long current = (long) remainder * originalBase + digit;
                int q = (int) (current / newBase);
                remainder = (int) (current % newBase);
                if (quotientLength > 0 || q != 0) {
                    quotient[quotientLength++] = q;
                }
            }
            reversed[resultLength++] = remainder;
            if (quotientLength == 0) {
                break;
            }
            work = new int[quotientLength];
            System.arraycopy(quotient, 0, work, 0, quotientLength);
        }

        int[] result = new int[resultLength];
        for (int i = 0; i < resultLength; i++) {
            result[i] = reversed[resultLength - 1 - i];
        }
        return result;
    }
}

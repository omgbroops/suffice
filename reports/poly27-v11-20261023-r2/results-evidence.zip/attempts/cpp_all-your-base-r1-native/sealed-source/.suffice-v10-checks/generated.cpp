#include "catch.hpp"
#include "all_your_base.h"

#include <limits>
#include <stdexcept>
#include <vector>

using all_your_base::convert;
using Digits = std::vector<unsigned int>;

TEST_CASE("Convert known values between bases") {
    REQUIRE(convert(2, {1}, 10) == Digits{1});
    REQUIRE(convert(2, {1, 0, 1, 0, 1, 0}, 10) == Digits{4, 2});
    REQUIRE(convert(10, {4, 2}, 2) == Digits{1, 0, 1, 0, 1, 0});
    REQUIRE(convert(3, {1, 1, 2, 0}, 10) == Digits{4, 2});
    REQUIRE(convert(2, {1, 0, 1, 0, 1, 0}, 3) == Digits{1, 1, 2, 0});
    REQUIRE(convert(16, {2, 10}, 10) == Digits{4, 2});
    REQUIRE(convert(97, {3, 46, 60}, 73) == Digits{6, 10, 45});
    REQUIRE(convert(10, {1, 2, 3, 4}, 10) == Digits{1, 2, 3, 4});
}

TEST_CASE("Normalize zero and leading zeroes") {
    REQUIRE(convert(2, {}, 10) == Digits{0});
    REQUIRE(convert(10, {0}, 2) == Digits{0});
    REQUIRE(convert(7, {0, 0, 0}, 16) == Digits{0});
    REQUIRE(convert(2, {0, 0, 1, 0, 1, 0, 1, 0}, 10) == Digits{4, 2});
    REQUIRE(convert(10, {0, 0, 4, 2}, 10) == Digits{4, 2});
}

TEST_CASE("Reject invalid bases and digits") {
    for (const auto base : {0u, 1u}) {
        REQUIRE_THROWS_AS(convert(base, {0}, 10), std::invalid_argument);
        REQUIRE_THROWS_AS(convert(10, {0}, base), std::invalid_argument);
        REQUIRE_THROWS_AS(convert(base, {}, 10), std::invalid_argument);
        REQUIRE_THROWS_AS(convert(10, {}, base), std::invalid_argument);
    }
    REQUIRE_THROWS_AS(convert(2, {1, 2, 0}, 10), std::invalid_argument);
    REQUIRE_THROWS_AS(convert(10, {10}, 2), std::invalid_argument);
    REQUIRE_THROWS_AS(convert(16, {1, std::numeric_limits<unsigned int>::max()}, 10),
                      std::invalid_argument);
}

TEST_CASE("Convert numbers beyond machine integer limits") {
    Digits binary(101, 0);
    binary.front() = 1;
    const Digits decimal{1, 2, 6, 7, 6, 5, 0, 6, 0, 0, 2, 2, 8, 2, 2, 9,
                         4, 0, 1, 4, 9, 6, 7, 0, 3, 2, 0, 5, 3, 7, 6};
    REQUIRE(convert(2, binary, 10) == decimal);
    REQUIRE(convert(10, decimal, 2) == binary);
}

TEST_CASE("Support the largest unsigned base") {
    const auto base = std::numeric_limits<unsigned int>::max();
    REQUIRE(convert(base, {base - 1, base - 1, base - 1}, base) ==
            Digits{base - 1, base - 1, base - 1});
    REQUIRE(convert(base, {1, 0}, 2) == Digits(32, 1));
    REQUIRE(convert(2, Digits(32, 1), base) == Digits{1, 0});
}

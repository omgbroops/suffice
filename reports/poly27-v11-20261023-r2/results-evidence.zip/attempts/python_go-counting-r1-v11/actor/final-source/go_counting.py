class Board:
    """Count territories of each player in a Go game.

    Coordinates are represented as ``(x, y)`` pairs, where ``x`` is the
    column and ``y`` is the row. The origin is the top-left intersection.
    """

    def __init__(self, board):
        # Keep a private copy so later caller changes do not affect results.
        self.board = [list(row) for row in board]
        self.height = len(self.board)
        self.width = len(self.board[0]) if self.height else 0
        if any(len(row) != self.width for row in self.board):
            raise ValueError("Board rows must all have the same length")

    def _neighbors(self, x, y):
        for nx, ny in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
            if 0 <= nx < self.width and 0 <= ny < self.height:
                yield nx, ny

    def _region(self, x, y):
        """Return an empty connected region and the colors bordering it."""
        pending = [(x, y)]
        region = set()
        borders = set()
        while pending:
            point = pending.pop()
            if point in region:
                continue
            region.add(point)
            px, py = point
            for nx, ny in self._neighbors(px, py):
                value = self.board[ny][nx]
                if value == " ":
                    if (nx, ny) not in region:
                        pending.append((nx, ny))
                elif value in ("B", "W"):
                    borders.add(value)
        owner = next(iter(borders)) if len(borders) == 1 else ""
        return owner, region

    def territory(self, x, y):
        """Find the owner and region containing a board coordinate."""
        if not isinstance(x, int) or not isinstance(y, int) or not (
            0 <= x < self.width and 0 <= y < self.height
        ):
            raise ValueError("Invalid coordinate")
        if self.board[y][x] != " ":
            return "", set()
        return self._region(x, y)

    def territories(self):
        """Return all empty intersections grouped by territory owner."""
        result = {"B": set(), "W": set(), "": set()}
        visited = set()
        for y in range(self.height):
            for x in range(self.width):
                if self.board[y][x] != " " or (x, y) in visited:
                    continue
                owner, region = self._region(x, y)
                result[owner].update(region)
                visited.update(region)
        return result

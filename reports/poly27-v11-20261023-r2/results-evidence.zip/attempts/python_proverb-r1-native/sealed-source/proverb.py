def proverb(*items, qualifier=None):
    """Return the proverb's verses, optionally qualifying the original item."""
    if not items:
        return []

    verses = [
        f"For want of a {cause} the {effect} was lost."
        for cause, effect in zip(items, items[1:])
    ]
    first_item = f"{qualifier} {items[0]}" if qualifier else items[0]
    verses.append(f"And all for the want of a {first_item}.")
    return verses

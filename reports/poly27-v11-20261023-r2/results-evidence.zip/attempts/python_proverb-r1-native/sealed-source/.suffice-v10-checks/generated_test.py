from proverb import proverb


def test_empty_input():
    assert proverb() == []
    assert proverb(qualifier="horseshoe") == []


def test_single_item():
    assert proverb("nail") == ["And all for the want of a nail."]
    assert proverb("seed", qualifier="tiny") == [
        "And all for the want of a tiny seed."
    ]


def test_two_items():
    assert proverb("nail", "shoe") == [
        "For want of a nail the shoe was lost.",
        "And all for the want of a nail.",
    ]


def test_full_proverb():
    assert proverb("nail", "shoe", "horse", "rider", "message", "battle", "kingdom") == [
        "For want of a nail the shoe was lost.",
        "For want of a shoe the horse was lost.",
        "For want of a horse the rider was lost.",
        "For want of a rider the message was lost.",
        "For want of a message the battle was lost.",
        "For want of a battle the kingdom was lost.",
        "And all for the want of a nail.",
    ]


def test_qualifier_changes_only_final_verse():
    assert proverb("nail", "shoe", "horse", qualifier="horseshoe") == [
        "For want of a nail the shoe was lost.",
        "For want of a shoe the horse was lost.",
        "And all for the want of a horseshoe nail.",
    ]


def test_arbitrary_content_and_repeated_items():
    assert proverb("red thread", "button", "red thread", qualifier="silky") == [
        "For want of a red thread the button was lost.",
        "For want of a button the red thread was lost.",
        "And all for the want of a silky red thread.",
    ]


def test_empty_qualifier():
    assert proverb("key", qualifier="") == ["And all for the want of a key."]

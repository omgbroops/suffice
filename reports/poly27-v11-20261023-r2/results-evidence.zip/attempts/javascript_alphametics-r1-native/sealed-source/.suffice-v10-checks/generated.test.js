import { solve } from '../alphametics.js';

const expectSolution = (puzzle) => {
  const solution = solve(puzzle);
  expect(solution).not.toBeNull();
  const words = puzzle.match(/[A-Za-z]+/g);
  const letters = [...new Set(words.join(''))];
  expect(Object.keys(solution).sort()).toEqual(letters.sort());
  const digits = Object.values(solution);
  expect(new Set(digits).size).toBe(letters.length);
  for (const digit of digits) {
    expect(Number.isInteger(digit)).toBe(true);
    expect(digit).toBeGreaterThanOrEqual(0);
    expect(digit).toBeLessThanOrEqual(9);
  }
  for (const word of words) {
    if (word.length > 1) expect(solution[word[0]]).not.toBe(0);
  }
  const values = words.map((word) =>
    BigInt([...word].map((letter) => solution[letter]).join('')),
  );
  const result = values.pop();
  expect(values.reduce((total, value) => total + value, 0n)).toBe(result);
  return solution;
};

test('solves SEND + MORE = MONEY with the expected assignment', () => {
  expect(expectSolution('SEND + MORE = MONEY')).toEqual({
    S: 9, E: 5, N: 6, D: 7, M: 1, O: 0, R: 8, Y: 2,
  });
});

test('supports repeated letters and the double-equals puzzle notation', () => {
  expect(expectSolution('I + BB == ILL')).toEqual({ I: 1, B: 9, L: 0 });
});

test('permits zero for a one-letter word', () => {
  expect(expectSolution('A + B = A').B).toBe(0);
});

test('handles carries with several addends and all ten digits', () => {
  expectSolution('DONALD + GERALD == ROBERT');
  expectSolution('SEND + MORE + MONEY = PAYDAY');
  expectSolution('THIS + IS + TOO = FUNNY');
});

test('handles carry values larger than one digit', () => {
  expectSolution(`${Array(20).fill('A').join(' + ')} = BCC`);
});

test('handles numbers longer than the safe integer range', () => {
  expectSolution('A + BBBBBBBBBBBBBBBBBBBB = ACCCCCCCCCCCCCCCCCCCC');
});

test('handles flexible whitespace and calls with independent assignments', () => {
  expectSolution('  A+B  =  C  ');
  expectSolution('TWO + TWO = FOUR');
  expectSolution('A = A');
});

test('returns null when distinct digits or leading-zero rules prevent a solution', () => {
  for (const puzzle of [
    'A + B = AA',
    'AA + BB = AA',
    'A + B = BA',
    'A = B',
    'AB = A',
    'A + B = CDE',
    'ABCDEFGHIJ + K = ABCDEFGHIJ',
  ]) {
    expect(solve(puzzle)).toBeNull();
  }
});

//
// This is only a SKELETON file for the 'Alphametics' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export const solve = (puzzle) => {
  const sides = puzzle.trim().split(/\s*={1,2}\s*/);
  if (sides.length !== 2) return null;

  const addends = sides[0].split('+').map((word) => word.trim());
  const result = sides[1];
  const words = [...addends, result];
  if (words.some((word) => !/^[A-Za-z]+$/.test(word))) return null;

  const letters = new Set(words.join(''));
  if (letters.size > 10) return null;

  const leading = new Set(
    words.filter((word) => word.length > 1).map((word) => word[0]),
  );
  const assignment = {};
  const used = new Set();
  const width = Math.max(...words.map((word) => word.length));
  // Count repeated addend letters so each needs only one choice per column.
  const columns = Array.from({ length: width }, (_, column) => {
    const counts = new Map();
    for (const word of addends) {
      const letter = word[word.length - 1 - column];
      if (letter !== undefined) {
        counts.set(letter, (counts.get(letter) || 0) + 1);
      }
    }
    return [...counts];
  });

  const canAssign = (letter, digit) =>
    !used.has(digit) && (digit !== 0 || !leading.has(letter));

  const search = (column, term, sum) => {
    if (column === width) return sum === 0;

    const terms = columns[column];
    if (term < terms.length) {
      const [letter, count] = terms[term];
      if (assignment[letter] !== undefined) {
        return search(column, term + 1, sum + count * assignment[letter]);
      }

      for (let digit = 0; digit <= 9; digit += 1) {
        if (!canAssign(letter, digit)) continue;
        assignment[letter] = digit;
        used.add(digit);
        if (search(column, term + 1, sum + count * digit)) return true;
        used.delete(digit);
        delete assignment[letter];
      }
      return false;
    }

    // The addend digits force both the result digit and the next carry.
    const digit = sum % 10;
    const carry = Math.floor(sum / 10);
    const letter = result[result.length - 1 - column];
    if (letter === undefined) {
      return digit === 0 && search(column + 1, 0, carry);
    }
    if (assignment[letter] !== undefined) {
      return assignment[letter] === digit && search(column + 1, 0, carry);
    }
    if (!canAssign(letter, digit)) return false;

    assignment[letter] = digit;
    used.add(digit);
    if (search(column + 1, 0, carry)) return true;
    used.delete(digit);
    delete assignment[letter];
    return false;
  };

  return search(0, 0, 0) ? assignment : null;
};

/**
 * Solve an alphametics addition puzzle.
 *
 * @param {string} puzzle
 * @returns {Record<string, number> | null}
 */
export const solve = (puzzle) => {
  if (typeof puzzle !== 'string') return null;

  const compact = puzzle.replace(/\s+/g, '');
  const match = /^([A-Z]+(?:\+[A-Z]+)*)=([A-Z]+)$/.exec(compact);
  if (!match) return null;

  const addends = match[1].split('+');
  const result = match[2];
  const letters = new Set(compact.match(/[A-Z]/g));
  if (letters.size > 10) return null;

  const leading = new Set();
  for (const word of [...addends, result]) {
    if (word.length > 1) leading.add(word[0]);
  }

  const assignment = Object.create(null);
  const used = new Set();
  const width = Math.max(result.length, ...addends.map((word) => word.length));

  const searchColumn = (column, carry) => {
    if (column === width) return carry === 0;

    const columnLetters = [];
    for (const word of addends) {
      const index = word.length - 1 - column;
      if (index >= 0) columnLetters.push(word[index]);
    }

    const assignAddends = (index, sum) => {
      if (index < columnLetters.length) {
        const letter = columnLetters[index];
        if (Object.hasOwn(assignment, letter)) {
          return assignAddends(index + 1, sum + assignment[letter]);
        }

        for (let digit = 0; digit <= 9; digit += 1) {
          if (used.has(digit) || (digit === 0 && leading.has(letter))) continue;
          assignment[letter] = digit;
          used.add(digit);
          if (assignAddends(index + 1, sum + digit)) return true;
          delete assignment[letter];
          used.delete(digit);
        }
        return false;
      }

      const total = sum + carry;
      const digit = total % 10;
      const nextCarry = Math.floor(total / 10);
      const resultIndex = result.length - 1 - column;

      if (resultIndex < 0) {
        return digit === 0 && searchColumn(column + 1, nextCarry);
      }

      const letter = result[resultIndex];
      if (Object.hasOwn(assignment, letter)) {
        return assignment[letter] === digit && searchColumn(column + 1, nextCarry);
      }
      if (used.has(digit) || (digit === 0 && leading.has(letter))) return false;

      assignment[letter] = digit;
      used.add(digit);
      if (searchColumn(column + 1, nextCarry)) return true;
      delete assignment[letter];
      used.delete(digit);
      return false;
    };

    return assignAddends(0, 0);
  };

  if (!searchColumn(0, 0)) return null;
  return { ...assignment };
};

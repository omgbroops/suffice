import java.util.regex.Matcher;
import java.util.regex.Pattern;

class PigLatinTranslator {
    private static final Pattern WORD = Pattern.compile("\\S+");

    public String translate(String word) {
        return WORD.matcher(word).replaceAll(
                match -> Matcher.quoteReplacement(translateWord(match.group())));
    }

    private String translateWord(String word) {
        if (word.startsWith("xr") || word.startsWith("yt")) {
            return word + "ay";
        }

        int prefixLength = 0;
        while (prefixLength < word.length()) {
            char letter = word.charAt(prefixLength);
            if ("aeiou".indexOf(letter) >= 0 || (letter == 'y' && prefixLength > 0)) {
                break;
            }
            if (word.startsWith("qu", prefixLength)) {
                prefixLength += 2;
            } else {
                prefixLength++;
            }
        }

        return word.substring(prefixLength) + word.substring(0, prefixLength) + "ay";
    }
}

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class GeneratedCheck {
    private final PigLatinTranslator translator = new PigLatinTranslator();

    @Test
    void wordsStartingWithVowels() {
        assertTranslation("apple", "appleay");
        assertTranslation("ear", "earay");
        assertTranslation("igloo", "iglooay");
        assertTranslation("object", "objectay");
        assertTranslation("under", "underay");
        assertTranslation("equal", "equalay");
    }

    @Test
    void specialVowelPrefixes() {
        assertTranslation("xray", "xrayay");
        assertTranslation("yttria", "yttriaay");
        assertTranslation("xenon", "enonxay");
        assertTranslation("yellow", "ellowyay");
    }

    @Test
    void consonantsAndClusters() {
        assertTranslation("pig", "igpay");
        assertTranslation("koala", "oalakay");
        assertTranslation("chair", "airchay");
        assertTranslation("thrush", "ushthray");
        assertTranslation("school", "oolschay");
        assertTranslation("therapy", "erapythay");
    }

    @Test
    void quMovesWithTheConsonantPrefix() {
        assertTranslation("quick", "ickquay");
        assertTranslation("queen", "eenquay");
        assertTranslation("square", "aresquay");
        assertTranslation("squeal", "ealsquay");
        assertTranslation("liquid", "iquidlay");
    }

    @Test
    void yActsAsAVowelAfterConsonants() {
        assertTranslation("my", "ymay");
        assertTranslation("rhythm", "ythmrhay");
        assertTranslation("fly", "yflay");
        assertTranslation("typhoon", "yphoontay");
    }

    @Test
    void translatesEachWordInPhrases() {
        assertTranslation("quick fast run", "ickquay astfay unray");
        assertTranslation("my square apple", "ymay aresquay appleay");
        assertTranslation("the quick brown fox", "ethay ickquay ownbray oxfay");
    }

    private void assertTranslation(String english, String pigLatin) {
        assertEquals(pigLatin, translator.translate(english), english);
    }
}

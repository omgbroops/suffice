def transpose(text):
    """Return the rows and columns of *text* transposed."""
    rows = text.splitlines()
    if not rows:
        return ""

    width = max(map(len, rows), default=0)
    transposed = []
    for column in range(width):
        present = [index for index, row in enumerate(rows) if column < len(row)]
        if not present:
            continue
        last = present[-1]
        transposed.append(
            "".join(row[column] if column < len(row) else " " for row in rows[:last + 1])
        )
    return "\n".join(transposed)

package say

import "strings"

// Say spells n in English, returning false if n is outside the supported range.
func Say(n int64) (string, bool) {
	if n < 0 || n > 999_999_999_999 {
		return "", false
	}
	if n == 0 {
		return "zero", true
	}

	var parts []string
	for _, scale := range []struct {
		value int64
		name  string
	}{
		{1_000_000_000, "billion"},
		{1_000_000, "million"},
		{1_000, "thousand"},
		{1, ""},
	} {
		chunk := n / scale.value
		n %= scale.value
		if chunk == 0 {
			continue
		}
		part := sayChunk(int(chunk))
		if scale.name != "" {
			part += " " + scale.name
		}
		parts = append(parts, part)
	}
	return strings.Join(parts, " "), true
}

// sayChunk spells a number from 1 through 999.
func sayChunk(n int) string {
	small := [...]string{
		"", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
		"ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen",
		"seventeen", "eighteen", "nineteen",
	}
	tens := [...]string{"", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"}

	var result string
	if n >= 100 {
		result = small[n/100] + " hundred"
		n %= 100
		if n == 0 {
			return result
		}
		result += " "
	}
	if n < 20 {
		return result + small[n]
	}
	result += tens[n/10]
	if n%10 != 0 {
		result += "-" + small[n%10]
	}
	return result
}

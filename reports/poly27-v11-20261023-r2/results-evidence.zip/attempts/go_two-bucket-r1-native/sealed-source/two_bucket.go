package twobucket

import "errors"

// Solve finds the fewest legal actions needed to measure goalAmount.
func Solve(sizeBucketOne, sizeBucketTwo, goalAmount int, startBucket string) (string, int, int, error) {
	if sizeBucketOne <= 0 || sizeBucketTwo <= 0 || sizeBucketOne == sizeBucketTwo {
		return "", 0, 0, errors.New("bucket sizes must be positive and different")
	}
	if goalAmount <= 0 || (goalAmount > sizeBucketOne && goalAmount > sizeBucketTwo) {
		return "", 0, 0, errors.New("goal must be positive and fit in a bucket")
	}
	if startBucket != "one" && startBucket != "two" {
		return "", 0, 0, errors.New("starting bucket must be one or two")
	}

	// Every reachable amount is a multiple of the capacities' greatest
	// common divisor, including when the capacities are not relatively prime.
	a, b := sizeBucketOne, sizeBucketTwo
	for b != 0 {
		a, b = b, a%b
	}
	if goalAmount%a != 0 {
		return "", 0, 0, errors.New("goal cannot be reached with these bucket sizes")
	}

	type levels struct{ one, two int }
	type state struct {
		levels
		steps int
	}
	initial := levels{one: sizeBucketOne}
	forbidden := levels{two: sizeBucketTwo}
	if startBucket == "two" {
		initial, forbidden = forbidden, initial
	}
	queue := []state{{initial, 1}}
	visited := map[levels]bool{initial: true}
	for head := 0; head < len(queue); head++ {
		current := queue[head]
		if current.one == goalAmount {
			return "one", current.steps, current.two, nil
		}
		if current.two == goalAmount {
			return "two", current.steps, current.one, nil
		}

		pourToTwo := current.one
		if space := sizeBucketTwo - current.two; pourToTwo > space {
			pourToTwo = space
		}
		pourToOne := current.two
		if space := sizeBucketOne - current.one; pourToOne > space {
			pourToOne = space
		}
		next := [...]levels{
			{current.one - pourToTwo, current.two + pourToTwo},
			{current.one + pourToOne, current.two - pourToOne},
			{0, current.two},
			{current.one, 0},
			{sizeBucketOne, current.two},
			{current.one, sizeBucketTwo},
		}
		for _, candidate := range next {
			if candidate == forbidden || visited[candidate] {
				continue
			}
			visited[candidate] = true
			queue = append(queue, state{candidate, current.steps + 1})
		}
	}
	return "", 0, 0, errors.New("no legal solution exists")
}

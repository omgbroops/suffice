package twobucket

import "testing"

func TestSolvePublicExamples(t *testing.T) {
	cases := []struct {
		name              string
		one, two, goal    int
		start, wantBucket string
		wantSteps, other  int
	}{
		{"small first", 3, 5, 1, "one", "one", 4, 5},
		{"large first", 3, 5, 1, "two", "two", 8, 3},
		{"seven first", 7, 11, 2, "one", "one", 14, 11},
		{"eleven first", 7, 11, 2, "two", "two", 18, 7},
		{"first fill reaches goal", 3, 5, 3, "one", "one", 1, 0},
		{"second bucket first fill", 3, 5, 5, "two", "two", 1, 0},
		{"fill other directly", 1, 3, 3, "one", "two", 2, 1},
		{"fill other directly reversed", 3, 1, 3, "two", "one", 2, 1},
		{"other capacity", 2, 3, 3, "one", "two", 2, 2},
		{"forbidden state prevents shortcut", 3, 5, 4, "one", "two", 8, 0},
		{"reverse direction", 3, 5, 4, "two", "two", 6, 3},
		{"common divisor reachable", 6, 15, 9, "one", "two", 10, 0},
		{"common divisor capacity", 6, 15, 15, "one", "two", 2, 6},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			bucket, steps, other, err := Solve(tc.one, tc.two, tc.goal, tc.start)
			if err != nil {
				t.Fatalf("Solve returned unexpected error: %v", err)
			}
			if bucket != tc.wantBucket || steps != tc.wantSteps || other != tc.other {
				t.Errorf("Solve = (%q, %d, %d); want (%q, %d, %d)", bucket, steps, other, tc.wantBucket, tc.wantSteps, tc.other)
			}
		})
	}
}

func TestSolveRejectsInvalidOrUnreachableInputs(t *testing.T) {
	cases := []struct {
		name           string
		one, two, goal int
		start          string
	}{
		{"zero first capacity", 0, 5, 1, "one"},
		{"zero second capacity", 3, 0, 1, "two"},
		{"negative first capacity", -3, 5, 1, "one"},
		{"negative second capacity", 3, -5, 1, "one"},
		{"equal capacities", 3, 3, 1, "one"},
		{"zero goal", 3, 5, 0, "one"},
		{"negative goal", 3, 5, -1, "one"},
		{"goal exceeds capacities", 3, 5, 6, "one"},
		{"missing start", 3, 5, 1, ""},
		{"unknown start", 3, 5, 1, "three"},
		{"case sensitive start", 3, 5, 1, "One"},
		{"unreachable common divisor", 6, 15, 5, "one"},
		{"unreachable reversed start", 6, 15, 5, "two"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if _, _, _, err := Solve(tc.one, tc.two, tc.goal, tc.start); err == nil {
				t.Error("Solve returned no error for invalid or unreachable input")
			}
		})
	}
}

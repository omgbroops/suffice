import { House } from '../house.js';

const rhyme = `This is the house that Jack built.

This is the malt
that lay in the house that Jack built.

This is the rat
that ate the malt
that lay in the house that Jack built.

This is the cat
that killed the rat
that ate the malt
that lay in the house that Jack built.

This is the dog
that worried the cat
that killed the rat
that ate the malt
that lay in the house that Jack built.

This is the cow with the crumpled horn
that tossed the dog
that worried the cat
that killed the rat
that ate the malt
that lay in the house that Jack built.

This is the maiden all forlorn
that milked the cow with the crumpled horn
that tossed the dog
that worried the cat
that killed the rat
that ate the malt
that lay in the house that Jack built.

This is the man all tattered and torn
that kissed the maiden all forlorn
that milked the cow with the crumpled horn
that tossed the dog
that worried the cat
that killed the rat
that ate the malt
that lay in the house that Jack built.

This is the priest all shaven and shorn
that married the man all tattered and torn
that kissed the maiden all forlorn
that milked the cow with the crumpled horn
that tossed the dog
that worried the cat
that killed the rat
that ate the malt
that lay in the house that Jack built.

This is the rooster that crowed in the morn
that woke the priest all shaven and shorn
that married the man all tattered and torn
that kissed the maiden all forlorn
that milked the cow with the crumpled horn
that tossed the dog
that worried the cat
that killed the rat
that ate the malt
that lay in the house that Jack built.

This is the farmer sowing his corn
that kept the rooster that crowed in the morn
that woke the priest all shaven and shorn
that married the man all tattered and torn
that kissed the maiden all forlorn
that milked the cow with the crumpled horn
that tossed the dog
that worried the cat
that killed the rat
that ate the malt
that lay in the house that Jack built.

This is the horse and the hound and the horn
that belonged to the farmer sowing his corn
that kept the rooster that crowed in the morn
that woke the priest all shaven and shorn
that married the man all tattered and torn
that kissed the maiden all forlorn
that milked the cow with the crumpled horn
that tossed the dog
that worried the cat
that killed the rat
that ate the malt
that lay in the house that Jack built.`;

const expectedVerses = rhyme.split('\n\n');

expectedVerses.forEach((verse, index) => {
  test(`verse ${index + 1} matches the supplied rhyme`, () => {
    expect(House.verse(index + 1)).toEqual(verse.split('\n'));
  });
});

test('every inclusive range has exactly one empty line between verses', () => {
  for (let start = 1; start <= 12; start += 1) {
    for (let end = start; end <= 12; end += 1) {
      expect(House.verses(start, end)).toEqual(
        expectedVerses.slice(start - 1, end).join('\n\n').split('\n'),
      );
    }
  }
});

test('returns the entire rhyme', () => {
  expect(House.verses(1, 12)).toEqual(rhyme.split('\n'));
});

test('returned arrays can be changed without affecting future calls', () => {
  const verse = House.verse(1);
  const verses = House.verses(1, 2);
  verse[0] = 'changed';
  verses.push('changed');
  expect(House.verse(1)).toEqual(expectedVerses[0].split('\n'));
  expect(House.verses(1, 2)).toEqual(
    expectedVerses.slice(0, 2).join('\n\n').split('\n'),
  );
});

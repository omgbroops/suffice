from collections import deque


class ConnectGame:
    def __init__(self, board):
        # The input is conventionally a sequence of rows, with individual
        # cells separated by spaces.  Splitting each row also discards the
        # visual indentation used to draw the parallelogram.
        self.board = [row.split() for row in board]

    def get_winner(self):
        if not self.board or not any(self.board):
            return ""

        rows = len(self.board)

        def connected(player, starts, is_goal):
            queue = deque()
            visited = set()
            for position in starts:
                if position not in visited:
                    visited.add(position)
                    queue.append(position)

            while queue:
                row, col = queue.popleft()
                if is_goal(row, col):
                    return True

                # Hex cells have horizontal, vertical, and two diagonal
                # neighbours.  In these logical row/column coordinates the
                # diagonal pair is upper-right/lower-left.
                for next_row, next_col in (
                    (row, col - 1),
                    (row, col + 1),
                    (row - 1, col),
                    (row + 1, col),
                    (row - 1, col + 1),
                    (row + 1, col - 1),
                ):
                    if (
                        0 <= next_row < rows
                        and 0 <= next_col < len(self.board[next_row])
                        and self.board[next_row][next_col] == player
                        and (next_row, next_col) not in visited
                    ):
                        visited.add((next_row, next_col))
                        queue.append((next_row, next_col))
            return False

        # O connects the first and last rows; X connects the first and last
        # columns.  A row may have a different width from another row.
        if connected(
            "O",
            ((0, col) for col, cell in enumerate(self.board[0]) if cell == "O"),
            lambda row, col: row == rows - 1,
        ):
            return "O"

        # Test X connections left-to-right and right-to-left explicitly.
        for starts_left, goal_right in ((True, True), (False, False)):
            starts = (
                (row, 0 if starts_left else len(cells) - 1)
                for row, cells in enumerate(self.board)
                if cells
                and cells[0 if starts_left else -1] == "X"
            )
            if connected(
                "X",
                starts,
                lambda row, col, right=goal_right: col
                == (len(self.board[row]) - 1 if right else 0),
            ):
                return "X"

        return ""

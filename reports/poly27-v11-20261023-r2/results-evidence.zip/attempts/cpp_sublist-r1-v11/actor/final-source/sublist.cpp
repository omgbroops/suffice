#include "sublist.h"

#include <algorithm>

namespace sublist {

List_comparison sublist(const std::vector<int>& first,
                        const std::vector<int>& second) {
    if (first == second) {
        return List_comparison::equal;
    }

    if (first.size() < second.size() &&
        std::search(second.begin(), second.end(), first.begin(), first.end()) !=
            second.end()) {
        return List_comparison::sublist;
    }

    if (first.size() > second.size() &&
        std::search(first.begin(), first.end(), second.begin(), second.end()) !=
            first.end()) {
        return List_comparison::superlist;
    }

    return List_comparison::unequal;
}

}  // namespace sublist

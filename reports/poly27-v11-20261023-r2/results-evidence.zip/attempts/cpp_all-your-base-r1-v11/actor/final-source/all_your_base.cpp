#include "all_your_base.h"

#include <algorithm>
#include <cstdint>
#include <stdexcept>
#include <vector>

namespace all_your_base {

std::vector<unsigned int> convert(unsigned int input_base,
                                  const std::vector<unsigned int>& input_digits,
                                  unsigned int output_base) {
    if (input_base < 2 || output_base < 2) {
        throw std::invalid_argument("bases must be at least 2");
    }
    for (const unsigned int digit : input_digits) {
        if (digit >= input_base) {
            throw std::invalid_argument("input digit is not valid for its base");
        }
    }
    if (input_digits.empty()) {
        return {};
    }

    // Repeatedly divide the input-base number by output_base. Keeping the
    // working value as digits avoids imposing a machine-integer size limit.
    std::vector<unsigned int> remaining(input_digits);
    std::vector<unsigned int> result;
    while (!remaining.empty()) {
        std::uint64_t remainder = 0;
        std::vector<unsigned int> quotient;
        quotient.reserve(remaining.size());

        for (const unsigned int digit : remaining) {
            const std::uint64_t value = remainder * input_base + digit;
            const unsigned int quotient_digit =
                static_cast<unsigned int>(value / output_base);
            remainder = value % output_base;
            if (!quotient.empty() || quotient_digit != 0) {
                quotient.push_back(quotient_digit);
            }
        }

        result.push_back(static_cast<unsigned int>(remainder));
        remaining.swap(quotient);
    }

    std::reverse(result.begin(), result.end());
    return result;
}

}  // namespace all_your_base

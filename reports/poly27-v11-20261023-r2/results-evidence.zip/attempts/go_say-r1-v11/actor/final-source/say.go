package say

import "strings"

const maxNumber int64 = 999999999999

var ones = [...]string{
	"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
	"ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen",
	"seventeen", "eighteen", "nineteen",
}

var tens = [...]string{
	"", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety",
}

// Say spells out n in English. The boolean is false when n is outside the
// supported range [0, 999,999,999,999].
func Say(n int64) (string, bool) {
	if n < 0 || n > maxNumber {
		return "", false
	}
	if n == 0 {
		return "zero", true
	}

	chunks := [...]int64{n / 1_000_000_000, n / 1_000_000 % 1000, n / 1000 % 1000, n % 1000}
	scales := [...]string{"billion", "million", "thousand", ""}
	parts := make([]string, 0, 7)
	for i, chunk := range chunks {
		if chunk == 0 {
			continue
		}
		words := spellUnderThousand(chunk)
		if scales[i] != "" {
			words += " " + scales[i]
		}
		parts = append(parts, words)
	}
	return strings.Join(parts, " "), true
}

func spellUnderThousand(n int64) string {
	parts := make([]string, 0, 3)
	if n >= 100 {
		parts = append(parts, ones[n/100]+" hundred")
		n %= 100
	}
	switch {
	case n >= 20:
		word := tens[n/10]
		if n%10 != 0 {
			word += "-" + ones[n%10]
		}
		parts = append(parts, word)
	case n > 0:
		parts = append(parts, ones[n])
	}
	return strings.Join(parts, " ")
}

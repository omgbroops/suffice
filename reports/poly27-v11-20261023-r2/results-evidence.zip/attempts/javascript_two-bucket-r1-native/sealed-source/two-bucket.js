//
// This is only a SKELETON file for the 'Two Bucket' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class TwoBucket {
  constructor(size1, size2, goal, start) {
    this.sizes = [size1, size2];
    this.goal = goal;
    this.start = start === 'one' ? 0 : 1;
  }

  solve() {
    const [size1, size2] = this.sizes;
    const initial = this.start === 0 ? [size1, 0] : [0, size2];
    const queue = [[...initial, 1]];
    const visited = new Set([initial.join(',')]);

    for (let index = 0; index < queue.length; index += 1) {
      const [one, two, moves] = queue[index];

      if (one === this.goal || two === this.goal) {
        return {
          moves,
          goalBucket: one === this.goal ? 'one' : 'two',
          otherBucket: one === this.goal ? two : one,
        };
      }

      const pourToTwo = Math.min(one, size2 - two);
      const pourToOne = Math.min(two, size1 - one);
      const nextStates = [
        [size1, two],
        [one, size2],
        [0, two],
        [one, 0],
        [one - pourToTwo, two + pourToTwo],
        [one + pourToOne, two - pourToOne],
      ];

      for (const state of nextStates) {
        // The starting bucket may never be empty while the other is full.
        if (
          state[this.start] === 0 &&
          state[1 - this.start] === this.sizes[1 - this.start]
        ) {
          continue;
        }

        const key = state.join(',');
        if (!visited.has(key)) {
          visited.add(key);
          queue.push([...state, moves + 1]);
        }
      }
    }

    throw new Error('The goal cannot be reached with these bucket sizes');
  }
}

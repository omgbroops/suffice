import { TwoBucket } from '../two-bucket.js';

test('starts with bucket one and measures one liter', () => {
  expect(new TwoBucket(3, 5, 1, 'one').solve()).toEqual({
    moves: 4,
    goalBucket: 'one',
    otherBucket: 5,
  });
});

test('starting with bucket two changes the required moves and result', () => {
  expect(new TwoBucket(3, 5, 1, 'two').solve()).toEqual({
    moves: 8,
    goalBucket: 'two',
    otherBucket: 3,
  });
});

test('measures two liters with seven and eleven liter buckets', () => {
  expect(new TwoBucket(7, 11, 2, 'one').solve()).toEqual({
    moves: 14,
    goalBucket: 'one',
    otherBucket: 11,
  });
  expect(new TwoBucket(7, 11, 2, 'two').solve()).toEqual({
    moves: 18,
    goalBucket: 'two',
    otherBucket: 7,
  });
});

test('counts the initial fill when it immediately reaches the goal', () => {
  expect(new TwoBucket(3, 5, 3, 'one').solve()).toEqual({
    moves: 1,
    goalBucket: 'one',
    otherBucket: 0,
  });
  expect(new TwoBucket(3, 5, 5, 'two').solve()).toEqual({
    moves: 1,
    goalBucket: 'two',
    otherBucket: 0,
  });
});

test('can fill the other bucket immediately after the required first fill', () => {
  expect(new TwoBucket(3, 5, 5, 'one').solve()).toEqual({
    moves: 2,
    goalBucket: 'two',
    otherBucket: 3,
  });
  expect(new TwoBucket(3, 5, 3, 'two').solve()).toEqual({
    moves: 2,
    goalBucket: 'one',
    otherBucket: 5,
  });
});

test('never takes the shortcut through an empty starting bucket and full other bucket', () => {
  expect(new TwoBucket(2, 3, 1, 'one').solve()).toEqual({
    moves: 4,
    goalBucket: 'one',
    otherBucket: 3,
  });
});

test('handles a reachable goal with bucket sizes sharing a common divisor', () => {
  expect(new TwoBucket(6, 10, 2, 'one').solve()).toEqual({
    moves: 4,
    goalBucket: 'one',
    otherBucket: 10,
  });
});

test('rejects an impossible goal instead of looping forever', () => {
  expect(() => new TwoBucket(6, 10, 5, 'one').solve()).toThrow();
  expect(() => new TwoBucket(3, 5, 6, 'two').solve()).toThrow();
});

test('solving the same instance repeatedly gives the same result', () => {
  const buckets = new TwoBucket(3, 5, 1, 'two');
  const expected = { moves: 8, goalBucket: 'two', otherBucket: 3 };
  expect(buckets.solve()).toEqual(expected);
  expect(buckets.solve()).toEqual(expected);
});

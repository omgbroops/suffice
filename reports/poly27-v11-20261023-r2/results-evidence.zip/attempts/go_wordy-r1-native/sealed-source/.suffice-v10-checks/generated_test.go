package wordy

import "testing"

func TestValidWordProblems(t *testing.T) {
	cases := []struct {
		question string
		want     int
	}{
		{"What is 5?", 5},
		{"What is 0?", 0},
		{"What is -123?", -123},
		{"What is 5 plus 13?", 18},
		{"What is 123456789 plus 987654321?", 1111111110},
		{"What is -1 plus -10?", -11},
		{"What is 7 minus 5?", 2},
		{"What is 4 minus -12?", 16},
		{"What is 6 multiplied by 4?", 24},
		{"What is -3 multiplied by 6?", -18},
		{"What is 25 divided by 5?", 5},
		{"What is -12 divided by -3?", 4},
		{"What is 5 plus 13 plus 6?", 24},
		{"What is 3 plus 2 multiplied by 3?", 15},
		{"What is 20 minus 4 divided by 2?", 8},
		{"What is 20 divided by 2 divided by 2?", 5},
		{"What is 5 minus 3 minus 1?", 1},
		{"What is 2 multiplied by -2 multiplied by 3?", -12},
		{"What is 10 plus 6 divided by 4 minus 2 multiplied by 3?", 6},
	}
	for _, tc := range cases {
		t.Run(tc.question, func(t *testing.T) {
			got, ok := Answer(tc.question)
			if !ok || got != tc.want {
				t.Errorf("Answer(%q) = (%d, %t), want (%d, true)", tc.question, got, ok, tc.want)
			}
		})
	}
}

func TestInvalidWordProblems(t *testing.T) {
	questions := []string{
		"", "What is?", "What is ?", "What is 1", "What is 1??",
		"Who is the President of the United States", "How much is 5?",
		"What is 52 cubed?", "What is 2 raised to the 5th power?",
		"What is 1 plus plus 2?", "What is plus 1?", "What is 1 plus?",
		"What is 1 2?", "What is 1 plus 2 3?", "What is 1 plus minus 2?",
		"What is 2 multiplied 3?", "What is 2 multiplied by?",
		"What is 2 divided 3?", "What is 2 divided by by 3?",
		"What is 2 plus by 3?", "What is two plus 3?",
		"What is 1.5 plus 2?", "What is 1 divided by 0?",
		"What is 999999999999999999999999999999999999?",
	}
	for _, question := range questions {
		t.Run(question, func(t *testing.T) {
			if answer, ok := Answer(question); ok {
				t.Errorf("Answer(%q) = (%d, true), want invalid question", question, answer)
			}
		})
	}
}

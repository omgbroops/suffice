package wordy

import (
	"strconv"
	"strings"
)

// Answer evaluates a word problem from left to right. The boolean reports
// whether the question is a valid, supported math problem.
func Answer(question string) (int, bool) {
	if !strings.HasPrefix(question, "What is ") || !strings.HasSuffix(question, "?") {
		return 0, false
	}
	words := strings.Fields(question[len("What is ") : len(question)-1])
	if len(words) == 0 {
		return 0, false
	}
	answer, err := strconv.Atoi(words[0])
	if err != nil {
		return 0, false
	}
	for i := 1; i < len(words); {
		op := words[i]
		i++
		switch op {
		case "plus", "minus":
		case "multiplied", "divided":
			if i >= len(words) || words[i] != "by" {
				return 0, false
			}
			i++
		default:
			return 0, false
		}
		if i >= len(words) {
			return 0, false
		}
		operand, err := strconv.Atoi(words[i])
		if err != nil {
			return 0, false
		}
		i++
		switch op {
		case "plus":
			answer += operand
		case "minus":
			answer -= operand
		case "multiplied":
			answer *= operand
		case "divided":
			if operand == 0 {
				return 0, false
			}
			answer /= operand
		}
	}
	return answer, true
}

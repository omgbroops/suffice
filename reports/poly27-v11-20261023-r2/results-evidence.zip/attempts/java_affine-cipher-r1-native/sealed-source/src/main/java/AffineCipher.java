public class AffineCipher {
    private static final int ALPHABET_SIZE = 26;

    public String encode(String text, int coefficient1, int coefficient2) {
        int multiplier = Math.floorMod(coefficient1, ALPHABET_SIZE);
        modularInverse(multiplier);
        return transform(text, multiplier, Math.floorMod(coefficient2, ALPHABET_SIZE), true);
    }

    public String decode(String text, int coefficient1, int coefficient2) {
        int inverse = modularInverse(Math.floorMod(coefficient1, ALPHABET_SIZE));
        int offset = -inverse * Math.floorMod(coefficient2, ALPHABET_SIZE);
        return transform(text, inverse, offset, false);
    }

    private int modularInverse(int multiplier) {
        for (int candidate = 1; candidate < ALPHABET_SIZE; candidate++) {
            if (multiplier * candidate % ALPHABET_SIZE == 1) {
                return candidate;
            }
        }
        throw new IllegalArgumentException("Error: keyA and alphabet size must be coprime.");
    }

    private String transform(String text, int multiplier, int offset, boolean grouped) {
        StringBuilder result = new StringBuilder();
        int characterCount = 0;
        for (int index = 0; index < text.length(); index++) {
            char character = text.charAt(index);
            if (character >= 'A' && character <= 'Z') {
                character = (char) (character - 'A' + 'a');
            }
            if (character >= 'a' && character <= 'z') {
                character = (char) ('a' + Math.floorMod(
                        multiplier * (character - 'a') + offset, ALPHABET_SIZE));
            } else if (character < '0' || character > '9') {
                continue;
            }
            if (grouped && characterCount > 0 && characterCount % 5 == 0) {
                result.append(' ');
            }
            result.append(character);
            characterCount++;
        }
        return result.toString();
    }
}

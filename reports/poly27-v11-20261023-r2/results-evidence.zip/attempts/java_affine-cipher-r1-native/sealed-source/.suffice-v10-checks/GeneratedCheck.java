import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class GeneratedCheck {
    private final AffineCipher cipher = new AffineCipher();

    @Test
    void encryptsAndDecryptsInstructionExamples() {
        assertEquals("ybty", cipher.encode("test", 5, 7));
        assertEquals("test", cipher.decode("ybty", 5, 7));
        assertEquals("lqul", cipher.decode("ybty", 11, 7));
        assertEquals("thequickbrownfoxjumpsoverthelazydog",
                cipher.decode("kqlfd jzvgy tpaet icdhm rtwly kqlon ubstx", 19, 13));
        assertEquals("kqlfd jzvgy tpaet icdhm rtwly kqlon ubstx",
                cipher.encode("The quick brown fox jumps over the lazy dog.", 19, 13));
    }

    @Test
    void findsTheModularInverse() {
        assertEquals("sfsen sq", cipher.encode("anagram", 15, 18));
        assertEquals("anagram", cipher.decode("sfsen sq", 15, 18));
    }

    @Test
    void preservesDigitsAndExcludesPunctuation() {
        assertEquals("ybty1 23456 7890", cipher.encode("TEST, 1234! 567890?", 5, 7));
        assertEquals("test1234567890", cipher.decode("YBTY1, 23456! 7890?", 5, 7));
    }

    @Test
    void groupsExactlyFiveCharactersWithoutTrailingSpaces() {
        assertEquals("abcde", cipher.encode("abcde", 1, 0));
        assertEquals("abcde f", cipher.encode("abcdef", 1, 0));
        assertEquals("abcde fghij", cipher.encode("abcdefghij", 1, 0));
        assertEquals("01234 56789 0", cipher.encode("01234567890", 1, 0));
    }

    @Test
    void handlesEmptyOrDiscardedInput() {
        assertEquals("", cipher.encode("", 5, 7));
        assertEquals("", cipher.decode("", 5, 7));
        assertEquals("", cipher.encode(" !?", 5, 7));
        assertEquals("", cipher.decode(" !?", 5, 7));
    }

    @Test
    void rejectsNonCoprimeKeysForBothOperationsEvenOnEmptyInput() {
        for (int key : new int[] {0, 2, 13, 18, 26, -13, Integer.MIN_VALUE}) {
            assertThrows(IllegalArgumentException.class, () -> cipher.encode("test", key, 7));
            assertThrows(IllegalArgumentException.class, () -> cipher.decode("ybty", key, 7));
            assertThrows(IllegalArgumentException.class, () -> cipher.encode("", key, 7));
            assertThrows(IllegalArgumentException.class, () -> cipher.decode("", key, 7));
        }
    }

    @Test
    void usesMathematicalModuloForNegativeAndLargeKeys() {
        assertEquals("czhc", cipher.encode("test", -5, -7));
        assertEquals("test", cipher.decode("czhc", -5, -7));
        assertEquals("cf09", cipher.encode("az09", Integer.MAX_VALUE, Integer.MIN_VALUE));
        assertEquals("az09", cipher.decode("cf09", Integer.MAX_VALUE, Integer.MIN_VALUE));
    }
}

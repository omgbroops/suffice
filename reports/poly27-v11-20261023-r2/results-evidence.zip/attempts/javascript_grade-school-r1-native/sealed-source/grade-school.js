//
// This is only a SKELETON file for the 'Grade School' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class GradeSchool {
  constructor() {
    this.students = new Map();
  }

  roster() {
    const grades = [...new Set(this.students.values())].sort((a, b) => a - b);
    return Object.fromEntries(grades.map((grade) => [grade, this.grade(grade)]));
  }

  add(student, grade) {
    this.students.set(student, grade);
  }

  grade(grade) {
    return [...this.students]
      .filter(([, studentGrade]) => studentGrade === grade)
      .map(([student]) => student)
      .sort();
  }
}

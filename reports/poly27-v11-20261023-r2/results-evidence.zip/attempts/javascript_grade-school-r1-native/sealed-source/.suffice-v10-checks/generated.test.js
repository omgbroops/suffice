import { GradeSchool } from '../grade-school.js';

test('a new school has an empty roster and empty grades', () => {
  const school = new GradeSchool();
  expect(school.roster()).toEqual({});
  expect(school.grade(2)).toEqual([]);
});

test('adding a student returns undefined and enrolls them in their grade', () => {
  const school = new GradeSchool();
  expect(school.add('Jim', 2)).toBeUndefined();
  expect(school.grade(2)).toEqual(['Jim']);
  expect(school.roster()).toEqual({ 2: ['Jim'] });
});

test('grades contain only their students in alphabetical order', () => {
  const school = new GradeSchool();
  school.add('Zoe', 2);
  school.add('Peter', 2);
  school.add('Anna', 1);
  school.add('Alex', 2);
  expect(school.grade(2)).toEqual(['Alex', 'Peter', 'Zoe']);
  expect(school.grade(1)).toEqual(['Anna']);
  expect(school.grade(3)).toEqual([]);
});

test('the roster groups alphabetically sorted students in numeric grade order', () => {
  const school = new GradeSchool();
  school.add('Jim', 10);
  school.add('Zoe', 2);
  school.add('Charlie', 1);
  school.add('Anna', 1);
  school.add('Alex', 2);
  school.add('Barb', 1);
  const roster = school.roster();
  expect(roster).toEqual({
    1: ['Anna', 'Barb', 'Charlie'],
    2: ['Alex', 'Zoe'],
    10: ['Jim'],
  });
  expect(Object.keys(roster)).toEqual(['1', '2', '10']);
});

test('adding the same student to the same grade does not duplicate them', () => {
  const school = new GradeSchool();
  school.add('Jim', 2);
  expect(school.add('Jim', 2)).toBeUndefined();
  expect(school.grade(2)).toEqual(['Jim']);
  expect(school.roster()).toEqual({ 2: ['Jim'] });
});

test('adding an existing student updates their grade and removes empty grades', () => {
  const school = new GradeSchool();
  school.add('Jim', 2);
  school.add('Alex', 3);
  school.add('Jim', 3);
  expect(school.grade(2)).toEqual([]);
  expect(school.grade(3)).toEqual(['Alex', 'Jim']);
  expect(school.roster()).toEqual({ 3: ['Alex', 'Jim'] });
});

test('moving a student preserves classmates in the previous grade', () => {
  const school = new GradeSchool();
  school.add('Anna', 1);
  school.add('Barb', 1);
  school.add('Anna', 2);
  expect(school.roster()).toEqual({ 1: ['Barb'], 2: ['Anna'] });
});

test('returned grade arrays and roster objects cannot change school enrollment', () => {
  const school = new GradeSchool();
  school.add('Jim', 2);
  school.grade(2).push('Zoe');
  const roster = school.roster();
  roster[2].push('Alex');
  roster[3] = ['Anna'];
  delete roster[2];
  expect(school.grade(2)).toEqual(['Jim']);
  expect(school.roster()).toEqual({ 2: ['Jim'] });
});

test('earlier results are snapshots and different schools are independent', () => {
  const school = new GradeSchool();
  const otherSchool = new GradeSchool();
  school.add('Jim', 2);
  const roster = school.roster();
  const grade = school.grade(2);
  school.add('Anna', 2);
  school.add('Jim', 3);
  expect(roster).toEqual({ 2: ['Jim'] });
  expect(grade).toEqual(['Jim']);
  expect(otherSchool.roster()).toEqual({});
});

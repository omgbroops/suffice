import pytest

from go_counting import Board


@pytest.mark.parametrize("color", ["B", "W"])
def test_enclosed_connected_region(color):
    board = Board([color * 5, color + "   " + color,
                   color * 2 + " " + color * 2, color * 5])
    region = {(1, 1), (2, 1), (3, 1), (2, 2)}
    for coordinate in region:
        assert board.territory(*coordinate) == (color, region)
    expected = {"B": set(), "W": set(), "": set()}
    expected[color] = region
    assert board.territories() == expected


def test_both_colors_and_neutral_regions_on_rectangular_board():
    board = Board([" B W "] * 3)
    expected = {
        "B": {(0, y) for y in range(3)},
        "W": {(4, y) for y in range(3)},
        "": {(2, y) for y in range(3)},
    }
    assert board.territories() == expected
    for owner, region in expected.items():
        for coordinate in region:
            assert board.territory(*coordinate) == (owner, region)


def test_diagonal_stones_do_not_border_region():
    assert Board(["BW", " B"]).territory(0, 1) == ("B", {(0, 1)})


def test_diagonal_empty_intersections_are_separate():
    board = Board([" B", "B "])
    assert board.territory(0, 0) == ("B", {(0, 0)})
    assert board.territory(1, 1) == ("B", {(1, 1)})
    assert board.territories() == {"B": {(0, 0), (1, 1)}, "W": set(), "": set()}


@pytest.mark.parametrize("coordinate", [(0, 0), (1, 0)])
def test_stones_are_not_territory(coordinate):
    board = Board(["BW"])
    assert board.territory(*coordinate) == ("", set())
    assert board.territories() == {"B": set(), "W": set(), "": set()}


@pytest.mark.parametrize("coordinate", [(-1, 0), (0, -1), (3, 0), (0, 2), (8, 9)])
def test_invalid_coordinates_raise_with_message(coordinate):
    with pytest.raises(ValueError, match=".+"):
        Board(["   ", "   "]).territory(*coordinate)


def test_empty_board():
    board = Board([])
    assert board.territories() == {"B": set(), "W": set(), "": set()}
    with pytest.raises(ValueError, match=".+"):
        board.territory(0, 0)


def test_large_region_without_stones_is_unowned():
    board = Board([" " * 60] * 60)
    region = {(x, y) for x in range(60) for y in range(60)}
    assert board.territory(30, 30) == ("", region)
    assert board.territories() == {"B": set(), "W": set(), "": region}


@pytest.mark.parametrize("cell, owner", [(" ", ""), ("B", ""), ("W", "")])
def test_single_intersection(cell, owner):
    region = {(0, 0)} if cell == " " else set()
    assert Board([cell]).territory(0, 0) == (owner, region)

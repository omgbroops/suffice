import pytest

from affine_cipher import decode, encode


@pytest.mark.parametrize(
    "plain_text,a,b,expected",
    [
        ("test", 5, 7, "ybty"),
        ("Yes", 5, 7, "xbt"),
        ("OMG", 21, 3, "lvz"),
        ("Testing,1 2 3, testing.", 3, 4, "jqgjc rw123 jqgjc rw"),
        ("The quick brown fox jumps over the lazy dog.", 19, 13,
         "kqlfd jzvgy tpaet icdhm rtwly kqlon ubstx"),
        ("0123456789", 5, 7, "01234 56789"),
        ("abcde", 1, 0, "abcde"),
        ("abcdef", 1, 0, "abcde f"),
        ("", 5, 7, ""),
        (" ,.!?\n\t", 5, 7, ""),
    ],
)
def test_encode_examples(plain_text, a, b, expected):
    assert encode(plain_text, a, b) == expected


@pytest.mark.parametrize(
    "ciphered_text,a,b,expected",
    [
        ("ybty", 5, 7, "test"),
        ("ybty", 11, 7, "lqul"),
        ("kqlfd jzvgy tpaet icdhm rtwly kqlon ubstx", 19, 13,
         "thequickbrownfoxjumpsoverthelazydog"),
        ("YB,TY! 01234 56789", 5, 7, "test0123456789"),
        ("", 15, 1, ""),
        (" !\n\t", 15, 1, ""),
    ],
)
def test_decode_examples(ciphered_text, a, b, expected):
    assert decode(ciphered_text, a, b) == expected


@pytest.mark.parametrize("operation", [encode, decode])
@pytest.mark.parametrize("a", [0, 2, 13, 18, 26, -2])
@pytest.mark.parametrize("text", ["test123", ""])
def test_invalid_keys(operation, a, text):
    with pytest.raises(ValueError, match=r"^a and m must be coprime\.$"):
        operation(text, a, 7)


@pytest.mark.parametrize("a", [1, 3, 5, 7, 9, 11, 15, 17, 19, 21, 23, 25, -5, 31])
@pytest.mark.parametrize("b", [0, 7, 26, -13, 100])
def test_round_trip(a, b):
    text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789!"
    encrypted = encode(text, a, b)
    assert decode(encrypted, a, b) == "abcdefghijklmnopqrstuvwxyz0123456789"
    groups = encrypted.split()
    assert all(len(group) == 5 for group in groups[:-1])
    assert 1 <= len(groups[-1]) <= 5


def test_modular_inverse_example():
    assert encode("abcdefghijklmnopqrstuvwxyz", 15, 0) == "apeti xmbqf ujync rgvkz odshw l"
    assert decode("apeti xmbqf ujync rgvkz odshw l", 15, 0) == "abcdefghijklmnopqrstuvwxyz"

#include "catch.hpp"
#include "phone_number.h"

#include <stdexcept>
#include <string>

TEST_CASE("Common formatting and the optional country code are cleaned") {
    for (const std::string input : {"+1 (613)-995-0253", "613-995-0253",
                                    "1 613 995 0253", "613.995.0253",
                                    "6139950253", "  613 995 0253  "}) {
        const phone_number::phone_number phone(input);
        REQUIRE(phone.number() == "6139950253");
        REQUIRE(phone.area_code() == "613");
        REQUIRE(static_cast<std::string>(phone) == "(613) 995-0253");
    }
}

TEST_CASE("NANP prefix boundaries and zero subscriber digits are valid") {
    const phone_number::phone_number low("+1 (200) 200-0000");
    REQUIRE(low.number() == "2002000000");
    REQUIRE(low.area_code() == "200");
    REQUIRE(static_cast<std::string>(low) == "(200) 200-0000");

    const phone_number::phone_number high("9999999999");
    REQUIRE(high.number() == "9999999999");
    REQUIRE(high.area_code() == "999");
}

TEST_CASE("Invalid lengths and country codes are rejected") {
    for (const std::string input : {"", "   ", "123456789", "223456789",
                                    "223456789012", "22234567890",
                                    "02345678901", "+44 223 456 7890"}) {
        REQUIRE_THROWS_AS(phone_number::phone_number{input}, std::domain_error);
    }
}

TEST_CASE("Area and exchange codes cannot begin with zero or one") {
    for (const std::string input : {"0234567890", "1234567890", "2230567890",
                                    "2231567890", "10234567890", "11234567890",
                                    "12230567890", "12231567890"}) {
        REQUIRE_THROWS_AS(phone_number::phone_number{input}, std::domain_error);
    }
}

TEST_CASE("Letters and unsupported punctuation are rejected") {
    for (const std::string input : {"223a4567890", "2234567890x", "223@4567890",
                                    "223:4567890", "223!4567890"}) {
        REQUIRE_THROWS_AS(phone_number::phone_number{input}, std::domain_error);
    }
}

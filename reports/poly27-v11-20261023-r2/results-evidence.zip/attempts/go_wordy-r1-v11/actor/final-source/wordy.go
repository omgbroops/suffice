package wordy

import (
	"strconv"
	"strings"
)

// Answer evaluates a simple arithmetic word problem. Operations are applied
// from left to right, as they are spoken.
func Answer(question string) (int, bool) {
	question = strings.TrimSpace(question)
	if !strings.HasPrefix(question, "What is ") || !strings.HasSuffix(question, "?") {
		return 0, false
	}

	expression := strings.TrimSpace(question[len("What is ") : len(question)-1])
	fields := strings.Fields(expression)
	if len(fields) == 0 {
		return 0, false
	}

	value, ok := parseNumber(fields[0])
	if !ok {
		return 0, false
	}

	for i := 1; i < len(fields); {
		if i+1 >= len(fields) {
			return 0, false
		}
		operator := fields[i]
		numberIndex := i + 1
		if operator == "multiplied" || operator == "divided" {
			if i+2 >= len(fields) || fields[i+1] != "by" {
				return 0, false
			}
			numberIndex = i + 2
		}
		next, ok := parseNumber(fields[numberIndex])
		if !ok {
			return 0, false
		}

		switch operator {
		case "plus":
			value += next
		case "minus":
			value -= next
		case "multiplied":
			value *= next
		case "divided":
			if next == 0 {
				return 0, false
			}
			value /= next
		default:
			return 0, false
		}
		i = numberIndex + 1
	}
	return value, true
}

func parseNumber(token string) (int, bool) {
	n, err := strconv.ParseInt(token, 10, strconv.IntSize)
	if err != nil {
		return 0, false
	}
	return int(n), true
}

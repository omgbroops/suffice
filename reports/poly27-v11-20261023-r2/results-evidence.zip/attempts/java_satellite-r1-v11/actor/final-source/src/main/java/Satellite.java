import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Satellite {
    public Tree treeFromTraversals(List<Character> preorderInput, List<Character> inorderInput) {
        if (preorderInput == null || inorderInput == null) {
            throw new IllegalArgumentException("traversals must not be null");
        }
        if (preorderInput.size() != inorderInput.size()) {
            throw new IllegalArgumentException("traversals must have the same length");
        }

        Map<Character, Integer> inorderPositions = new HashMap<>();
        Set<Character> preorderValues = new HashSet<>();
        for (int i = 0; i < preorderInput.size(); i++) {
            Character value = preorderInput.get(i);
            if (value == null || !preorderValues.add(value)) {
                throw new IllegalArgumentException("traversals must contain unique items");
            }
        }
        for (int i = 0; i < inorderInput.size(); i++) {
            Character value = inorderInput.get(i);
            if (value == null || inorderPositions.put(value, i) != null) {
                throw new IllegalArgumentException("traversals must contain unique items");
            }
        }
        if (!preorderValues.equals(inorderPositions.keySet())) {
            throw new IllegalArgumentException("traversals must contain the same elements");
        }
        if (preorderInput.isEmpty()) {
            return new Tree(null);
        }

        int[] preorderPosition = {0};
        Node root = build(preorderInput, inorderPositions, preorderPosition, 0, inorderInput.size() - 1);
        if (preorderPosition[0] != preorderInput.size()) {
            throw new IllegalArgumentException("traversals must contain the same elements");
        }
        return new Tree(root);
    }

    private Node build(List<Character> preorder, Map<Character, Integer> inorderPositions,
                       int[] preorderPosition, int start, int end) {
        if (start > end) {
            return null;
        }
        if (preorderPosition[0] >= preorder.size()) {
            throw new IllegalArgumentException("traversals must contain the same elements");
        }

        Character value = preorder.get(preorderPosition[0]++);
        Integer rootPosition = inorderPositions.get(value);
        if (rootPosition == null || rootPosition < start || rootPosition > end) {
            throw new IllegalArgumentException("traversals must contain the same elements");
        }

        Node root = new Node(value);
        root.left = build(preorder, inorderPositions, preorderPosition, start, rootPosition - 1);
        root.right = build(preorder, inorderPositions, preorderPosition, rootPosition + 1, end);
        return root;
    }
}

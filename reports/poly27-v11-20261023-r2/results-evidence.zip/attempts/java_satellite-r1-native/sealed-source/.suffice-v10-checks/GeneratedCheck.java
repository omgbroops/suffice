import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import org.junit.jupiter.api.Test;

public class GeneratedCheck {
    private final Satellite satellite = new Satellite();

    @Test
    void emptyTree() {
        assertTraversals(List.of(), List.of(), List.of());
    }

    @Test
    void singleNode() {
        assertTraversals(List.of('a'), List.of('a'), List.of('a'));
    }

    @Test
    void exampleTree() {
        assertTraversals(List.of('a', 'i', 'x', 'f', 'r'),
                List.of('i', 'a', 'f', 'x', 'r'), List.of('i', 'f', 'r', 'x', 'a'));
    }

    @Test
    void balancedTree() {
        assertTraversals(List.of('d', 'b', 'a', 'c', 'f', 'e', 'g'),
                List.of('a', 'b', 'c', 'd', 'e', 'f', 'g'),
                List.of('a', 'c', 'b', 'e', 'g', 'f', 'd'));
    }

    @Test
    void leftAndRightChains() {
        assertTraversals(List.of('a', 'b', 'c'), List.of('c', 'b', 'a'),
                List.of('c', 'b', 'a'));
        assertTraversals(List.of('a', 'b', 'c'), List.of('a', 'b', 'c'),
                List.of('c', 'b', 'a'));
    }

    @Test
    void preservesInputsAndSupportsRepeatedCalls() {
        List<Character> preorder = new LinkedList<>(List.of('b', 'a', 'c'));
        List<Character> inorder = new ArrayList<>(List.of('a', 'b', 'c'));
        Tree first = satellite.treeFromTraversals(preorder, inorder);
        assertEquals(List.of('b', 'a', 'c'), preorder);
        assertEquals(List.of('a', 'b', 'c'), inorder);
        assertTraversals(List.of('x'), List.of('x'), List.of('x'));
        assertEquals(List.of('a', 'c', 'b'), first.postorder());
    }

    @Test
    void rejectsDifferentLengths() {
        assertInvalid(List.of('a'), List.of(), "traversals must have the same length");
        assertInvalid(List.of(), List.of('a'), "traversals must have the same length");
    }

    @Test
    void rejectsDifferentElements() {
        assertInvalid(List.of('a', 'b'), List.of('a', 'c'),
                "traversals must have the same elements");
    }

    @Test
    void rejectsRepeatedItemsInEitherTraversal() {
        assertInvalid(List.of('a', 'a'), List.of('a', 'a'),
                "traversals must contain unique items");
        assertInvalid(List.of('a', 'a'), List.of('a', 'b'),
                "traversals must contain unique items");
        assertInvalid(List.of('a', 'b'), List.of('a', 'a'),
                "traversals must contain unique items");
    }

    @Test
    void rejectsIncompatibleSubtreeOrdering() {
        assertThrows(IllegalArgumentException.class,
                () -> satellite.treeFromTraversals(List.of('a', 'b', 'c'),
                        List.of('c', 'a', 'b')));
    }

    private void assertTraversals(List<Character> preorder, List<Character> inorder,
            List<Character> postorder) {
        Tree tree = satellite.treeFromTraversals(preorder, inorder);
        assertEquals(preorder, tree.preorder());
        assertEquals(inorder, tree.inorder());
        assertEquals(postorder, tree.postorder());
    }

    private void assertInvalid(List<Character> preorder, List<Character> inorder, String message) {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> satellite.treeFromTraversals(preorder, inorder));
        assertEquals(message, exception.getMessage());
    }
}

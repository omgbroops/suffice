import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Satellite {
    public Tree treeFromTraversals(List<Character> preorderInput, List<Character> inorderInput) {
        if (preorderInput.size() != inorderInput.size()) {
            throw new IllegalArgumentException("traversals must have the same length");
        }

        Set<Character> preorderValues = new HashSet<>(preorderInput);
        Set<Character> inorderValues = new HashSet<>(inorderInput);
        if (preorderValues.size() != preorderInput.size()
                || inorderValues.size() != inorderInput.size()) {
            throw new IllegalArgumentException("traversals must contain unique items");
        }
        if (!preorderValues.equals(inorderValues)) {
            throw new IllegalArgumentException("traversals must have the same elements");
        }

        Map<Character, Integer> inorderPositions = new HashMap<>();
        int position = 0;
        for (char value : inorderInput) {
            inorderPositions.put(value, position++);
        }
        return new Tree(buildSubtree(preorderInput.iterator(), inorderPositions,
                0, inorderInput.size()));
    }

    private Node buildSubtree(Iterator<Character> preorder, Map<Character, Integer> inorderPositions,
            int start, int end) {
        if (start == end) {
            return null;
        }

        char value = preorder.next();
        int rootPosition = inorderPositions.get(value);
        if (rootPosition < start || rootPosition >= end) {
            throw new IllegalArgumentException("traversals must have the same elements");
        }

        Node root = new Node(value);
        root.left = buildSubtree(preorder, inorderPositions, start, rootPosition);
        root.right = buildSubtree(preorder, inorderPositions, rootPosition + 1, end);
        return root;
    }
}

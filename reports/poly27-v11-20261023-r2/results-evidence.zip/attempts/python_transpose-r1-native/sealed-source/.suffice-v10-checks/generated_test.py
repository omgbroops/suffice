import pytest

from transpose import transpose


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("", ""),
        ("A", "A"),
        ("ABC", "A\nB\nC"),
        ("A\nB\nC", "ABC"),
        ("ABC\nDEF", "AD\nBE\nCF"),
        ("ABC\nDE", "AD\nBE\nC"),
        ("AB\nDEF", "AD\nBE\n F"),
        ("A\nBCD\nE", "ABE\n C\n D"),
        ("ABC\nD\nEFG", "ADE\nB F\nC G"),
        ("ABC\n   ", "A \nB \nC "),
        ("AB \nD", "AD\nB\n "),
        ("A\nB ", "AB\n  "),
        (" \n ", "  "),
        ("\nAB", " A\n B"),
        ("AB\n\nCD", "A C\nB D"),
        ("AB\n", "A\nB"),
        ("\n\n", ""),
        ("αβ\nγδ", "αγ\nβδ"),
        ("A\t\nBC", "AB\n\tC"),
    ],
)
def test_transpose_public_examples_and_edge_cases(text, expected):
    assert transpose(text) == expected


def test_rectangular_text_round_trip_preserves_spaces():
    text = " A  \nB C \n D E"
    assert transpose(transpose(text)) == text

from itertools import zip_longest


def transpose(text):
    """Transpose rows, padding gaps only before existing characters."""
    transposed = []
    for column in zip_longest(*text.split("\n"), fillvalue=None):
        end = len(column)
        # Remove missing cells at the end, preserving actual input spaces.
        while end and column[end - 1] is None:
            end -= 1
        transposed.append("".join(
            character if character is not None else " "
            for character in column[:end]
        ))
    return "\n".join(transposed)

class PigLatinTranslator {
    public String translate(String word) {
        if (word == null || word.isEmpty()) {
            return word;
        }

        StringBuilder result = new StringBuilder(word.length() + 2);
        int position = 0;
        while (position < word.length()) {
            if (!isLetter(word.charAt(position))) {
                result.append(word.charAt(position++));
                continue;
            }

            int end = position;
            while (end < word.length() && isLetter(word.charAt(end))) {
                end++;
            }
            result.append(translateWord(word.substring(position, end)));
            position = end;
        }
        return result.toString();
    }

    private String translateWord(String word) {
        String lower = word.toLowerCase(java.util.Locale.ROOT);
        if (startsWithVowel(lower) || lower.startsWith("xr") || lower.startsWith("yt")) {
            return word + "ay";
        }

        int split = -1;
        for (int i = 0; i < lower.length(); i++) {
            if (lower.startsWith("qu", i)) {
                split = i + 2;
                break;
            }
            if (isVowel(lower.charAt(i))) {
                split = i;
                break;
            }
            if (i > 0 && lower.charAt(i) == 'y') {
                split = i;
                break;
            }
        }

        if (split < 0) {
            // A word with no vowel or internal y has no vowel cluster to split at.
            split = word.length();
        }
        return word.substring(split) + word.substring(0, split) + "ay";
    }

    private boolean startsWithVowel(String word) {
        return !word.isEmpty() && isVowel(word.charAt(0));
    }

    private boolean isVowel(char character) {
        return character == 'a' || character == 'e' || character == 'i'
                || character == 'o' || character == 'u';
    }

    private boolean isLetter(char character) {
        return (character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z');
    }
}

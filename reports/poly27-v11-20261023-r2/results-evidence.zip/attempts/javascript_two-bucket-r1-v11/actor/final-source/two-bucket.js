//
// This is only a SKELETON file for the 'Two Bucket' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class TwoBucket {
  constructor(size1, size2, goal, start) {
    this.capacities = [size1, size2];
    this.goal = goal;
    this.startIndex = start === 'one' ? 0 : 1;
  }

  solve() {
    const [size1, size2] = this.capacities;
    const { goal, startIndex } = this;

    if (!Number.isInteger(size1) || !Number.isInteger(size2) ||
        size1 <= 0 || size2 <= 0 || !Number.isInteger(goal) ||
        goal < 0 || goal > Math.max(size1, size2)) {
      throw new Error('The goal cannot be measured with these buckets.');
    }

    const initial = [0, 0];
    initial[startIndex] = this.capacities[startIndex];
    const queue = [{ one: initial[0], two: initial[1], moves: 1 }];
    const visited = new Set([initial.join(',')]);
    const otherIndex = 1 - startIndex;

    while (queue.length > 0) {
      const state = queue.shift();
      const values = [state.one, state.two];

      if (state.moves > 0 && (state.one === goal || state.two === goal)) {
        return {
          moves: state.moves,
          goalBucket: state.one === goal ? 'one' : 'two',
          otherBucket: state.one === goal ? state.two : state.one,
        };
      }

      const successors = [];
      // Fill or empty either bucket.
      for (const index of [startIndex, otherIndex]) {
        if (values[index] < this.capacities[index]) {
          const filled = [...values];
          filled[index] = this.capacities[index];
          successors.push(filled);
        }
        if (values[index] > 0) {
          const emptied = [...values];
          emptied[index] = 0;
          successors.push(emptied);
        }
      }

      // Pour in either direction until the source is empty or destination full.
      for (const [from, to] of [[startIndex, otherIndex], [otherIndex, startIndex]]) {
        if (values[from] === 0 || values[to] === this.capacities[to]) continue;
        const amount = Math.min(values[from], this.capacities[to] - values[to]);
        const poured = [...values];
        poured[from] -= amount;
        poured[to] += amount;
        successors.push(poured);
      }

      for (const next of successors) {
        if (next[startIndex] === 0 && next[otherIndex] === this.capacities[otherIndex]) continue;
        const key = next.join(',');
        if (visited.has(key)) continue;
        visited.add(key);
        queue.push({ one: next[0], two: next[1], moves: state.moves + 1 });
      }
    }

    throw new Error('The goal cannot be measured with these buckets.');
  }
}

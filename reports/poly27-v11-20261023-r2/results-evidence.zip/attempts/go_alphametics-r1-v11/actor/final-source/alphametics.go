package alphametics

import (
	"fmt"
	"strings"
	"unicode"
)

// Solve finds a distinct decimal digit for each letter such that the addition
// represented by puzzle is valid.
func Solve(puzzle string) (map[string]int, error) {
	fields := strings.Fields(puzzle)
	if len(fields) < 3 || len(fields)%2 == 0 {
		return nil, fmt.Errorf("invalid alphametics puzzle")
	}

	if len(fields)%2 == 0 || fields[len(fields)-2] != "==" {
		return nil, fmt.Errorf("invalid alphametics puzzle")
	}
	addends := make([][]string, 0, (len(fields)-1)/2)
	for i := 0; i < len(fields)-2; i += 2 {
		word, err := letters(fields[i])
		if err != nil {
			return nil, err
		}
		addends = append(addends, word)
		if i+1 < len(fields)-2 && fields[i+1] != "+" {
			return nil, fmt.Errorf("invalid alphametics puzzle")
		}
	}
	result, err := letters(fields[len(fields)-1])
	if err != nil {
		return nil, err
	}

	leading := make(map[string]bool)
	all := make(map[string]bool)
	mark := func(word []string) {
		for _, letter := range word {
			all[letter] = true
		}
		if len(word) > 1 {
			leading[word[0]] = true
		}
	}
	for _, word := range addends {
		mark(word)
	}
	mark(result)
	if len(all) > 10 {
		return nil, fmt.Errorf("puzzle has more than ten letters")
	}

	assignment := make(map[string]int, len(all))
	used := [10]bool{}
	maxColumns := len(result)
	for _, word := range addends {
		if len(word) > maxColumns {
			maxColumns = len(word)
		}
	}

	var solveColumn func(int, int) bool
	var assignAddend func(int, int, int, int) bool
	assignAddend = func(column, index, sum, carry int) bool {
		if index == len(addends) {
			total := sum + carry
			digit := total % 10
			nextCarry := total / 10
			if column >= len(result) {
				if digit != 0 {
					return false
				}
			} else {
				letter := result[len(result)-1-column]
				if value, ok := assignment[letter]; ok {
					if value != digit {
						return false
					}
					return solveColumn(column+1, nextCarry)
				}
				if used[digit] || (digit == 0 && leading[letter]) {
					return false
				}
				assignment[letter] = digit
				used[digit] = true
				if solveColumn(column+1, nextCarry) {
					return true
				}
				delete(assignment, letter)
				used[digit] = false
			}
			return false
		}

		word := addends[index]
		if column >= len(word) {
			return assignAddend(column, index+1, sum, carry)
		}
		letter := word[len(word)-1-column]
		if value, ok := assignment[letter]; ok {
			return assignAddend(column, index+1, sum+value, carry)
		}
		for digit := 0; digit <= 9; digit++ {
			if used[digit] || (digit == 0 && leading[letter]) {
				continue
			}
			assignment[letter] = digit
			used[digit] = true
			if assignAddend(column, index+1, sum+digit, carry) {
				return true
			}
			delete(assignment, letter)
			used[digit] = false
		}
		return false
	}
	solveColumn = func(column, carry int) bool {
		if column == maxColumns {
			return carry == 0
		}
		return assignAddend(column, 0, 0, carry)
	}

	if !solveColumn(0, 0) {
		return nil, fmt.Errorf("puzzle has no solution")
	}
	return assignment, nil
}

func letters(word string) ([]string, error) {
	if word == "" {
		return nil, fmt.Errorf("invalid empty word")
	}
	runes := []rune(word)
	out := make([]string, len(runes))
	for i, r := range runes {
		if !unicode.IsLetter(r) {
			return nil, fmt.Errorf("invalid character in word %q", word)
		}
		out[i] = string(r)
	}
	return out, nil
}

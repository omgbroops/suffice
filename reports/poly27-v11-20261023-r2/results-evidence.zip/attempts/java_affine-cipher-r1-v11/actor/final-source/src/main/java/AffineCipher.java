public class AffineCipher {
    private static final int MODULUS = 26;

    public String encode(String text, int coefficient1, int coefficient2) {
        validateKey(coefficient1);

        StringBuilder encoded = new StringBuilder();
        int groupLength = 0;
        int a = Math.floorMod(coefficient1, MODULUS);
        int b = Math.floorMod(coefficient2, MODULUS);

        for (int i = 0; i < text.length(); i++) {
            char character = Character.toLowerCase(text.charAt(i));
            if (character >= 'a' && character <= 'z') {
                int value = character - 'a';
                encoded.append((char) ('a' + Math.floorMod(a * value + b, MODULUS)));
                groupLength++;
                if (groupLength == 5) {
                    encoded.append(' ');
                    groupLength = 0;
                }
            } else if (character >= '0' && character <= '9') {
                encoded.append(character);
                groupLength++;
                if (groupLength == 5) {
                    encoded.append(' ');
                    groupLength = 0;
                }
            }
        }

        if (encoded.length() > 0 && encoded.charAt(encoded.length() - 1) == ' ') {
            encoded.setLength(encoded.length() - 1);
        }
        return encoded.toString();
    }

    public String decode(String text, int coefficient1, int coefficient2) {
        validateKey(coefficient1);

        int a = Math.floorMod(coefficient1, MODULUS);
        int b = Math.floorMod(coefficient2, MODULUS);
        int inverse = 0;
        for (int candidate = 1; candidate < MODULUS; candidate++) {
            if (Math.floorMod(a * candidate, MODULUS) == 1) {
                inverse = candidate;
                break;
            }
        }

        StringBuilder decoded = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char character = Character.toLowerCase(text.charAt(i));
            if (character >= 'a' && character <= 'z') {
                int value = character - 'a';
                decoded.append((char) ('a' + Math.floorMod(inverse * (value - b), MODULUS)));
            } else if (character >= '0' && character <= '9') {
                decoded.append(character);
            }
        }
        return decoded.toString();
    }

    private void validateKey(int coefficient1) {
        if (gcd(Math.floorMod(coefficient1, MODULUS), MODULUS) != 1) {
            throw new IllegalArgumentException("The first key must be coprime to 26.");
        }
    }

    private int gcd(int first, int second) {
        while (second != 0) {
            int remainder = first % second;
            first = second;
            second = remainder;
        }
        return first;
    }
}
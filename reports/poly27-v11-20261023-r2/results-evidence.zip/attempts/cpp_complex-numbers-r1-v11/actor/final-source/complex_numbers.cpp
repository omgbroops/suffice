#include "complex_numbers.h"

#include <cmath>
#include <ostream>

namespace complex_numbers {

Complex::Complex(double real, double imaginary)
    : real_(real), imaginary_(imaginary) {}

Complex Complex::operator+(const Complex& other) const {
  return Complex(real_ + other.real_, imaginary_ + other.imaginary_);
}

Complex Complex::operator-(const Complex& other) const {
  return Complex(real_ - other.real_, imaginary_ - other.imaginary_);
}

Complex Complex::operator*(const Complex& other) const {
  return Complex(real_ * other.real_ - imaginary_ * other.imaginary_,
                 imaginary_ * other.real_ + real_ * other.imaginary_);
}

Complex Complex::operator/(const Complex& other) const {
  const double denominator =
      other.real_ * other.real_ + other.imaginary_ * other.imaginary_;
  return Complex((real_ * other.real_ + imaginary_ * other.imaginary_) /
                     denominator,
                 (imaginary_ * other.real_ - real_ * other.imaginary_) /
                     denominator);
}

double Complex::abs() const {
  return std::hypot(real_, imaginary_);
}

Complex Complex::conj() const {
  return Complex(real_, -imaginary_);
}

double Complex::real() const {
  return real_;
}

double Complex::imag() const {
  return imaginary_;
}

Complex Complex::exp() const {
  const double magnitude = std::exp(real_);
  return Complex(magnitude * std::cos(imaginary_),
                 magnitude * std::sin(imaginary_));
}

bool operator==(const Complex& lhs, const Complex& rhs) {
  return lhs.real() == rhs.real() && lhs.imag() == rhs.imag();
}

std::ostream& operator<<(std::ostream& stream, const Complex& value) {
  return stream << value.real() << " + " << value.imag() << "i";
}

Complex operator+(const Complex& lhs, double rhs) {
  return lhs + Complex(rhs, 0.0);
}

Complex operator+(double lhs, const Complex& rhs) {
  return Complex(lhs, 0.0) + rhs;
}

Complex operator-(const Complex& lhs, double rhs) {
  return lhs - Complex(rhs, 0.0);
}

Complex operator-(double lhs, const Complex& rhs) {
  return Complex(lhs, 0.0) - rhs;
}

Complex operator*(const Complex& lhs, double rhs) {
  return Complex(lhs.real() * rhs, lhs.imag() * rhs);
}

Complex operator*(double lhs, const Complex& rhs) {
  return rhs * lhs;
}

Complex operator/(const Complex& lhs, double rhs) {
  return Complex(lhs.real() / rhs, lhs.imag() / rhs);
}

Complex operator/(double lhs, const Complex& rhs) {
  return Complex(lhs, 0.0) / rhs;
}

}  // namespace complex_numbers

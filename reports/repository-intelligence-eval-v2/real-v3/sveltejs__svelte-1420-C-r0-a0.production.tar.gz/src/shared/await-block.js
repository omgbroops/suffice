import { assign, isPromise } from './utils.js';

export function handlePromise(promise, info) {
	var token = info.token = {};

	function update(type, key, value) {
		if (info.token !== token || info.destroyed) return;

		info.resolved = key && { [key]: value };

		const child_ctx = assign(assign({}, info.ctx), info.resolved);
		const block = type && (info.current = type)(info.component, child_ctx);

		if (info.block) {
			const old_block = info.block;
			info.nextBlock = block;

			const mount = () => {
				if (info.destroyed) return;

				const next_block = info.nextBlock;
				old_block.u();
				old_block.d();
				next_block.c();
				if (next_block.i) next_block.i(info.mount(), info.anchor);
				else next_block.m(info.mount(), info.anchor);

				info.block = next_block;
				info.nextBlock = null;
				info.component.root.set({});
			};

			if (old_block.o) old_block.o(mount);
			else mount();
		} else {
			info.block = block;
		}
	}

	if (isPromise(promise)) {
		promise.then(value => {
			update(info.then, info.value, value);
		}, error => {
			update(info.catch, info.error, error);
		});

		// if we previously had a then/catch block, destroy it
		if (info.current !== info.pending) {
			update(info.pending);
			return true;
		}
	} else {
		if (info.current !== info.then) {
			update(info.then, info.value, promise);
			return true;
		}

		info.resolved = { [info.value]: promise };
	}
}